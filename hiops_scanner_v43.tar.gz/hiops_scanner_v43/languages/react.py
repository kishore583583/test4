PATTERNS = {'LOG-001': ['(?i)@sentry/react', '(?i)loglevel'], 'CFG-001': ['(?i)process\\\\.env']}
