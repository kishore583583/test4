PATTERNS = {'LOG-001': ['(?i)console\\\\.log', '(?i)logger\\\\.'], 'SEC-001': ['(?i)token', '(?i)secret']}
