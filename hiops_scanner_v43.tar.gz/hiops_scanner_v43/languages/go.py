PATTERNS = {'MET-001': ['(?i)promhttp', '(?i)otel'], 'REL-002': ['(?i)Timeout:', '(?i)context\\\\.WithTimeout']}
