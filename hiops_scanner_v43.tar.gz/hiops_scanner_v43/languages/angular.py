PATTERNS = {'LOG-001': ['(?i)angular\\\\.json', '(?i)ngx-logger'], 'CFG-001': ['(?i)environment\\\\.prod']}
