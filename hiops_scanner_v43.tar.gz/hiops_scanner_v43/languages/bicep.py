PATTERNS = {'CLD-001': ['(?i)resource\\\\s+\\\\w+'], 'SEC-001': ['(?i)secureString']}
