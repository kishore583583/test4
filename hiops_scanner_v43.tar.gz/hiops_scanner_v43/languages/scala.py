PATTERNS = {'LOG-001': ['(?i)logger\\\\.', '(?i)logback'], 'MET-001': ['(?i)kamon', '(?i)prometheus']}
