PATTERNS = {'LOG-001': ['NSLog'], 'SEC-001': ['(?i)token', '(?i)secret']}
