PATTERNS = {'LOG-001': ['(?i)logger\\\\.', '(?i)logback'], 'TRC-001': ['(?i)OpenTelemetry']}
