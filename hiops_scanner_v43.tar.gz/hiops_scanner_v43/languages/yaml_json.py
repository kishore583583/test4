PATTERNS = {'DEV-001': ['(?i)stages:', '(?i)jobs:', '(?i)workflow'], 'CLD-001': ['(?i)apiVersion', '(?i)kind:']}
