PATTERNS = {'CLD-001': ['(?i)Chart\\\\.yaml', '(?i)values\\\\.yaml']}
