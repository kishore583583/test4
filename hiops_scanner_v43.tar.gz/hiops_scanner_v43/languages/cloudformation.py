PATTERNS = {'CLD-001': ['(?i)Resources:', '(?i)AWSTemplateFormatVersion']}
