PATTERNS = {'CLD-001': ['(?i)kind:\\\\s+Deployment', '(?i)livenessProbe', '(?i)readinessProbe']}
