PATTERNS = {'LOG-001': ['(?i)Monolog', '(?i)logger'], 'REL-002': ['(?i)timeout']}
