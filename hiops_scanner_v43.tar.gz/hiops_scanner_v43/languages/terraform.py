PATTERNS = {'CLD-001': ['(?i)resource\\\\s+\\\\\\"', '(?i)provider\\\\s+\\\\\\"'], 'SEC-001': ['(?i)secret', '(?i)password']}
