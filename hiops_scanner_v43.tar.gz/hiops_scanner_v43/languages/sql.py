PATTERNS = {'DAT-001': ['(?i)create table', '(?i)select ', '(?i)insert ']}
