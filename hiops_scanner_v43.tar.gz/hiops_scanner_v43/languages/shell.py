PATTERNS = {'DEV-001': ['(?i)^#!/bin/bash', '(?i)kubectl', '(?i)helm']}
