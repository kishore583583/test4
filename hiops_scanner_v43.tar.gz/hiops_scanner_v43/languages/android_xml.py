PATTERNS = {'ARC-001': ['(?i)AndroidManifest'], 'SEC-001': ['(?i)android:exported']}
