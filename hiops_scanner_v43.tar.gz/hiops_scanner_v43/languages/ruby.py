PATTERNS = {'LOG-001': ['(?i)logger\\\\.', '(?i)Rails\\\\.logger'], 'REL-002': ['(?i)timeout']}
