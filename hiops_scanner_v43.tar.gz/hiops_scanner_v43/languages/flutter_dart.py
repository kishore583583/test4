PATTERNS = {'LOG-001': ['(?i)logger', '(?i)print\\\\('], 'CFG-001': ['(?i)const String\\\\.fromEnvironment']}
