PATTERNS = {'CLD-001': ['(?i)resources', '(?i)apiVersion']}
