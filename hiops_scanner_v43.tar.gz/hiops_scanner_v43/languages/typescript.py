PATTERNS = {'LOG-001': ['(?i)logLevel', '(?i)process\\\\.env'], 'DEV-001': ['(?i)tsconfig\\\\.json']}
