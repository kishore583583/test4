PATTERNS = {'LOG-001': ['(?i)Logger\\\\(', '(?i)os_log'], 'SEC-001': ['(?i)apiKey', '(?i)token']}
