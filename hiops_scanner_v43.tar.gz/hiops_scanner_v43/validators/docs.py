CATEGORY_NAME = "Docs"

def select_controls(controls):
    return [c for c in controls if c["Category"] == CATEGORY_NAME]

def run(repo_path, controls, executor):
    results = []
    for control in controls:
        results.append(executor.execute(control))
    return results
