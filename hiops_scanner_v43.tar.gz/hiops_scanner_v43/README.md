# HiOps Scanner V43

Scalable Python scanner engine for multi-language repository assessment.

## Supported language packs
- generic
- java
- dotnet
- python
- node
- angular
- react
- go
- kotlin
- scala
- ruby
- php
- swift
- objective_c
- flutter_dart
- android_xml
- typescript
- javascript
- terraform
- bicep
- arm
- cloudformation
- kubernetes
- helm
- sql
- shell
- yaml_json

## Categories covered
- logs
- metrics
- tracing
- alerting
- reliability
- error_handling
- batch
- api
- security
- config
- cicd
- cloud
- data
- architecture
- docs

## Quick start
```bash
pip install -r requirements.txt
python main.py --repo ./sample_repo --output ./outputs
```

## Output
- outputs/json/scan_run.json
- outputs/csv/control_results.csv
- outputs/csv/control_evidence.csv
- outputs/csv/recommendations.csv
