from pathlib import Path

class RepoLoader:
    def __init__(self, repo_path: Path):
        self.repo_path = repo_path

    def validate(self) -> Path:
        if not self.repo_path.exists():
            raise FileNotFoundError(f"Repo path not found: {self.repo_path}")
        return self.repo_path
