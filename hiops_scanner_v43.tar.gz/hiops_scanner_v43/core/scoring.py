def score_results(results):
    total_weight = 0
    pass_weight = 0
    for r in results:
        weight = int(r.get("weight", 1))
        total_weight += weight
        if r["result"] == "PASS":
            pass_weight += weight
    score = round((pass_weight / total_weight) * 100, 2) if total_weight else 0
    return {"overall_score": score, "controls_evaluated": len(results)}
