class DBWriter:
    def write(self, payload):
        # Future MySQL persistence hook
        return {"status": "not_implemented"}
