from pathlib import Path

class FileInventory:
    def __init__(self, repo_path: Path):
        self.repo_path = repo_path

    def build(self):
        files = []
        for p in self.repo_path.rglob("*"):
            if p.is_file():
                files.append({
                    "path": str(p),
                    "name": p.name,
                    "suffix": p.suffix.lower(),
                    "size": p.stat().st_size
                })
        return files
