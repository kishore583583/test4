from pathlib import Path

class LanguageDetector:
    def detect(self, files):
        names = {f["name"] for f in files}
        suffixes = {f["suffix"] for f in files}
        langs = set(["generic"])

        if ".java" in suffixes or "pom.xml" in names or "build.gradle" in names:
            langs.add("java")
        if ".cs" in suffixes or any(n.endswith(".csproj") or n.endswith(".sln") for n in names):
            langs.add("dotnet")
        if ".py" in suffixes or "pyproject.toml" in names or "requirements.txt" in names:
            langs.add("python")
        if ".js" in suffixes or "package.json" in names:
            langs.add("node"); langs.add("javascript")
        if ".ts" in suffixes or "tsconfig.json" in names:
            langs.add("typescript")
        if "angular.json" in names:
            langs.add("angular")
        if "package.json" in names and any(x in str(names).lower() for x in ["react", "next"]):
            langs.add("react")
        if ".go" in suffixes or "go.mod" in names:
            langs.add("go")
        if ".kt" in suffixes:
            langs.add("kotlin")
        if ".scala" in suffixes or "build.sbt" in names:
            langs.add("scala")
        if ".rb" in suffixes or "Gemfile" in names:
            langs.add("ruby")
        if ".php" in suffixes or "composer.json" in names:
            langs.add("php")
        if ".swift" in suffixes:
            langs.add("swift")
        if ".m" in suffixes or ".mm" in suffixes:
            langs.add("objective_c")
        if ".dart" in suffixes or "pubspec.yaml" in names:
            langs.add("flutter_dart")
        if "AndroidManifest.xml" in names:
            langs.add("android_xml")
        if ".tf" in suffixes:
            langs.add("terraform")
        if ".bicep" in suffixes:
            langs.add("bicep")
        if any("arm" in n.lower() and n.lower().endswith(".json") for n in names):
            langs.add("arm")
        if "template.yaml" in names or "serverless.yml" in names:
            langs.add("cloudformation")
        if any(n in names for n in ["deployment.yaml", "service.yaml", "ingress.yaml"]):
            langs.add("kubernetes")
        if "Chart.yaml" in names:
            langs.add("helm")
        if ".sql" in suffixes:
            langs.add("sql")
        if ".sh" in suffixes:
            langs.add("shell")
        if ".yaml" in suffixes or ".yml" in suffixes or ".json" in suffixes:
            langs.add("yaml_json")
        return sorted(langs)
