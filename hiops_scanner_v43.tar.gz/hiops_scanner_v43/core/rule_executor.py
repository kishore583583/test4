import re
from pathlib import Path
from core.language_registry import LANGUAGE_PACKS

class RuleExecutor:
    def __init__(self, repo_path: Path, detected_languages: list[str]):
        self.repo_path = repo_path
        self.detected_languages = detected_languages

    def _read_file(self, path: Path) -> str:
        try:
            return path.read_text(encoding="utf-8", errors="ignore")
        except Exception:
            return ""

    def execute(self, control):
        control_id = control["ID"]
        category = control["Category"]
        patterns = []
        for lang in self.detected_languages:
            pack = LANGUAGE_PACKS.get(lang)
            if not pack:
                continue
            patterns.extend(pack.PATTERNS.get(control_id, []))

        evidence = []
        if not patterns:
            return {
                "control_id": control_id,
                "category": category,
                "result": "UNKNOWN",
                "evidence": [],
                "why": "No patterns registered for detected languages."
            }

        for path in self.repo_path.rglob("*"):
            if not path.is_file():
                continue
            text = self._read_file(path)
            lines = text.splitlines()
            for idx, line in enumerate(lines, start=1):
                for pat in patterns:
                    if re.search(pat, line):
                        evidence.append({
                            "file": str(path),
                            "line": idx,
                            "snippet": line[:300]
                        })
                        break

        result = "PASS" if evidence else "FAIL"
        return {
            "control_id": control_id,
            "category": category,
            "result": result,
            "evidence": evidence[:50],
            "why": f"{len(evidence)} matches found" if evidence else "No evidence found"
        }
