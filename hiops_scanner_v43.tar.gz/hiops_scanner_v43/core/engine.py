from pathlib import Path
from core.repo_loader import RepoLoader
from core.file_inventory import FileInventory
from core.language_detector import LanguageDetector
from core.controller_grid import load_controller_grid
from core.rule_executor import RuleExecutor
from core.scoring import score_results
from core.recommendations import build_recommendations
from core.evidence_writer import EvidenceWriter

from validators import (
    logs, metrics, tracing, alerting, reliability, error_handling, batch, api,
    security, config, cicd, cloud, data, architecture, docs
)

VALIDATOR_MODULES = [
    logs, metrics, tracing, alerting, reliability, error_handling, batch, api,
    security, config, cicd, cloud, data, architecture, docs
]

class ScannerEngine:
    def __init__(self, repo_path: Path, output_dir: Path):
        self.repo_path = repo_path
        self.output_dir = output_dir
        self.grid_path = Path(__file__).resolve().parent.parent / "controller_grid.csv"

    def run(self):
        RepoLoader(self.repo_path).validate()
        files = FileInventory(self.repo_path).build()
        languages = LanguageDetector().detect(files)
        controls = load_controller_grid(self.grid_path)
        controls_by_id = {c["ID"]: c for c in controls}
        executor = RuleExecutor(self.repo_path, languages)

        all_results = []
        for validator in VALIDATOR_MODULES:
            category_controls = validator.select_controls(controls)
            validator_results = validator.run(self.repo_path, category_controls, executor)
            for r in validator_results:
                r["weight"] = int(controls_by_id[r["control_id"]]["Weight"])
            all_results.extend(validator_results)

        summary = score_results(all_results)
        recs = build_recommendations(all_results, controls_by_id)

        writer = EvidenceWriter(self.output_dir)
        writer.write_results(all_results)
        writer.write_evidence(all_results)
        writer.write_recommendations(recs)
        payload = {
            "repo_path": str(self.repo_path),
            "detected_languages": languages,
            "summary": summary,
            "results": all_results,
            "recommendations": recs
        }
        writer.write_json(payload)
        return {"summary": summary, "languages": languages, "recommendations": len(recs)}
