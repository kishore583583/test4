from pathlib import Path
import csv, json

class EvidenceWriter:
    def __init__(self, output_dir: Path):
        self.output_dir = output_dir
        (self.output_dir / "csv").mkdir(parents=True, exist_ok=True)
        (self.output_dir / "json").mkdir(parents=True, exist_ok=True)

    def write_results(self, results):
        out = self.output_dir / "csv" / "control_results.csv"
        with out.open("w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=["control_id","category","result","why","weight"])
            writer.writeheader()
            writer.writerows(results)

    def write_evidence(self, results):
        out = self.output_dir / "csv" / "control_evidence.csv"
        with out.open("w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=["control_id","category","file","line","snippet"])
            writer.writeheader()
            for r in results:
                for e in r["evidence"]:
                    writer.writerow({
                        "control_id": r["control_id"],
                        "category": r["category"],
                        "file": e["file"],
                        "line": e["line"],
                        "snippet": e["snippet"],
                    })

    def write_recommendations(self, recs):
        out = self.output_dir / "csv" / "recommendations.csv"
        with out.open("w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=["control_id","category","severity","score_impact","recommendation","why_it_matters"])
            writer.writeheader()
            writer.writerows(recs)

    def write_json(self, payload):
        out = self.output_dir / "json" / "scan_run.json"
        out.write_text(json.dumps(payload, indent=2), encoding="utf-8")
