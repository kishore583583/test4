def build_recommendations(results, controls_by_id):
    recs = []
    for r in results:
        if r["result"] == "FAIL":
            control = controls_by_id.get(r["control_id"], {})
            recs.append({
                "control_id": r["control_id"],
                "category": r["category"],
                "recommendation": control.get("Dev_Suggestion", "Implement best-practice fix"),
                "severity": control.get("Severity", "P2"),
                "score_impact": control.get("Score_Impact", "Medium"),
                "why_it_matters": f"{r['control_id']} failed because required evidence was not found."
            })
    return recs
