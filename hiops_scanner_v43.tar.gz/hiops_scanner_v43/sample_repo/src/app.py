import logging
import requests
import os

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

API_TOKEN = "hardcoded-token-123"

def fetch():
    logger.info("starting fetch")
    response = requests.get("https://example.com/data")
    return response.text
