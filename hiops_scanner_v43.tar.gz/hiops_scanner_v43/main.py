from pathlib import Path
import argparse
from core.engine import ScannerEngine

def main():
    parser = argparse.ArgumentParser(description="HiOps Scanner V43")
    parser.add_argument("--repo", required=True, help="Path to repository")
    parser.add_argument("--output", default="outputs", help="Output directory")
    args = parser.parse_args()

    engine = ScannerEngine(repo_path=Path(args.repo), output_dir=Path(args.output))
    result = engine.run()
    print(f"Scan complete: {result['summary']}")

if __name__ == "__main__":
    main()
