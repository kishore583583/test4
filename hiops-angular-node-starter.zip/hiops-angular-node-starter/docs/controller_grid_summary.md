# Controller Grid v1 Summary

Use this as the contract between Python scanner, MySQL storage, Node APIs, and Angular UI.

## Categories

1. Logs
2. Metrics
3. Tracing
4. Alerting
5. Reliability / Resilience
6. Error Handling
7. Batch / Scheduler
8. API / Integration
9. Security / Secrets
10. Configuration
11. CI/CD / DevOps
12. Cloud / Infra as Code
13. Data / Database / Messaging
14. Architecture / Dependency hints
15. Docs / Readiness hints

## Standard columns

- ID
- Category
- Control
- Weight
- Severity
- How_to_Validate
- Evidence_Output
- Pattern_Groups
- Auto_Scan_Type
- Dev_Suggestion
- Score_Impact
- Maturity_Level_Map

## Recommendation model

Every failed control should produce:

- Why it matters
- Gap detected
- Recommendation
- Suggested owner
- Score impact

## Persistence model

Store at minimum:

- scan_run
- scan_target
- control_result
- control_evidence
- score_summary
- recommendation_result
- pattern_match_detail
- file_inventory
- dependency_inventory
- doc_inventory
