# HiOps Angular + Node Starter

This starter package contains:

- `frontend/` — Angular 21 standalone app shell with dark blue executive UI
- `backend/` — Node.js + Express mock API for dashboard, explorer, recommendations, and admin scan queue
- `docs/` — implementation notes and controller grid summary

## Why this structure

The Python scanner should detect controls and store normalized scan results into MySQL first.
The Node backend should then read summarized data from MySQL and serve clean APIs.
The Angular UI should only render normalized data and should not interpret raw regex evidence.

## Angular notes

Angular v21 is current, and standalone components are the default authoring model in current Angular docs. See Angular official docs for v21 and standalone guidance. citeturn307325search0turn307325search6turn307325search11

## Run locally

### Backend

```bash
cd backend
npm install
npm run dev
```

### Frontend

```bash
cd frontend
npm install
npm start
```

Backend runs on port `4000`.
Frontend is configured to call `http://localhost:4000/api/...`.
