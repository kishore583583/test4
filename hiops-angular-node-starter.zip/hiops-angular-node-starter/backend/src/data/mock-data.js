export const dashboard = {
  summary: { score: 78, risk: 'High Risk', apps: 164, recommendations: 247 },
  buckets: [
    { name: 'Reliability & Operations', score: 74, status: 'amber' },
    { name: 'Observability & Insights', score: 81, status: 'green' },
    { name: 'Engineering & Modernization', score: 69, status: 'amber' },
    { name: 'Architecture & Business Context', score: 63, status: 'red' }
  ],
  domains: [
    { name: 'Claims', score: 82, kind: 'conf' },
    { name: 'Pharmacy', score: 68, kind: 'med' },
    { name: 'Digital', score: 87, kind: 'hi' },
    { name: 'Enrollment', score: 59, kind: 'low' },
    { name: 'Provider', score: 71, kind: 'med' },
    { name: 'Analytics', score: 80, kind: 'conf' }
  ],
  priorities: [
    'Enable structured logging in 18 services',
    'Link change records to services',
    'Fill missing architecture flow docs'
  ]
};

export const explorer = [
  { business: 'Claims Adjudication', application: 'PBM Hub', service: 'Claims API', score: 61, risk: 'High' },
  { business: 'Member Digital', application: 'Member Portal', service: 'Session Service', score: 83, risk: 'Low' },
  { business: 'Enrollment Intake', application: 'Intake Flow', service: 'Batch Loader', score: 58, risk: 'High' },
  { business: 'Claims Payments', application: 'Payment Edge', service: 'Retry Worker', score: 74, risk: 'Medium' }
];

export const recommendations = [
  { title: 'Adopt structured JSON logging in 18 services', owner: 'Engineering Enablement', uplift: '+4.2' },
  { title: 'Fill missing app-service-repo mappings', owner: 'App teams + data steward', uplift: '+3.7' },
  { title: 'Document upstream/downstream data flows', owner: 'Solution architects', uplift: '+3.1' }
];

export const queue = [
  { name: 'Claims API deep scan', status: 'Running', progress: 62 },
  { name: 'Enrollment batch scan', status: 'Queued', progress: 18 },
  { name: 'Pharmacy domain program scan', status: 'Completed', progress: 100 }
];
