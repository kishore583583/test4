import express from 'express';
import cors from 'cors';
import { dashboard, explorer, recommendations, queue } from './data/mock-data.js';

const app = express();
app.use(cors());
app.use(express.json());

app.get('/api/health', (_req, res) => res.json({ status: 'ok' }));
app.get('/api/dashboard', (_req, res) => res.json(dashboard));
app.get('/api/explorer', (_req, res) => res.json(explorer));
app.get('/api/recommendations', (_req, res) => res.json(recommendations));
app.get('/api/admin/queue', (_req, res) => res.json(queue));

app.post('/api/admin/scan', (req, res) => {
  const body = req.body ?? {};
  res.status(202).json({
    message: 'Scan accepted',
    scanId: `scan_${Date.now()}`,
    received: body
  });
});

const port = process.env.PORT || 4000;
app.listen(port, () => {
  console.log(`HiOps backend listening on http://localhost:${port}`);
});
