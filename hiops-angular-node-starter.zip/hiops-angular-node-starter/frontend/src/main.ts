import { bootstrapApplication } from '@angular/platform-browser';
import { provideRouter, RouterLink, RouterLinkActive, RouterOutlet, Routes } from '@angular/router';
import { Component, Input, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClient, provideHttpClient } from '@angular/common/http';
import { map } from 'rxjs/operators';

interface DashboardData {
  summary: { score: number; risk: string; apps: number; recommendations: number };
  buckets: Array<{ name: string; score: number; status: 'green'|'amber'|'red' }>;
  domains: Array<{ name: string; score: number; kind: 'hi'|'med'|'low'|'conf' }>;
  priorities: string[];
}

class ApiService {
  private http = inject(HttpClient);
  dashboard() { return this.http.get<DashboardData>('http://localhost:4000/api/dashboard'); }
  explorer() { return this.http.get<any[]>('http://localhost:4000/api/explorer'); }
  recommendations() { return this.http.get<any[]>('http://localhost:4000/api/recommendations'); }
  queues() { return this.http.get<any[]>('http://localhost:4000/api/admin/queue'); }
}

@Component({
  selector: 'app-shell',
  standalone: true,
  imports: [CommonModule, RouterOutlet, RouterLink, RouterLinkActive],
  template: `
  <div class="page-shell">
    <aside class="sidebar">
      <div class="brand">HiOps<small>Reliability Intelligence Command Center</small></div>
      <div class="nav-section">
        <div class="nav-title">Workspace</div>
        <a routerLink="/dashboard" routerLinkActive="active" class="nav-link">Executive Dashboard</a>
        <a routerLink="/matrix" routerLinkActive="active" class="nav-link">Tier Matrix View</a>
        <a routerLink="/explorer" routerLinkActive="active" class="nav-link">Application Explorer</a>
        <a routerLink="/domain/pharmacy" routerLinkActive="active" class="nav-link">Domain View</a>
        <a routerLink="/application/pbm-hub" routerLinkActive="active" class="nav-link">Application View</a>
        <a routerLink="/service/claims-api" routerLinkActive="active" class="nav-link">Service View</a>
        <a routerLink="/repo/claims-api-core" routerLinkActive="active" class="nav-link">Repository View</a>
        <a routerLink="/admin-scan" routerLinkActive="active" class="nav-link">Admin Scan</a>
        <a routerLink="/recommendations" routerLinkActive="active" class="nav-link">Recommendations</a>
      </div>
    </aside>
    <main class="content"><router-outlet /></main>
  </div>`
})
class ShellComponent {}

@Component({
  selector: 'page-dashboard',
  standalone: true,
  imports: [CommonModule],
  template: `
  <div class="header">
    <div><h1>Executive Dashboard</h1><p>Enterprise maturity at a glance with domain rollups, weak spots, and action priorities.</p></div>
    <div class="chips"><div class="chip">Version 1</div><div class="chip">Dark Blue Premium</div><div class="chip">Confidence 84%</div></div>
  </div>
  <div class="hero"><h2>Enterprise Maturity Score: {{data?.summary?.score}} <span class="badge amber">{{data?.summary?.risk}}</span></h2><p>Single-screen command view for overall maturity, domain performance, top risks, trend movement, and highest-impact actions.</p></div>
  <div class="grid-4">
    <div class="card kpi"><div class="label">Overall Maturity</div><div class="value">{{data?.summary?.score}}</div></div>
    <div class="card kpi"><div class="label">Applications Assessed</div><div class="value">{{data?.summary?.apps}}</div></div>
    <div class="card kpi"><div class="label">Open Recommendations</div><div class="value">{{data?.summary?.recommendations}}</div></div>
    <div class="card kpi"><div class="label">Risk Index</div><div class="value">{{data?.summary?.risk}}</div></div>
  </div>
  <div class="grid-2">
    <div class="card">
      <h3>Tier Matrix · Application Maturity</h3>
      <div class="heatmap">
        <div *ngFor="let d of data?.domains" class="heat" [ngClass]="d.kind">{{d.name}}<small>{{d.score}}</small></div>
      </div>
    </div>
    <div class="card">
      <h3>Bucket Health</h3>
      <div class="list">
        <div *ngFor="let b of data?.buckets">
          <div style="display:flex;justify-content:space-between;margin-bottom:8px"><span>{{b.name}}</span><strong>{{b.score}}</strong></div>
          <div class="progress"><div [style.width.%]="b.score" [ngClass]="b.status + '-fill'"></div></div>
        </div>
      </div>
    </div>
  </div>
  <div class="grid-2">
    <div class="card"><h3>Trend</h3><p class="muted">Use Power BI or charting later for 6-month movement of Tier 0/1/2/3 apps by maturity.</p></div>
    <div class="card"><h3>Top Action Priorities</h3><div class="list"><div *ngFor="let p of data?.priorities" class="list-item">{{p}}</div></div></div>
  </div>`
})
class DashboardPage {
  private api = inject(ApiService);
  data?: DashboardData;
  constructor() { this.api.dashboard().subscribe(x => this.data = x); }
}

@Component({selector:'page-matrix', standalone:true, imports:[CommonModule], template:`
  <div class="header"><div><h1>Tier Matrix View</h1><p>Tier 0 / 1 / 2 / 3 applications versus maturity across core buckets.</p></div></div>
  <div class="card">
    <h3>Executive Matrix</h3>
    <table class="table"><thead><tr><th>Tier</th><th>Logs</th><th>Metrics</th><th>Tracing</th><th>Reliability</th><th>Security</th><th>Total</th></tr></thead>
    <tbody>
      <tr><td>Tier 0 Apps</td><td>92</td><td>85</td><td>80</td><td>88</td><td>90</td><td>89</td></tr>
      <tr><td>Tier 1 Apps</td><td>78</td><td>70</td><td>65</td><td>75</td><td>72</td><td>72</td></tr>
      <tr><td>Tier 2 Apps</td><td>60</td><td>55</td><td>48</td><td>62</td><td>58</td><td>56</td></tr>
      <tr><td>Tier 3 Apps</td><td>45</td><td>40</td><td>30</td><td>50</td><td>42</td><td>41</td></tr>
    </tbody></table>
  </div>`})
class MatrixPage {}

@Component({selector:'page-explorer', standalone:true, imports:[CommonModule], template:`
  <div class="header"><div><h1>Application Explorer</h1><p>Business area to repo drill-down with scan status, maturity, failed controls, and recommendations.</p></div></div>
  <div class="grid-2">
    <div class="card"><h3>Explorer Grid</h3><table class="table"><thead><tr><th>Business</th><th>Application</th><th>Service</th><th>Score</th><th>Risk</th></tr></thead><tbody><tr *ngFor="let row of rows"><td>{{row.business}}</td><td>{{row.application}}</td><td>{{row.service}}</td><td>{{row.score}}</td><td>{{row.risk}}</td></tr></tbody></table></div>
    <div class="card"><h3>Filters</h3><div class="list"><div class="list-item">Domain</div><div class="list-item">Business</div><div class="list-item">Tier</div><div class="list-item">Only failed controls</div></div></div>
  </div>`})
class ExplorerPage { private api=inject(ApiService); rows:any[]=[]; constructor(){this.api.explorer().subscribe(x=>this.rows=x);} }

@Component({selector:'page-domain', standalone:true, imports:[CommonModule], template:`<div class="header"><div><h1>Domain View · Pharmacy</h1><p>Roll up businesses, applications, and weak buckets inside the selected domain.</p></div></div><div class="grid-4"><div class="card kpi"><div class="label">Domain Score</div><div class="value">68</div></div><div class="card kpi"><div class="label">Businesses</div><div class="value">8</div></div><div class="card kpi"><div class="label">Applications</div><div class="value">36</div></div><div class="card kpi"><div class="label">Recommendations</div><div class="value">57</div></div></div><div class="card"><h3>Business Breakdown</h3><table class="table"><thead><tr><th>Business</th><th>Score</th><th>Top Gap</th></tr></thead><tbody><tr><td>Claims Adjudication</td><td>71</td><td>Architecture docs</td></tr><tr><td>PBM Pricing</td><td>63</td><td>Change linkage</td></tr></tbody></table></div>`})
class DomainPage {}

@Component({selector:'page-application', standalone:true, imports:[CommonModule], template:`<div class="header"><div><h1>Application View · PBM Hub</h1><p>Application-level maturity with services, repos, and top fixes.</p></div></div><div class="hero"><h2>Score 64 <span class="badge amber">Needs attention</span></h2><p>Major drag is architecture clarity and recovery continuity.</p></div><div class="grid-4"><div class="card kpi"><div class="label">Reliability</div><div class="value">62</div></div><div class="card kpi"><div class="label">Observability</div><div class="value">77</div></div><div class="card kpi"><div class="label">Engineering</div><div class="value">66</div></div><div class="card kpi"><div class="label">Architecture</div><div class="value">49</div></div></div>`})
class ApplicationPage {}

@Component({selector:'page-service', standalone:true, imports:[CommonModule], template:`<div class="header"><div><h1>Service View · Claims API</h1><p>Service health, failed controls, and dependency picture.</p></div></div><div class="grid-3"><div class="card"><h3>Logs</h3><div class="progress"><div class="green-fill" style="width:82%"></div></div></div><div class="card"><h3>Metrics</h3><div class="progress"><div class="amber-fill" style="width:67%"></div></div></div><div class="card"><h3>Tracing</h3><div class="progress"><div class="amber-fill" style="width:59%"></div></div></div></div><div class="grid-2"><div class="card"><h3>Failed Controls</h3><div class="list"><div class="list-item">REL-010 · Remote call timeouts not consistently configured</div><div class="list-item">TRC-002 · Trace context not injected on outbound requests</div></div></div><div class="card"><h3>Dependencies</h3><div class="list"><div class="list-item">Claims DB</div><div class="list-item">Member Auth Service</div><div class="list-item">Notification Queue</div></div></div></div>`})
class ServicePage {}

@Component({selector:'page-repo', standalone:true, imports:[CommonModule], template:`<div class="header"><div><h1>Repository View · claims-api-core</h1><p>Scanner evidence and exact control outcome source.</p></div></div><div class="grid-2"><div class="card"><h3>Scan Summary</h3><div class="list"><div class="list-item">Pass: 74</div><div class="list-item">Warning: 21</div><div class="list-item">Fail: 17</div></div></div><div class="card"><h3>Evidence</h3><table class="table"><thead><tr><th>Control</th><th>File</th><th>Line</th><th>Result</th></tr></thead><tbody><tr><td>LOG-003</td><td>src/api/Program.cs</td><td>42</td><td>PASS</td></tr><tr><td>REL-010</td><td>src/partner/PartnerGateway.cs</td><td>118</td><td>FAIL</td></tr></tbody></table></div></div>`})
class RepoPage {}

@Component({selector:'page-admin', standalone:true, imports:[CommonModule], template:`<div class="header"><div><h1>Admin Scan</h1><p>Queue scans, monitor long-running jobs, and persist normalized results to MySQL.</p></div></div><div class="grid-2"><div class="card"><h3>Trigger New Scan</h3><div class="list"><div class="list-item">Scope: Domain / Business / App / Service / Repo</div><div class="list-item">Mode: Quick / Deep / Program</div><div class="list-item">Version: v1</div></div></div><div class="card"><h3>Queue Status</h3><div class="list"><div class="list-item" *ngFor="let q of queue">{{q.name}} · {{q.status}} · {{q.progress}}%</div></div></div></div>`})
class AdminPage { private api=inject(ApiService); queue:any[]=[]; constructor(){this.api.queues().subscribe(x=>this.queue=x);} }

@Component({selector:'page-recommendations', standalone:true, imports:[CommonModule], template:`<div class="header"><div><h1>Recommendations</h1><p>Fix-first view showing expected uplift and suggested owner.</p></div></div><div class="card"><h3>Top Fixes</h3><div class="list"><div *ngFor="let r of rows" class="list-item"><strong>{{r.title}}</strong><div class="muted">{{r.owner}} · Uplift {{r.uplift}}</div></div></div></div>`})
class RecommendationsPage { private api=inject(ApiService); rows:any[]=[]; constructor(){this.api.recommendations().subscribe(x=>this.rows=x);} }

const routes: Routes = [
  { path: '', pathMatch: 'full', redirectTo: 'dashboard' },
  { path: 'dashboard', component: DashboardPage },
  { path: 'matrix', component: MatrixPage },
  { path: 'explorer', component: ExplorerPage },
  { path: 'domain/:id', component: DomainPage },
  { path: 'application/:id', component: ApplicationPage },
  { path: 'service/:id', component: ServicePage },
  { path: 'repo/:id', component: RepoPage },
  { path: 'admin-scan', component: AdminPage },
  { path: 'recommendations', component: RecommendationsPage },
];

bootstrapApplication(ShellComponent, { providers: [provideRouter(routes), provideHttpClient(), ApiService] });
