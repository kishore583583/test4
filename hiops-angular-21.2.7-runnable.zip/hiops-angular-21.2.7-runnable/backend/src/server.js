import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';

dotenv.config();
const app = express();
const port = Number(process.env.PORT || 3001);

app.use(cors());
app.use(express.json());

app.get('/api/health', (_req, res) => res.json({ status: 'ok' }));
app.get('/api/dashboard', (_req, res) => res.json({
  summary: { overallScore: 78, criticalGaps: 11, applicationsAssessed: 164, recommendations: 247, confidence: 84 },
  domains: [
    { id: 1, name: 'Claims', score: 82, riskLevel: 'Low' },
    { id: 2, name: 'Pharmacy', score: 68, riskLevel: 'High' },
    { id: 3, name: 'Digital', score: 87, riskLevel: 'Low' },
    { id: 4, name: 'Enrollment', score: 59, riskLevel: 'High' }
  ],
  bucketScores: [
    { name: 'Reliability & Operations', score: 74 },
    { name: 'Observability & Insights', score: 81 },
    { name: 'Engineering & Modernization', score: 69 },
    { name: 'Architecture & Business Context', score: 63 }
  ],
  trend: [58, 61, 64, 66, 71, 78]
}));
app.get('/api/applications', (_req, res) => res.json([
  { id: 1, domain: 'Pharmacy', name: 'PBM Hub', tier: 'T1', score: 64, riskLevel: 'High', repoCount: 11 },
  { id: 2, domain: 'Claims', name: 'Payment Edge', tier: 'T0', score: 74, riskLevel: 'Medium', repoCount: 6 },
  { id: 3, domain: 'Enrollment', name: 'Intake Flow', tier: 'T2', score: 58, riskLevel: 'High', repoCount: 3 },
  { id: 4, domain: 'Digital', name: 'Member Portal', tier: 'T0', score: 83, riskLevel: 'Low', repoCount: 8 }
]));
app.get('/api/recommendations', (_req, res) => res.json([
  { id: 1, title: 'Adopt structured JSON logging in 18 services', impact: 'High', ownerTeam: 'Engineering Enablement', details: 'Potential uplift +4.2 enterprise points' },
  { id: 2, title: 'Fill missing app-service-repo mappings', impact: 'High', ownerTeam: 'App Teams + Data Steward', details: 'Potential uplift +3.7 enterprise points' },
  { id: 3, title: 'Document upstream/downstream data flows', impact: 'Medium', ownerTeam: 'Solution Architects', details: 'Potential uplift +3.1 application points' }
]));
app.get('/api/scans/runs', (_req, res) => res.json([
  { id: 1, targetName: 'Claims API', scanMode: 'Deep', status: 'Running', progressPct: 62 },
  { id: 2, targetName: 'Enrollment Batch', scanMode: 'Quick', status: 'Queued', progressPct: 18 },
  { id: 3, targetName: 'Pharmacy', scanMode: 'Program', status: 'Completed', progressPct: 100 }
]));
app.post('/api/scans/queue', (req, res) => {
  res.status(201).json({
    id: Math.floor(Math.random() * 10000),
    targetName: req.body?.targetName || 'unknown-target',
    scanMode: req.body?.scanMode || 'Quick',
    status: 'Queued',
    progressPct: 0
  });
});

app.listen(port, () => console.log(`HiOps backend running on http://localhost:${port}`));
