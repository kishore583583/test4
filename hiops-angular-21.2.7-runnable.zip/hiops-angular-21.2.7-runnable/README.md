# HiOps Angular 21.2.7 + Node Starter

This is a corrected runnable starter with non-empty frontend files.

## Prerequisites
- Node.js 20+ or 22+
- npm 10+

## Run backend
```bash
cd backend
npm install
cp .env.example .env
npm run dev
```

## Run frontend
```bash
cd frontend
npm install
npm start
```

Frontend: http://localhost:4200  
Backend: http://localhost:3001
