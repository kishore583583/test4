import { Component } from '@angular/core';
import { RouterLink, RouterLinkActive, RouterOutlet } from '@angular/router';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet, RouterLink, RouterLinkActive],
  template: `
    <div class="page-shell">
      <aside class="sidebar">
        <div class="brand">HiOps<small>Reliability Intelligence Command Center</small></div>
        <div class="nav-title">Workspace</div>
        <a routerLink="/dashboard" routerLinkActive="active" class="nav-link">Executive Dashboard</a>
        <a routerLink="/tier-matrix" routerLinkActive="active" class="nav-link">Tier Matrix View</a>
        <a routerLink="/explorer" routerLinkActive="active" class="nav-link">Application Explorer</a>
        <a routerLink="/admin-scan" routerLinkActive="active" class="nav-link">Admin Scan</a>
        <a routerLink="/recommendations" routerLinkActive="active" class="nav-link">Recommendations</a>
      </aside>
      <main class="main">
        <router-outlet></router-outlet>
      </main>
    </div>
  `
})
export class AppComponent {}
