import { Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ApiService } from '../api.service';
import { toSignal } from '@angular/core/rxjs-interop';

@Component({
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="topbar"><div class="title"><h1>Application Explorer</h1><p>Filter across domain, business, application, service, and repo to isolate maturity gaps.</p></div><div class="chips"><div class="chip">Only failed controls</div><div class="chip">Criticality: Tier 1</div></div></div>
    <div class="card">
      <h3>Explorer Grid</h3>
      <table class="table">
        <thead><tr><th>Domain</th><th>Application</th><th>Tier</th><th>Score</th><th>Risk</th><th>Repos</th></tr></thead>
        <tbody><tr *ngFor="let a of apps()"><td>{{ a.domain }}</td><td>{{ a.name }}</td><td>{{ a.tier }}</td><td>{{ a.score }}</td><td>{{ a.riskLevel }}</td><td>{{ a.repoCount }}</td></tr></tbody>
      </table>
    </div>
  `
})
export class ExplorerPageComponent {
  private api = inject(ApiService);
  apps = toSignal(this.api.getApplications(), { initialValue: [] as any[] });
}
