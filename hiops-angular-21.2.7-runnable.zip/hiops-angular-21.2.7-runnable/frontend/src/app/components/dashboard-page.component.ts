import { Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ApiService } from '../api.service';
import { toSignal } from '@angular/core/rxjs-interop';

@Component({
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="topbar">
      <div class="title"><h1>Executive Dashboard</h1><p>Enterprise maturity at a glance with domain rollups, weak spots, and action priorities.</p></div>
      <div class="chips"><div class="chip">Version 1</div><div class="chip">Confidence: {{ data()?.summary?.confidence }}%</div></div>
    </div>
    <div class="hero"><h2>Enterprise Maturity Score: {{ data()?.summary?.overallScore }} <span class="badge green">Improving</span></h2><p>Single-screen command view for overall maturity, domain performance, top risks, trend movement, and highest-impact actions.</p></div>
    <div class="section grid-4">
      <div class="card kpi"><div class="label">Overall Maturity</div><div class="num">{{ data()?.summary?.overallScore }}</div></div>
      <div class="card kpi"><div class="label">Critical Gaps</div><div class="num">{{ data()?.summary?.criticalGaps }}</div></div>
      <div class="card kpi"><div class="label">Applications Assessed</div><div class="num">{{ data()?.summary?.applicationsAssessed }}</div></div>
      <div class="card kpi"><div class="label">Recommendations</div><div class="num">{{ data()?.summary?.recommendations }}</div></div>
    </div>
    <div class="section grid-2">
      <div class="card"><h3>Domain Heatmap</h3><div class="heatmap"><div class="heat" [class.h1]="d.score >= 85" [class.h2]="d.score >= 70 && d.score < 85" [class.h3]="d.score < 70" *ngFor="let d of data()?.domains">{{ d.name }}<strong>{{ d.score }}</strong><small>{{ d.riskLevel }}</small></div></div></div>
      <div class="card"><h3>Bucket Health</h3><div class="progress-wrap"><div class="progress-item" *ngFor="let b of data()?.bucketScores"><div class="row"><span>{{ b.name }}</span><strong>{{ b.score }}</strong></div><div class="progress-bar"><span [style.width.%]="b.score" [class.fill-green]="b.score >= 80" [class.fill-amber]="b.score >= 65 && b.score < 80" [class.fill-red]="b.score < 65"></span></div></div></div></div>
    </div>
    <div class="section card"><h3>Maturity Trend</h3><div class="sparkline"><div class="bar" *ngFor="let p of data()?.trend" [style.height.%]="p"></div></div></div>
  `
})
export class DashboardPageComponent {
  private api = inject(ApiService);
  data = toSignal(this.api.getDashboard(), { initialValue: null as any });
}
