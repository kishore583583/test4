import { Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ApiService } from '../api.service';
import { toSignal } from '@angular/core/rxjs-interop';

@Component({
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <div class="topbar"><div class="title"><h1>Admin Scan</h1><p>Queue scans, track long-running jobs, and store results into MySQL before the UI reads them back.</p></div></div>
    <div class="grid-2">
      <div class="card">
        <h3>Trigger New Scan</h3>
        <div class="list">
          <label>Target Type <input [(ngModel)]="form.targetType" /></label>
          <label>Target Name <input [(ngModel)]="form.targetName" /></label>
          <label>Scan Mode <input [(ngModel)]="form.scanMode" /></label>
          <button (click)="queue()">Queue Scan</button>
        </div>
      </div>
      <div class="card">
        <h3>Live Queue</h3>
        <div class="list">
          <div class="item" *ngFor="let r of runs()">{{ r.targetName }} · {{ r.scanMode }} · {{ r.status }} · {{ r.progressPct }}%</div>
        </div>
      </div>
    </div>
    <div class="section" *ngIf="message"><div class="card">{{ message }}</div></div>
  `
})
export class AdminScanPageComponent {
  private api = inject(ApiService);
  runs = toSignal(this.api.getScanRuns(), { initialValue: [] as any[] });
  message = '';
  form = { targetType: 'repository', targetName: 'pbm-api', scanMode: 'Quick' };

  queue() {
    this.api.queueScan(this.form).subscribe({
      next: (res) => this.message = `Queued scan #${res.id} for ${res.targetName}`,
      error: () => this.message = 'Failed to queue scan'
    });
  }
}
