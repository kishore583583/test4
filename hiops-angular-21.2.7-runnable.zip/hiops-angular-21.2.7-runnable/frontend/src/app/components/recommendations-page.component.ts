import { Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ApiService } from '../api.service';
import { toSignal } from '@angular/core/rxjs-interop';

@Component({
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="topbar"><div class="title"><h1>Recommendations</h1><p>Action-oriented view showing what to fix first, expected uplift, and owner guidance.</p></div></div>
    <div class="card"><h3>Recommendation Backlog</h3><table class="table"><thead><tr><th>Title</th><th>Impact</th><th>Owner</th><th>Details</th></tr></thead><tbody><tr *ngFor="let r of data()"><td>{{ r.title }}</td><td>{{ r.impact }}</td><td>{{ r.ownerTeam }}</td><td>{{ r.details }}</td></tr></tbody></table></div>
  `
})
export class RecommendationsPageComponent {
  private api = inject(ApiService);
  data = toSignal(this.api.getRecommendations(), { initialValue: [] as any[] });
}
