import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="topbar"><div class="title"><h1>Tier Matrix View</h1><p>Tier 0/1/2/3 applications versus maturity across executive buckets.</p></div></div>
    <div class="card">
      <h3>Application Maturity Matrix</h3>
      <table class="table">
        <thead><tr><th>Tier</th><th>Logs</th><th>Metrics</th><th>Tracing</th><th>Reliability</th><th>Security</th><th>Total</th></tr></thead>
        <tbody>
          <tr><td>Tier 0 Apps</td><td>93</td><td>85</td><td>82</td><td>92</td><td>70</td><td>88</td></tr>
          <tr><td>Tier 1 Apps</td><td>78</td><td>72</td><td>72</td><td>75</td><td>70</td><td>74</td></tr>
          <tr><td>Tier 2 Apps</td><td>62</td><td>57</td><td>48</td><td>66</td><td>58</td><td>58</td></tr>
          <tr><td>Tier 3 Apps</td><td>45</td><td>40</td><td>38</td><td>48</td><td>42</td><td>40</td></tr>
        </tbody>
      </table>
    </div>
  `
})
export class TierMatrixPageComponent {}
