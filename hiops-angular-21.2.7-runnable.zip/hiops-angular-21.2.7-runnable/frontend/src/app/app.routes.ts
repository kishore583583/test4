import { Routes } from '@angular/router';
import { DashboardPageComponent } from './components/dashboard-page.component';
import { TierMatrixPageComponent } from './components/tier-matrix-page.component';
import { ExplorerPageComponent } from './components/explorer-page.component';
import { AdminScanPageComponent } from './components/admin-scan-page.component';
import { RecommendationsPageComponent } from './components/recommendations-page.component';

export const routes: Routes = [
  { path: '', redirectTo: 'dashboard', pathMatch: 'full' },
  { path: 'dashboard', component: DashboardPageComponent },
  { path: 'tier-matrix', component: TierMatrixPageComponent },
  { path: 'explorer', component: ExplorerPageComponent },
  { path: 'admin-scan', component: AdminScanPageComponent },
  { path: 'recommendations', component: RecommendationsPageComponent }
];
