import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({ providedIn: 'root' })
export class ApiService {
  private http = inject(HttpClient);
  private baseUrl = 'http://localhost:3001/api';
  getDashboard() { return this.http.get<any>(`${this.baseUrl}/dashboard`); }
  getApplications() { return this.http.get<any[]>(`${this.baseUrl}/applications`); }
  getRecommendations() { return this.http.get<any[]>(`${this.baseUrl}/recommendations`); }
  getScanRuns() { return this.http.get<any[]>(`${this.baseUrl}/scans/runs`); }
  queueScan(payload: any) { return this.http.post<any>(`${this.baseUrl}/scans/queue`, payload); }
}
