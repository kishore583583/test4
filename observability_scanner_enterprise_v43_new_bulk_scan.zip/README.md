# Observability Scanner Enterprise v7

Adds:
- SQLite persistence
- portfolio landscape homepage
- tier assignment after scan
- inferred tier detection from repository hints
- database configuration page
- Excel export endpoint

## Run
```bash
pip install -r requirements.txt
uvicorn scanner_server:app --reload
```

Open:
http://127.0.0.1:8000

## Notes
- SQLite file is `assessments.db`
- Exported workbook is `observability_landscape.xlsx`
- Private Azure DevOps repos usually need a PAT

## v8 additions
- dashboard charts for maturity, tiers, buckets, and gaps
- service topology and service heatmap on details page
- Excel export includes service heatmap sheet

## v9 configuration update
- user-friendly configuration page with toggles and weight sliders
- scanner writes/reads scanner_config.json
- Python reacts to enabled buckets and configured weights during scan

## v10 enterprise batch scan
- enterprise scan page for admin-managed repository inventory
- sequential or controlled parallel multi-scan runner
- progress bar and per-repository status grid
- token alias support in settings for Azure-based bulk scanning
- still no external Azure discovery API dependency in the current app

## v11 audits and history
- audit & history page with scan run timeline
- application scan history with score deltas
- last scan summary and freshness indicators
- scan runs persisted in database for enterprise audits

## v11.1 UI fix
- fixed overlap in Assessment Details > Bucket Overview cards
- responsive bucket grid
- long sample file names now wrap safely

## v11.2 topology and heatmap fix
- topology now shows only explicitly detected services
- removed guessed/fallback services from details view
- service heatmap rows are clickable
- added Selected Service Details panel in Assessment Details

## v12 UI corrections
- restored clean white results style
- bucket overview uses white cards with subtle score-based color accents
- added KPI cards for score, signals, services, and vendor tools
- wrapped long metadata values and sample files safely

## v12.1 decluttered results
- simplified assessment details to reduce congestion
- topology/heatmap minimized into optional service insights summary
- KPI cards tightened and metadata wrapped more cleanly
- results page kept clean white style with subtle status accents

## v12.2 settings and UI improvements
- settings page now supports bucket thresholds: loose / normal / strict
- Python scoring reacts to thresholds as well as enabled flags and weights
- configuration save flow hardened so UI does not stop on save issues
- lighter multi-pastel UI replaces the pale green feel

## v12.3 glass style
- Apple-inspired glassmorphism UI refresh
- top menu changed from bubble buttons to a cleaner text nav with underline active state
- lighter translucent cards across the app

## v12.4 hyperlinks and heatmap details
- restored clickable service heatmap in assessment details
- added heatmap details panel on row click
- repository fields now render as hyperlinks where relevant

## v12.5 hyperlink fix
- repository hyperlinks now stop parent card click interception
- links open correctly from application cards, summary panels, and enterprise scan grids

## v12.6 button/link fix
- fixed JavaScript syntax error in config merge logic that was breaking all buttons and links
- validated static/app.js with node --check

## v13 professional layout refresh
- bucket overview now uses a clean 3-card layout per row when space allows
- bucket cards are clickable and open a bucket drilldown panel
- service heatmap is full width and bubble-clickable with heatmap detail panel
- reduced noisy explanatory text and trimmed long metadata lists
- improved spacing to prevent overlaps and squeezed cards

## v13.1 documentation menu
- restored Documentation menu item
- added documentation page covering methodology, scoring, maturity levels, and usage guidance

## v13.2 clickable colorful cards
- KPI cards, dashboard cards, chart rows, bucket cards, and documentation cards now feel clickable
- added functional click behavior for dashboard and documentation detail panels
- improved colorful accents without making the UI noisy

## v14 landing page refresh
- redesigned dashboard landing page in a Humana-inspired light green analytics style
- added recent scan activity and recommended focus area panels
- improved hero, KPI cards, and overall landing page polish

## v14.1 dark mode refinement
- dark mode refreshed to a Webull-like darker trading dashboard feel
- icon-only appearance toggle button
- improved palette consistency between light and dark modes

## v15 Humana metadata and layout refresh
- scanner now parses Humana-style asset.yml / asset.yaml for application names, AppService IDs, BusinessService IDs, technologies, and change template IDs
- detected metadata is moved lower on the page and rendered as structured cards instead of noisy text
- assessment details and applications layouts were widened and decongested to avoid overlapping cards
- landing page copy shortened and dashboard activity/recommendation panels made more infographic-like


## v18.2 fixes
- fixed enterprise scan text overflow in inventory preview
- restored simple database setup visibility in Administration
- added export of previous runs as Excel-compatible CSV


## v18.3 batch flow fix
- fixed enterprise scan text overlap in preview and status cards
- batch scan now focuses the current execution panel after start
- added current repository execution card so users can watch repositories move one by one
- token values are masked in preview/status for readability


## v18.4 assessment details redesign
- assessment details page now starts with an expandable application register table for all scanned repos
- reduced top white space by replacing the old tall summary area with compact KPI cards
- each application row can expand to show metadata, services/tools, and bucket summaries
- one click loads any scanned application into the deep details view below


## v19 parallel batch dashboard
- redesigned Enterprise Scan into a live parallel dashboard
- shows running scans, queued repos, completed scans, and expandable results on the same screen
- added KPI strip for total/running/completed/queued/average score
- settings moved to the far right of the main navigation


## v21 scans register page
- Applications page redesigned into an expandable scanned applications register
- export full register to Excel-compatible CSV
- each row expands to show all identified metadata from the last scan
- one click loads any scanned application into the deep details page


## v22 dual scanner profiles
- added Scanner 1 and Scanner 2 profile selection in Live Scan and Enterprise Scan
- Scanner 2 introduces the revised capability grid and final observability verdict model
- HTML results now show scanner profile, scanner 2 verdict, and grouped control summaries when Scanner 2 is used
- documentation updated to explain both scanner models and revised checklist controls


## v23 profile naming update
- scanner dropdown labels changed to OBS Industry and OBS Custom in live scan and enterprise scan
- documentation and results labels updated to match the new profile names


## v24 scanner flow fix
- fixed single scan so the selected scanner profile is passed to the backend process
- fixed enterprise scan so OBS Industry / OBS Custom is sent from the UI and preserved for every batch item
- batch status cards now show which profile each repository is using


## v25 code clarity and documentation depth
- added reviewer-friendly docstrings/comments to the Python scanner so the intent of each scan profile is clearer during code review
- expanded documentation into three layers: whole-level scanner overview, OBS Industry model, and OBS Custom model
- documentation now explains what each model scans, what outputs it produces, and how reviewers should interpret the result structures


## v26 batch verification fix
- fixed single scan request model so scanner profile selection works reliably
- fixed enterprise scan payload propagation so each queued repo preserves OBS Industry / OBS Custom
- added batch artifact exports by scan_run_id: summary CSV, details CSV, and holistic JSON report


## v27 demo menu controls and scan report exports
- added Settings control to toggle top menu pages on/off for demos
- added holistic CSV export for all scans
- added per-scan CSV export from the scans register expanded row
- backend report endpoints now produce audit-style CSV output for single scans and holistic register exports


## v28 scanner registry and visibility
- added Administration > Scanner Registry to control which scanners appear in dropdowns
- any additional python scanner dropped into the scanners folder is discovered automatically and shown in the registry
- live scan and enterprise scan dropdowns now load from the visible scanner registry instead of a hard-coded list


## v32 scanner dropdown and registry fix
- scanner dropdowns are now always visible in Live Scan and Enterprise Scan with fallback options
- Administration includes Scanner Registry to enable/disable scanners from dropdowns
- registry loading failure no longer hides the scanner selector


## v33 detection quality fix
- stricter service id validation: APP/APPSVC identifiers must be at least 12 characters and test/mock/sample values are ignored
- vendor detection is now stricter and ignores documentation/test/example files to reduce false Splunk/Dynatrace positives
- service heatmap is now evidence-based instead of synthetic/randomized
- bucket and heatmap details now show Not detected when evidence is absent and include technology/evidence context where available


## v34 evidence drilldown and bucket colors
- bucket cards are now explicitly clickable and auto-open the first bucket detail
- bucket details now explain why a bucket is green, amber, or red and list matched evidence files/patterns
- bucket colors are stricter: no evidence = red, partial evidence = amber, strong repeated evidence = green


## v35 post-scan tile drilldown
- top post-scan KPI tiles are now clickable and open deep drilldown details
- scanner output now includes bucket score details explaining evidence count, target threshold, points used, and score contribution
- bucket detail panels now use scanner-produced explanations so the UI reflects actual scoring logic instead of generic text


## v36 evidence click details
- top post-scan tiles now open scanner-backed detail panels
- heatmap bubble clicks now show evidence detail cards
- bucket drilldowns now include score mechanics, target evidence, raw points, and why-counted explanations


## v37 FIFO queue scan page
- added a new Queue Scan page that processes repositories one by one in FIFO order
- queue scan behaves like a live scan screen, showing the current repository logs and moving completed results into a table below
- supports comma-separated application/repo/token input and scanner selection


## v39 multi scan sequential page
- removed old Enterprise Scan and Queue Scan pages from navigation
- added a brand new Multi Scan page for sequential FIFO processing and per-repository saving
- multi scan shows the current repository live, waiting queue, and completed rows with saved status


## v40 clean documentation
- replaced older documentation content with a clean explanation of actual scanner logic
- documents the execution flow, regex signal families, service and vendor detection, scoring, bucket colors, and UI evidence mapping


## v41 live scan bulk
- added a new Live Scan Bulk page that follows the single live scan pattern but processes multiple repositories sequentially
- each completed repository is auto-saved when enabled and gets a saved checkmark in the completed table


## v43 new bulk scan enterprise layout
- added a new bulk scan page inspired by a multi-repository console layout
- supports paste input, sequential scanning, current finding panel, repo tree, progress table, and export report
- uses the same saved assessment register as the single live scan flow when auto-save is enabled
