Drop additional scanner Python scripts into this folder.
Each script should accept: <repo_input> <token> [scanner_id]
and emit a final [DONE] JSON line compatible with the application.
