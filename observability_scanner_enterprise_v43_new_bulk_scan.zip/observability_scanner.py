"""Observability scanner entrypoint.

This module supports two scan profiles:
1. scanner_v1 / OBS Industry
   - standard observability maturity scan
   - broad signal detection across logging, metrics, tracing, health, resilience, configuration, governance, and vendor tooling
2. scanner_v2 / OBS Custom
   - revised compliance-oriented scan
   - evaluates repository discovery, routing, ingestion, logging controls, metadata structure, security, signals, and governance

The code is organized so a reviewer can understand:
- what is being scanned
- how signals are grouped
- how evidence becomes bucket outcomes
- how final summaries are produced for the HTML application
"""

import sys
import os
import re
import json
import time
import shutil
import tempfile
import subprocess
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor, as_completed
from urllib.parse import quote

DEFAULT_CONFIG_PATH = Path(__file__).with_name('scanner_config.json')

EXCLUDE_DIRS = {
    ".git", "node_modules", "dist", "build", "bin", "obj", "venv", ".venv",
    "__pycache__", "target", ".idea", ".vs", ".next", ".nuxt", ".terraform"
}
TEXT_EXTENSIONS = {
    ".py", ".js", ".ts", ".tsx", ".jsx", ".java", ".cs", ".go", ".rb", ".php",
    ".json", ".yml", ".yaml", ".xml", ".properties", ".env", ".ini", ".cfg",
    ".toml", ".md", ".txt", ".sh", ".ps1", ".sql", ".html", ".htm"
}
MAX_FILE_SIZE = 1024 * 1024 * 2

BUCKETS = {
    "logging": {"weight": 15, "title": "Logging Standards"},
    "metrics": {"weight": 15, "title": "Metrics & SLI Signals"},
    "tracing": {"weight": 15, "title": "Distributed Tracing"},
    "health": {"weight": 15, "title": "Health & Readiness"},
    "resilience": {"weight": 10, "title": "Operational Resilience"},
    "config": {"weight": 10, "title": "Observability Configuration"},
    "governance": {"weight": 10, "title": "Governance & Standards"},
    "cloud_observability": {"weight": 10, "title": "Cloud & Vendor Observability"},
}

PATTERNS = {
    "logging": [
        r"\blogging\b", r"\blogger\b", r"\bserilog\b", r"\bstructlog\b",
        r"\blog4j\b", r"\bslf4j\b", r"\bwinston\b", r"\bpino\b", r"\bilogger\b",
        r"jsonformatter", r"structured"
    ],
    "metrics": [
        r"\bprometheus\b", r"\bmicrometer\b", r"\bmetrics\b", r"meterregistry",
        r"counter\(", r"histogram", r"summary", r"gauge\(", r"request_duration"
    ],
    "tracing": [
        r"opentelemetry", r"\btrace\b", r"tracerprovider", r"jaeger",
        r"zipkin", r"applicationinsights", r"traceparent", r"correlation-id",
        r"activitysource", r"span"
    ],
    "health": [
        r"/health", r"/ready", r"/live", r"healthcheck", r"healthchecks",
        r"readiness", r"liveness", r"actuator/health"
    ],
    "resilience": [
        r"\bretry\b", r"circuit.?breaker", r"\btimeout\b", r"dead.?letter",
        r"\bdlq\b", r"fallback", r"bulkhead", r"polly", r"resilience4j"
    ],
    "config": [
        r"otel_", r"log_level", r"logging.level", r"exporter",
        r"applicationinsights", r"connectionstring", r"monitoring",
        r"telemetry", r"instrumentationkey"
    ],
    "governance": [
        r"runbook", r"observability", r"owner", r"team", r"support",
        r"slo", r"sli", r"oncall", r"alerting"
    ],
    "cloud_observability": [
        r"azuremonitor", r"applicationinsights", r"monitor\.opentelemetry",
        r"awsxray", r"cloudwatch", r"stackdriver", r"google_cloud",
        r"datadog", r"newrelic", r"grafana", r"splunk", r"dynatrace", r"appdynamics",
        r"elastic apm", r"sumologic", r"loki", r"promtail", r"honeycomb"
    ],
}

VENDOR_PATTERNS = {
    "Azure Monitor": [r"azuremonitor", r"monitor\.opentelemetry"],
    "Application Insights": [r"applicationinsights", r"instrumentationkey"],
    "Datadog": [r"datadog"],
    "New Relic": [r"newrelic"],
    "Grafana": [r"grafana"],
    "Splunk": [r"splunk"],
    "Dynatrace": [r"dynatrace"],
    "AppDynamics": [r"appdynamics"],
    "Elastic APM": [r"elastic apm", r"elasticapm"],
    "Loki": [r"\bloki\b"],
    "Promtail": [r"promtail"],
    "Jaeger": [r"jaeger"],
    "Zipkin": [r"zipkin"],
    "CloudWatch": [r"cloudwatch"],
    "AWS X-Ray": [r"awsxray", r"x-ray"],
    "Stackdriver": [r"stackdriver", r"google_cloud"]
}

SERVICE_ID_PATTERNS = [
    r"service[_\- ]?id['\"\s:=]+([A-Za-z0-9._\-\/]+)",
    r"service[_\- ]?name['\"\s:=]+([A-Za-z0-9._\-\/]+)",
    r"application[_\- ]?name['\"\s:=]+([A-Za-z0-9._\-\/]+)",
    r"app[_\- ]?name['\"\s:=]+([A-Za-z0-9._\-\/]+)",
    r"OTEL_SERVICE_NAME['\"\s:=]+([A-Za-z0-9._\-\/]+)",
]

TIER_PATTERNS = {
    "T1": [r"tier[_\-\s]?1", r"criticality[_\-\s]?:?\s*high", r"mission[_\-\s]?critical", r"platinum"],
    "T2": [r"tier[_\-\s]?2", r"criticality[_\-\s]?:?\s*medium", r"gold"],
    "T3": [r"tier[_\-\s]?3", r"silver"],
    "T4": [r"tier[_\-\s]?4", r"bronze", r"low[_\-\s]?criticality"],
}

STACK_HINTS = {
    "Python": ["requirements.txt", "pyproject.toml", "setup.py", ".py", "manage.py", "main.py", "app.py"],
    ".NET": [".csproj", "Program.cs", "Startup.cs", "appsettings.json"],
    "Angular": ["angular.json", "src/main.ts", "app.module.ts"],
    "Node": ["package.json", "server.js", "app.js", ".js", ".ts"],
    "Java": ["pom.xml", "build.gradle", ".java", "application.yml", "application.yaml"],
    "Kubernetes": ["deployment.yaml", "deployment.yml", "values.yaml", "Chart.yaml", "Dockerfile"],
}

ARCHETYPE_RULES = {
    "Frontend Web App": [r"angular\.json", r"react", r"vue", r"src/main\.ts", r"app\.module\.ts"],
    "Backend API / Microservice": [r"controller", r"fastapi", r"flask", r"springboot", r"route\(", r"mapget", r"minimalapi"],
    "Batch / Scheduled Job": [r"cron", r"schedule", r"airflow", r"job", r"quartz"],
    "Worker / Queue Consumer": [r"consumer", r"kafka", r"rabbitmq", r"sqs", r"servicebus"],
    "Data Pipeline / ETL Job": [r"spark", r"databricks", r"etl", r"pipeline", r"dag"],
}

def load_runtime_bucket_config():
    config_buckets = {}
    try:
        if DEFAULT_CONFIG_PATH.exists():
            with open(DEFAULT_CONFIG_PATH, "r", encoding="utf-8") as fh:
                raw = json.load(fh)
                config_buckets = (raw or {}).get("buckets", {}) or {}
    except Exception:
        config_buckets = {}

    effective = {}
    for bucket_name, meta in BUCKETS.items():
        user_meta = config_buckets.get(bucket_name, {}) or {}
        enabled = bool(user_meta.get("enabled", True))
        weight = float(user_meta.get("weight", meta["weight"]))
        threshold = str(user_meta.get("threshold", "normal")).lower()
        if threshold not in {"loose", "normal", "strict"}:
            threshold = "normal"
        effective[bucket_name] = {
            "weight": weight,
            "title": meta["title"],
            "enabled": enabled,
            "threshold": threshold
        }
    return effective

RUNTIME_BUCKETS = load_runtime_bucket_config()

def enabled_patterns():
    return {k: v for k, v in PATTERNS.items() if RUNTIME_BUCKETS.get(k, {}).get("enabled", True)}

def log(tag, msg):
    print(f"[{tag}] {msg}", flush=True)

def fail_and_exit(msg, code=1):
    log("FAIL", msg)
    sys.exit(code)

def is_remote_repo(value: str) -> bool:
    v = value.lower()
    return v.startswith("http://") or v.startswith("https://") or v.startswith("git@")

def inject_auth(repo_url: str, token: str) -> str:
    if not token:
        return repo_url
    if repo_url.startswith("https://github.com/"):
        return repo_url.replace("https://", f"https://{quote(token, safe='')}@")
    if "dev.azure.com" in repo_url and repo_url.startswith("https://"):
        return repo_url.replace("https://", f"https://anything:{quote(token, safe='')}@")
    return repo_url

def prepare_repo(repo_input: str, token: str):
    if os.path.isdir(repo_input):
        log("STAGE", "Local repository path detected")
        return repo_input, False
    if not is_remote_repo(repo_input):
        fail_and_exit(f"Repository path does not exist and is not a supported URL: {repo_input}")
    log("STAGE", "Remote repository URL detected")
    temp_dir = tempfile.mkdtemp(prefix="obs_scan_")
    auth_url = inject_auth(repo_input, token)
    log("INFO", "Cloning repository into temporary workspace")
    try:
        result = subprocess.run(
            ["git", "clone", "--depth", "1", auth_url, temp_dir],
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            timeout=240,
            check=False
        )
    except FileNotFoundError:
        shutil.rmtree(temp_dir, ignore_errors=True)
        fail_and_exit("git is not installed or not available on PATH")
    except subprocess.TimeoutExpired:
        shutil.rmtree(temp_dir, ignore_errors=True)
        fail_and_exit("Repository clone timed out")
    if result.returncode != 0:
        shutil.rmtree(temp_dir, ignore_errors=True)
        output = (result.stdout or "").strip()
        fail_and_exit(f"Repository clone failed: {output[:1000]}")
    log("PASS", "Repository cloned successfully")
    return temp_dir, True

def collect_repo_index(repo_path: str):
    all_files = []
    for root, dirs, files in os.walk(repo_path):
        dirs[:] = [d for d in dirs if d not in EXCLUDE_DIRS]
        for f in files:
            rel = os.path.relpath(os.path.join(root, f), repo_path)
            all_files.append(rel.replace("\\", "/"))
    return all_files

def detect_stack(all_files):
    lowered = [f.lower() for f in all_files]
    matches = {}
    for stack, hints in STACK_HINTS.items():
        score = 0
        for hint in hints:
            h = hint.lower()
            if h.startswith("."):
                score += sum(1 for f in lowered if f.endswith(h))
            else:
                score += sum(1 for f in lowered if h in f)
        if score:
            matches[stack] = score
    if not matches:
        return "Unknown", matches
    return max(matches, key=matches.get), matches

def detect_archetype(all_files):
    lowered_blob = "\n".join(f.lower() for f in all_files[:5000])
    scores = {}
    for label, rules in ARCHETYPE_RULES.items():
        score = sum(1 for r in rules if re.search(r, lowered_blob, re.IGNORECASE))
        if score:
            scores[label] = score
    if not scores:
        return "General Application", scores
    return max(scores, key=scores.get), scores

def detect_tier(all_files, repo_path):
    candidate_files = all_files[:200]
    scores = {"T1": 0, "T2": 0, "T3": 0, "T4": 0}
    for rel in candidate_files:
        p = os.path.join(repo_path, rel.replace("/", os.sep))
        try:
            with open(p, "r", encoding="utf-8", errors="ignore") as fh:
                content = fh.read().lower()
        except Exception:
            continue
        for tier, rules in TIER_PATTERNS.items():
            scores[tier] += sum(1 for r in rules if re.search(r, content, re.IGNORECASE))
    best = max(scores, key=scores.get)
    return (best if scores[best] > 0 else ""), scores

def iter_candidate_files(repo_path: str):
    files = []
    for root, dirs, filenames in os.walk(repo_path):
        dirs[:] = [d for d in dirs if d not in EXCLUDE_DIRS]
        for name in filenames:
            p = os.path.join(root, name)
            ext = Path(name).suffix.lower()
            try:
                if os.path.getsize(p) > MAX_FILE_SIZE:
                    continue
            except OSError:
                continue
            if ext in TEXT_EXTENSIONS or name.lower() in {
                "dockerfile", "readme", "readme.md", "chart.yaml",
                "values.yaml", "requirements.txt", "package.json", "pom.xml",
                "build.gradle", "appsettings.json", "application.yml", "application.yaml"
            }:
                files.append(p)
    return files

def score_signal_severity(bucket, matched_patterns):
    if bucket in {"tracing", "metrics", "cloud_observability"} and len(matched_patterns) >= 2:
        return "green"
    if len(matched_patterns) >= 1:
        return "amber"
    return "red"

def _dedupe_keep_order(values):
    out = []
    seen = set()
    for v in values:
        vv = str(v or "").strip()
        if not vv:
            continue
        key = vv.lower()
        if key not in seen:
            out.append(vv)
            seen.add(key)
    return out

def is_valid_humana_service_id(value: str):
    """Validate service identifiers more strictly.

    Rules:
    - APP / APPSVC style IDs should be at least 12 characters long
    - ignore obvious test / testcase / mock / sample style identifiers
    - reject values that look like variable references or paths
    """
    v = str(value or "").strip()
    if not v:
        return False
    lower = v.lower()
    invalid_prefixes = (
        "this.", "result.", "response.", "null", "class", "string", "map", "set", "sets",
        "value.", "item.", "data.", "props.", "state.", "e.", "obj.", "arr."
    )
    invalid_words = ("test", "tests", "testcase", "spec", "mock", "sample", "dummy", "fixture")
    if any(lower.startswith(p) for p in invalid_prefixes):
        return False
    if any(word in lower for word in invalid_words):
        return False
    if "." in v and not re.fullmatch(r"[A-Za-z0-9_.\-]+", v):
        return False
    if "/" in v or "\\" in v:
        return False
    upper = v.upper()
    if upper.startswith("APP") or upper.startswith("APPSVC"):
        return len(v) >= 12 and bool(re.fullmatch(r"[A-Za-z0-9_-]+", v))
    if upper.startswith(("BSV", "SVC", "API")):
        return len(v) >= 6 and bool(re.fullmatch(r"[A-Za-z0-9_-]+", v))
    if re.match(r"^[A-Z]{2,}[A-Z0-9_-]{5,}$", v):
        return True
    return False
    lower = v.lower()
    invalid_prefixes = (
        "this.", "result.", "response.", "null", "class", "string", "map", "set", "sets",
        "value.", "item.", "data.", "props.", "state.", "e.", "obj.", "arr."
    )
    if any(lower.startswith(p) for p in invalid_prefixes):
        return False
    if "." in v and not re.fullmatch(r"[A-Za-z0-9_.\-]+", v):
        return False
    if "/" in v or "\\" in v:
        return False
    if re.match(r"^(APP|APPSVC|BSV|SVC|API)[A-Za-z0-9_-]{3,}$", v, re.IGNORECASE):
        return True
    if re.match(r"^[A-Z]{2,}[A-Z0-9_-]{3,}$", v):
        return True
    return False

def parse_asset_metadata(content: str, rel_path: str):
    meta = {
        "asset_files": [],
        "application_names": [],
        "app_service_ids": [],
        "business_service_ids": [],
        "technologies": [],
        "change_template_ids": [],
        "service_record_types": []
    }
    lower_rel = rel_path.lower()
    if not (lower_rel.endswith("asset.yml") or lower_rel.endswith("asset.yaml") or "asset" in lower_rel):
        return meta

    meta["asset_files"].append(rel_path)

    # common yaml patterns seen in Humana asset files
    for rx in [
        r"applicationName\s*:\s*([A-Za-z0-9_.\-]+)",
        r"app[_\- ]?name\s*:\s*([A-Za-z0-9_.\-]+)",
    ]:
        meta["application_names"].extend(re.findall(rx, content, re.IGNORECASE))

    # ids after typed records
    type_id_matches = list(re.finditer(r"type\s*:\s*(AppService|Application|Component|BusinessService)\s*[\r\n]+(?:[^\S\r\n]*[#-].*[\r\n]+)?[^\S\r\n]*id\s*:\s*([A-Za-z0-9_-]+)", content, re.IGNORECASE))
    for m in type_id_matches:
        t = m.group(1)
        ident = m.group(2)
        meta["service_record_types"].append(t)
        if re.match(r"AppService", t, re.IGNORECASE):
            meta["app_service_ids"].append(ident)
        elif re.match(r"BusinessService", t, re.IGNORECASE):
            meta["business_service_ids"].append(ident)
        else:
            if is_valid_humana_service_id(ident):
                meta["app_service_ids"].append(ident)

    # fallback generic ids in asset files
    for rx in [
        r"\bid\s*:\s*((?:APP|APPSVC|BSV|SVC|API)[A-Za-z0-9_-]{3,})",
        r"\bservice[_\- ]?id\s*:\s*((?:APP|APPSVC|BSV|SVC|API)[A-Za-z0-9_-]{3,})",
        r"\bchangeTemplateId\s*:\s*([A-Za-z0-9_.\-]+)",
        r"\btechnology\s*:\s*([A-Za-z0-9_.\-]+)",
    ]:
        hits = re.findall(rx, content, re.IGNORECASE)
        if "changeTemplateId" in rx:
            meta["change_template_ids"].extend(hits)
        elif "technology" in rx:
            meta["technologies"].extend(hits)
        else:
            for ident in hits:
                if ident.upper().startswith("BSV"):
                    meta["business_service_ids"].append(ident)
                else:
                    meta["app_service_ids"].append(ident)

    for k in list(meta.keys()):
        meta[k] = _dedupe_keep_order(meta[k])[:20]
    return meta

def merge_asset_metadata(meta_items):
    merged = {
        "asset_files": [],
        "application_names": [],
        "app_service_ids": [],
        "business_service_ids": [],
        "technologies": [],
        "change_template_ids": [],
        "service_record_types": []
    }
    for item in meta_items:
        for k in merged.keys():
            merged[k].extend(item.get(k, []))
    for k in list(merged.keys()):
        merged[k] = _dedupe_keep_order(merged[k])[:20]
    return merged

def extract_service_ids(content):
    values = []
    for rx in SERVICE_ID_PATTERNS:
        for m in re.finditer(rx, content, re.IGNORECASE):
            val = m.group(1).strip(" '\"")
            if 6 <= len(val) <= 80 and is_valid_humana_service_id(val):
                values.append(val)
    deduped = _dedupe_keep_order(values)
    return deduped[:12]

def detect_vendors(lowered, rel_path: str):
    """Detect vendor tools only from stronger operational/config evidence.

    Avoid counting vendor names from documentation, test content, screenshots,
    or generic narrative text.
    """
    rel_lower = rel_path.lower()
    doc_like = rel_lower.endswith((".md", ".txt")) or any(x in rel_lower for x in ("readme", "docs/", "/docs", "test", "tests", "__tests__", "spec", "example", "sample"))
    if doc_like:
        return []

    found = []
    for vendor, rules in VENDOR_PATTERNS.items():
        for rx in rules:
            if re.search(rf"\b(?:{rx})\b", lowered, re.IGNORECASE):
                found.append(vendor)
                break
    return found

def scan_file(path: str, repo_path: str):
    rel = os.path.relpath(path, repo_path).replace("\\", "/")
    try:
        with open(path, "r", encoding="utf-8", errors="ignore") as fh:
            content = fh.read()
    except Exception:
        return {"path": rel, "matches": {}, "service_ids": [], "vendors": [], "error": True}
    lowered = content.lower()
    matches = {}
    for bucket, regexes in enabled_patterns().items():
        hit_patterns = []
        for rx in regexes:
            if re.search(rx, lowered, re.IGNORECASE):
                hit_patterns.append(rx)
        if hit_patterns:
            matches[bucket] = hit_patterns[:4]
    asset_meta = parse_asset_metadata(content, rel)
    service_ids = extract_service_ids(content)
    if asset_meta.get("app_service_ids"):
        service_ids = _dedupe_keep_order(asset_meta.get("app_service_ids", []) + service_ids)
    if asset_meta.get("business_service_ids"):
        service_ids = _dedupe_keep_order(service_ids + asset_meta.get("business_service_ids", []))
    return {
        "path": rel,
        "matches": matches,
        "service_ids": service_ids,
        "asset_meta": asset_meta,
        "vendors": detect_vendors(lowered, rel),
        "error": False
    }

def scan_repository(repo_path: str):
    files = iter_candidate_files(repo_path)
    findings = {k: [] for k, v in RUNTIME_BUCKETS.items() if v.get('enabled', True)}
    files_scanned = 0
    errors = 0
    service_ids = []
    vendor_tools = []
    asset_meta_items = []
    log("INFO", f"Candidate files selected for scan: {len(files)}")
    workers = min(16, max(4, (os.cpu_count() or 4)))
    with ThreadPoolExecutor(max_workers=workers) as ex:
        future_map = {ex.submit(scan_file, p, repo_path): p for p in files}
        for idx, fut in enumerate(as_completed(future_map), start=1):
            result = fut.result()
            files_scanned += 1
            if result.get("error"):
                errors += 1
            for sid in result.get("service_ids", []):
                if sid not in service_ids:
                    service_ids.append(sid)
                    log("INFO", f"Service ID candidate detected: {sid}")
            asset_meta_items.append(result.get("asset_meta", {}) or {})
            for vendor in result.get("vendors", []):
                if vendor not in vendor_tools:
                    vendor_tools.append(vendor)
                    log("INFO", f"Vendor observability tool detected: {vendor}")
            for bucket, hit_patterns in result["matches"].items():
                severity = score_signal_severity(bucket, hit_patterns)
                findings[bucket].append({
                    "file": result["path"],
                    "patterns": hit_patterns,
                    "severity": severity
                })
                tag = "PASS" if severity == "green" else "WARN"
                log(tag, f"{bucket} signal found in {result['path']}")
            if idx % 100 == 0:
                log("INFO", f"Scanned {idx}/{len(files)} files")
    merged_asset_meta = merge_asset_metadata(asset_meta_items)
    preferred_service_ids = _dedupe_keep_order(merged_asset_meta.get("app_service_ids", []) + merged_asset_meta.get("business_service_ids", []) + service_ids)
    return findings, files_scanned, errors, preferred_service_ids[:20], vendor_tools, merged_asset_meta

def score_bucket(count: int, weight: float, threshold: str = "normal"):
    target_map = {
        "loose": 3.0,
        "normal": 5.0,
        "strict": 7.0
    }
    target = target_map.get(str(threshold).lower(), 5.0)
    evidence_points = min(float(count), target)
    return round((evidence_points / target) * weight, 2)

def explain_bucket_score(bucket: str, count: int, weight: float, threshold: str = "normal"):
    target_map = {
        "loose": 3.0,
        "normal": 5.0,
        "strict": 7.0
    }
    target = target_map.get(str(threshold).lower(), 5.0)
    evidence_points = min(float(count), target)
    score = round((evidence_points / target) * weight, 2)
    if count <= 0:
        rating = "red"
        reason = "No matching evidence was detected for this bucket."
    elif count < target * 0.5:
        rating = "amber"
        reason = "Some evidence was detected, but the bucket is still partial because the evidence count is below the threshold for strong coverage."
    else:
        rating = "green" if count >= target else "amber"
        reason = "Repeated evidence was detected for this bucket and the score reflects how close the evidence count is to the configured target."
    return {
        "bucket": bucket,
        "count": int(count),
        "weight": float(weight),
        "threshold": str(threshold),
        "target_evidence": float(target),
        "evidence_points_used": float(evidence_points),
        "score": float(score),
        "rating": rating,
        "reason": reason,
    }

def maturity_label(score: int):
    if score < 25:
        return "L1"
    if score < 50:
        return "L2"
    if score < 75:
        return "L3"
    return "L4"

def recommendations(findings, vendor_tools):
    recs = []
    if "logging" in findings and not findings["logging"]:
        recs.append({"bucket":"logging","audience":"Developers","priority":"High","text":"Adopt standardized structured logging across the application."})
    if "metrics" in findings and not findings["metrics"]:
        recs.append({"bucket":"metrics","audience":"Developers","priority":"High","text":"Add metrics exporters and core RED/USE signals for operational visibility."})
    if "tracing" in findings and not findings["tracing"]:
        recs.append({"bucket":"tracing","audience":"Developers","priority":"High","text":"Enable distributed tracing and trace context propagation."})
    if "health" in findings and not findings["health"]:
        recs.append({"bucket":"health","audience":"Developers","priority":"Medium","text":"Expose health, readiness, and liveness endpoints."})
    if "resilience" in findings and not findings["resilience"]:
        recs.append({"bucket":"resilience","audience":"Developers","priority":"Medium","text":"Implement retry, timeout, or circuit-breaker patterns where appropriate."})
    if "config" in findings and not findings["config"]:
        recs.append({"bucket":"config","audience":"Observability Management","priority":"Medium","text":"Externalize observability configuration such as OTEL and log-level settings."})
    if "governance" in findings and not findings["governance"]:
        recs.append({"bucket":"governance","audience":"Observability Management","priority":"Medium","text":"Add ownership, runbook, and observability standards documentation."})
    if "cloud_observability" in findings and not findings["cloud_observability"]:
        recs.append({"bucket":"cloud_observability","audience":"Observability Management","priority":"Medium","text":"Align cloud observability settings with vendor and platform-native monitoring signals."})
    if vendor_tools and "cloud_observability" in findings:
        recs.append({"bucket":"cloud_observability","audience":"Observability Management","priority":"Low","text":"Rationalize detected vendor tools and standardize observability governance across them."})
    return recs[:12]

def summarize_strengths(findings, vendor_tools, service_ids):
    strengths = []
    mapping = {
        "logging": "Logging evidence detected",
        "metrics": "Metrics evidence detected",
        "tracing": "Tracing evidence detected",
        "health": "Health/readiness evidence detected",
        "resilience": "Resilience patterns detected",
        "config": "Observability configuration detected",
        "governance": "Governance/documentation evidence detected",
        "cloud_observability": "Cloud/vendor observability integration detected",
    }
    for bucket, text in mapping.items():
        if findings[bucket]:
            strengths.append(text)
    if vendor_tools:
        strengths.append(f"Vendor tools detected: {', '.join(vendor_tools[:4])}")
    if service_ids:
        strengths.append(f"Service ID candidates detected: {', '.join(service_ids[:3])}")
    return strengths[:10]

def infer_services_from_evidence(service_ids, findings):
    services = []
    seen = set()
    for sid in service_ids:
        name = str(sid).strip()
        if not name:
            continue
        key = name.lower()
        if key not in seen:
            services.append({"name": name, "source": "service_id"})
            seen.add(key)
    return services[:20]

def build_service_heatmap(services, findings, asset_metadata=None):
    """Build a deterministic service heatmap with evidence details for clicks."""
    asset_metadata = asset_metadata or {}
    heat = []
    buckets = list(BUCKETS.keys())
    max_evidence = max([len(findings.get(b, [])) for b in buckets] + [1])
    technologies = asset_metadata.get("technologies", []) or []

    for svc in services:
        svc_name = svc.get("name", "")
        svc_source = svc.get("source", "service_id")
        row = {
            "service": svc_name,
            "source": svc_source,
            "technology": ", ".join(technologies[:4]) if technologies else "Not detected",
            "buckets": {},
            "bucket_evidence": {},
            "bucket_evidence_items": {},
            "overall": 0
        }
        score_total = 0
        for bucket in buckets:
            evidence = findings.get(bucket, [])
            if not evidence:
                val = 0
                evidence_count = 0
                related_items = []
            else:
                related_items = [x for x in evidence if svc_name and svc_name.lower() in json.dumps(x).lower()]
                if not related_items:
                    related_items = evidence[: min(10, len(evidence))]
                evidence_count = len(related_items)
                ratio = evidence_count / max_evidence
                if ratio >= 0.75:
                    val = 5
                elif ratio >= 0.5:
                    val = 4
                elif ratio >= 0.25:
                    val = 3
                elif ratio > 0:
                    val = 2
                else:
                    val = 0
            row["buckets"][bucket] = val
            row["bucket_evidence"][bucket] = evidence_count
            row["bucket_evidence_items"][bucket] = [
                {
                    "file": x.get("file", ""),
                    "patterns": x.get("patterns", [])[:8],
                    "severity": x.get("severity", "amber"),
                } for x in related_items[:12]
            ]
            score_total += val
        row["overall"] = round((score_total / (len(buckets) * 5)) * 100) if buckets else 0
        row["maturity"] = maturity_label(row["overall"])
        heat.append(row)
    return heat

def derive_bucket_overview(findings, bucket_scores):
    """Derive bucket cards with evidence-backed reasoning and detailed items."""
    overview = {}
    for bucket, meta in RUNTIME_BUCKETS.items():
        evidence = findings.get(bucket, [])
        weight = float(meta["weight"])
        threshold = str(meta.get("threshold", "normal"))
        score_meta = explain_bucket_score(bucket, evidence, weight, threshold)
        score = float(bucket_scores.get(bucket, score_meta["score"]) or 0)
        if len(evidence) == 0 or score <= 0:
            status = "red"
        elif score >= weight * 0.85 and len(evidence) >= 3:
            status = "green"
        else:
            status = "amber"
        score_meta["score"] = score
        score_meta["status"] = status

        detailed_items = []
        for idx, item in enumerate(evidence[:30], start=1):
            detailed_items.append({
                "index": idx,
                "file": item.get("file", ""),
                "patterns": item.get("patterns", [])[:8],
                "severity": item.get("severity", "amber"),
                "why_counted": f"Matched {len(item.get('patterns', [])[:8])} signal pattern(s) under the {meta['title']} bucket."
            })

        overview[bucket] = {
            "title": meta["title"],
            "score": score,
            "weight": weight,
            "status": status,
            "evidence_count": len(evidence),
            "sample_files": [x["file"] for x in evidence[:5]],
            "evidence_label": "Not detected" if not evidence else f"{len(evidence)} evidence item(s)",
            "evidence_items": detailed_items,
            "score_details": score_meta,
        }
    return overview



def get_git_branch(repo_path: str) -> str:
    """Return the current git branch for repository-level traceability."""
    try:
        branch = subprocess.check_output(["git", "-C", repo_path, "rev-parse", "--abbrev-ref", "HEAD"], text=True).strip()
        return branch
    except Exception:
        return ""

def get_git_commit(repo_path: str) -> str:
    """Return the current git commit hash so results can be tied to an exact revision."""
    try:
        commit = subprocess.check_output(["git", "-C", repo_path, "rev-parse", "HEAD"], text=True).strip()
        return commit
    except Exception:
        return ""

def repo_text_matches(repo_path: str, patterns: list[str], max_files: int = 400) -> bool:
    """Search candidate repository files for any of the supplied patterns.

    This helper is used heavily by OBS Custom to convert a policy/control into
    a simple evidence-backed True/False check.
    """
    try:
        files = iter_candidate_files(repo_path)[:max_files]
    except Exception:
        files = []
    rx = re.compile("|".join(patterns), re.IGNORECASE)
    for path in files:
        try:
            text = safe_read_text(path)
        except Exception:
            text = ""
        if text and rx.search(text):
            return True
    return False

def build_scanner2_controls(repo_input: str, repo_path: str, stack: str, archetype: str, findings: dict, service_ids: list, vendor_tools: list):
    """Build the OBS Custom control model.

    Scanner 2 is a compliance-style review rather than only a maturity score.
    It groups checks into capability areas and produces:
    - individual control booleans
    - capability bucket pass/total summaries
    - a final verdict (Fully Observable / Partially Observable / Non-Compliant)
    - evidence output labels for the HTML application
    """
    branch = get_git_branch(repo_path)
    commit = get_git_commit(repo_path)
    has_splunk = any("splunk" in str(v).lower() for v in vendor_tools)
    has_logging = bool(findings.get("logging"))
    has_metrics = bool(findings.get("metrics"))
    has_tracing = bool(findings.get("tracing"))
    has_health = bool(findings.get("health"))
    has_governance = bool(findings.get("governance"))
    has_config = bool(findings.get("config"))
    pipeline_hint = repo_text_matches(repo_path, [r"azure-pipelines", r"github/workflows", r"gitlab-ci", r"jenkinsfile"])
    async_logging = repo_text_matches(repo_path, [r"\basync\b.{0,25}\blog", r"queuehandler", r"nonblocking", r"background logger", r"serilog\.sinks\.async"])
    config_driven = repo_text_matches(repo_path, [r"loglevel", r"logging\.level", r"serilog", r"appsettings", r"logback", r"logger configuration"])
    blocking_io = repo_text_matches(repo_path, [r"\bprint\(", r"console\.log\(", r"sync io", r"fs\.readfilesync", r"thread\.sleep"])
    json_logs = repo_text_matches(repo_path, [r"jsonformatter", r"structured", r"json layout", r"ecs", r"jsonlogger"])
    utc_iso = repo_text_matches(repo_path, [r"utc", r"iso8601", r"yyyy-mm-dd", r"timestamp"])
    metadata_fields = repo_text_matches(repo_path, [r"traceid", r"requestid", r"correlationid", r"spanid", r"tenantid", r"service[_\- ]id"])
    multiline_csv = repo_text_matches(repo_path, [r"csv", r"multiline", r"plain text log"])
    sensitive = repo_text_matches(repo_path, [r"password", r"secret", r"token\s*=", r"apikey", r"ssn", r"phi", r"pii"])
    events_present = repo_text_matches(repo_path, [r"\bevent\b", r"emit", r"publish", r"audit", r"deployment", r"config change"])
    retention = repo_text_matches(repo_path, [r"retention", r"ttl", r"archive", r"daysToKeep", r"log retention"])
    anti_patterns = repo_text_matches(repo_path, [r"duplicate", r"sync io", r"blocking", r"multiline", r"console\.log", r"print\("])

    groups = {
        "Repository & Service Discovery": {
            "Repository, branch, commit identified": bool(repo_input and commit),
            "Services and components discovered": bool(service_ids),
            "Language/runtime identified": stack not in ("Unknown", "", None),
            "Deployment model identified": archetype not in ("Unknown", "", None),
        },
        "Log Routing & Rubric": {
            "Security logs to Splunk": has_splunk,
            "Regulatory logs to Splunk": has_splunk,
            "Operational logs to Splunk": has_splunk,
            "Debug logs local only": has_logging,
            "No duplicate forwarding": len(vendor_tools) <= 2,
        },
        "Logging & Ingestion": {
            "UF present and compliant version": has_splunk,
            "OTEL approved if used": has_tracing or not repo_text_matches(repo_path, [r"otel", r"opentelemetry"]),
            "Approved pipelines only": pipeline_hint,
            "Syslog over UDP only": has_config,
        },
        "Application Logging": {
            "Standard logging framework": has_logging,
            "Async logging enforced": async_logging,
            "Config-driven behavior": config_driven,
            "No blocking I/O": not blocking_io,
        },
        "Metadata & Structure": {
            "JSON logs only": json_logs,
            "UTC ISO timestamps": utc_iso,
            "Mandatory metadata fields present": metadata_fields,
            "No multiline or CSV logging": not multiline_csv,
        },
        "Security & Compliance": {
            "No PII/PHI/secrets": not sensitive,
            "Violations flagged CRITICAL": sensitive,
        },
        "Signals": {
            "Metrics present": has_metrics,
            "Tracing IDs propagated": has_tracing,
            "Events emitted": events_present,
        },
        "Governance": {
            "Retention enforced": retention,
            "Anti-patterns detected": anti_patterns,
            "Risks aggregated": has_governance or anti_patterns or sensitive,
        }
    }

    bucket_summary = {}
    for group_name, controls in groups.items():
        total = len(controls)
        passed = sum(1 for v in controls.values() if v)
        bucket_summary[group_name] = {
            "passed": passed,
            "total": total,
            "status": "green" if passed == total else ("amber" if passed > 0 else "red")
        }

    logs_ok = groups["Application Logging"]["Standard logging framework"] and groups["Metadata & Structure"]["No multiline or CSV logging"] and groups["Security & Compliance"]["No PII/PHI/secrets"]
    metrics_ok = groups["Signals"]["Metrics present"]
    tracing_ok = groups["Signals"]["Tracing IDs propagated"]
    events_ok = groups["Signals"]["Events emitted"]
    if logs_ok and metrics_ok and tracing_ok and events_ok:
        verdict = "Fully Observable"
    elif not groups["Security & Compliance"]["No PII/PHI/secrets"] or not groups["Application Logging"]["Standard logging framework"]:
        verdict = "Non-Compliant"
    else:
        verdict = "Partially Observable"

    return {
        "branch": branch,
        "commit_hash": commit,
        "groups": groups,
        "bucket_summary": bucket_summary,
        "verdict": verdict,
        "evidence_outputs": {
            "Repository & Service Discovery": "Scan Summary / Services Discovered",
            "Log Routing & Rubric": "Log Routing Compliance",
            "Logging & Ingestion": "Logging Agent Evidence / Ingestion Standards",
            "Application Logging": "Application Logging Compliance",
            "Metadata & Structure": "Log Format / Timestamp / Metadata Compliance",
            "Security & Compliance": "Security Risk Summary",
            "Signals": "Metrics Coverage / Tracing Readiness / Event Visibility",
            "Governance": "Retention / Anti-Pattern / Risk Summary"
        }
    }

def main():
    """Execute the requested scanner profile and emit a single JSON summary line.

    The frontend HTML application listens for this output and renders bucket cards,
    metadata, observations, recommendations, and profile-specific details.
    """
    if len(sys.argv) not in (3, 4):
        fail_and_exit("Usage: python observability_scanner.py <repo_path_or_url> <token> [scanner_profile]")
    repo_input = sys.argv[1].strip()
    token = sys.argv[2].strip()
    # scanner_profile controls whether we run the standard industry model or the custom policy model.
    scanner_profile = (sys.argv[3].strip() if len(sys.argv) >= 4 else 'scanner_v1') or 'scanner_v1'

    log("STAGE", f"Starting observability scan using profile: {scanner_profile}")
    log("INFO", f"Repository input: {repo_input}")

    start = time.time()
    repo_path = None
    cleanup = False
    try:
        repo_path, cleanup = prepare_repo(repo_input, token)
        all_files = collect_repo_index(repo_path)
        stack, stack_scores = detect_stack(all_files)
        archetype, archetype_scores = detect_archetype(all_files)
        inferred_tier, tier_signals = detect_tier(all_files, repo_path)
        if inferred_tier:
            log("INFO", f"Inferred application tier: {inferred_tier}")
        log("INFO", f"Detected stack: {stack}")
        log("INFO", f"Detected archetype: {archetype}")
        log("STAGE", "Scanning files for observability signals in parallel")
        findings, files_scanned, scan_errors, service_ids, vendor_tools, asset_metadata = scan_repository(repo_path)
        log("STAGE", "Calculating weighted maturity score")

        bucket_scores = {}
        bucket_score_details = {}
        total = 0.0
        for bucket, meta in RUNTIME_BUCKETS.items():
            detail = explain_bucket_score(bucket, len(findings[bucket]), meta["weight"], meta.get("threshold", "normal"))
            bucket_scores[bucket] = detail["score"]
            bucket_score_details[bucket] = detail
            total += bucket_scores[bucket]
            log("RESULT", f"{bucket}={bucket_scores[bucket]}")

        total_possible = sum(meta["weight"] for meta in RUNTIME_BUCKETS.values() if meta.get("enabled", True)) or 1
        total = round((total / total_possible) * 100)
        level = maturity_label(total)
        strengths = summarize_strengths(findings, vendor_tools, service_ids)
        gaps = [RUNTIME_BUCKETS[k]["title"] for k, v in findings.items() if not v]
        recs = recommendations(findings, vendor_tools)
        duration = round(time.time() - start, 2)

        inferred_services = infer_services_from_evidence(service_ids, findings)
        service_heatmap = build_service_heatmap(inferred_services, findings, asset_metadata)

        # Scanner 2 adds a second-layer compliance interpretation on top of the base signal scan.
        scanner2 = build_scanner2_controls(repo_input, repo_path, stack, archetype, findings, service_ids, vendor_tools)
        # Final summary is the single contract consumed by the HTML application.
        # Every new UI section should ideally be driven from this structure.
        summary = {
            "repository_input": repo_input,
            "scanner_profile": scanner_profile,
            "application_name": os.path.basename(repo_input.rstrip('/')) if repo_input else "unknown",
            "stack": stack,
            "archetype": archetype,
            "inferred_tier": inferred_tier,
            "tier_signals": tier_signals,
            "stack_signals": stack_scores,
            "archetype_signals": archetype_scores,
            "files_scanned": files_scanned,
            "scan_errors": scan_errors,
            "score": total,
            "maturity": level,
            "bucket_scores": bucket_scores,
            "bucket_score_details": bucket_score_details,
            "active_bucket_config": RUNTIME_BUCKETS,
            "bucket_overview": derive_bucket_overview(findings, bucket_scores),
            "signal_counts": {k: len(v) for k, v in findings.items()},
            "strengths": strengths,
            "gaps": gaps,
            "recommendations": recs,
            "sample_evidence": {k: v[:10] for k, v in findings.items() if v},
            "kpi_details": {
                "observability_score": {
                    "value": total,
                    "reason": "The total observability score is the weighted percentage across all enabled buckets.",
                    "parts": [bucket_score_details[k] for k in bucket_score_details]
                },
                "signals_detected": {
                    "value": sum(len(v) for v in findings.values()),
                    "reason": "Signals detected is the sum of matched evidence items across enabled buckets.",
                    "parts": [{"bucket": k, "count": len(v)} for k, v in findings.items()]
                },
                "services_detected": {
                    "value": len(inferred_services),
                    "reason": "Services detected are service identifiers inferred from asset metadata and repository evidence after validation filtering.",
                    "parts": [{"service": s.get("name",""), "source": s.get("source","")} for s in inferred_services]
                },
                "vendor_tools": {
                    "value": len(vendor_tools),
                    "reason": "Vendor tools are counted only when stronger configuration or operational evidence is found outside docs/tests/examples.",
                    "parts": [{"tool": t} for t in vendor_tools]
                }
            },
            "service_ids": service_ids,
            "asset_metadata": asset_metadata,
            "inferred_services": inferred_services,
            "service_heatmap": service_heatmap,
            "vendor_tools": vendor_tools,
            "duration_seconds": duration,
            "developer_focus": [r for r in recs if r["audience"] == "Developers"],
            "management_focus": [r for r in recs if r["audience"] == "Observability Management"],
            "scanner2": scanner2
        }
        log("DONE", json.dumps(summary))
    except Exception as exc:
        fail_and_exit(f"Unexpected scanner error: {exc}")
    finally:
        if cleanup and repo_path and os.path.isdir(repo_path):
            shutil.rmtree(repo_path, ignore_errors=True)

if __name__ == "__main__":
    main()
