
let newBulkPollHandle = null;
let newBulkInventory = [];

function parseNewBulkText(){
  const raw = qs("#newbulk-text")?.value || "";
  const lines = raw.split(/\r?\n/).map(x=>x.trim()).filter(Boolean);
  newBulkInventory = lines.map(line=>{
    const parts = line.split(",").map(x=>x.trim());
    if(parts.length === 2){
      return { application_name: inferRepoDisplayName(parts[0]), repo_url: parts[0], token_alias: parts[1] || "" };
    }
    return {
      application_name: parts[0] || inferRepoDisplayName(parts[1] || parts[0] || ""),
      repo_url: parts[1] || parts[0] || "",
      token_alias: parts[2] || "",
      tier: "",
      portfolio: "",
      owner: "",
      criticality: "",
      notes: ""
    };
  }).filter(x=>x.repo_url);
}

function loadNewBulkSample(){
  const sample = [
    "claims-api,https://dev.azure.com/org/proj/_git/claims-api,azure_pat_main",
    "member-ui,https://dev.azure.com/org/proj/_git/member-ui,azure_pat_main",
    "provider-worker,https://dev.azure.com/org/proj/_git/provider-worker,azure_pat_secondary",
  ].join("\n");
  const box = qs("#newbulk-text");
  if(box) box.value = sample;
  parseNewBulkText();
}

function repoStatusIcon(status){
  if(status === "completed") return "✅";
  if(status === "failed") return "❌";
  if(status === "running") return "🔵";
  return "📄";
}

function findingToneClass(sev){
  const s = String(sev || "").toLowerCase();
  if(s.includes("critical")) return "critical";
  if(s.includes("medium")) return "medium";
  if(s.includes("success")) return "success";
  return "medium";
}

function renderNewBulkStatus(data){
  const items = data.items || [];
  const summary = data.summary || {};
  const selectedRepo = data.selected_repo || (items[0] ? items[0].repo_url : "");
  const selected = items.find(x=>x.repo_url === selectedRepo) || items.find(x=>x.status === "running") || items[0] || null;

  const setv = (id,val)=>{ const el = qs(id); if(el) el.textContent = val; };
  setv("#newbulk-total-kpi", summary.total || 0);
  setv("#newbulk-queued-kpi", summary.queued || 0);
  setv("#newbulk-running-kpi", summary.running || 0);
  setv("#newbulk-completed-kpi", summary.completed || 0);
  setv("#newbulk-saved-kpi", summary.saved || 0);
  setv("#newbulk-queue-pill", `${summary.queued || 0} queued`);

  const tree = qs("#newbulk-repo-tree");
  if(tree){
    tree.innerHTML = items.length ? items.map(item=>`
      <button type="button" class="repo-tree-item ${item.repo_url === selectedRepo ? "active" : ""}" data-repo="${escapeHtml(item.repo_url)}">
        <span class="repo-icon">${repoStatusIcon(item.status)}</span>
        <span class="repo-text">${escapeHtml(item.application_name || inferRepoDisplayName(item.repo_url))} (${escapeHtml(item.status || "queued")})</span>
      </button>
    `).join("") : '<div class="muted">No repositories loaded.</div>';
    qsa(".repo-tree-item").forEach(btn=>{
      btn.addEventListener("click", ()=>{
        fetch("/bulk-v2/select", {
          method:"POST",
          headers:{"Content-Type":"application/json"},
          body: JSON.stringify({repo_url: btn.dataset.repo})
        }).then(()=>pollNewBulkStatus());
      });
    });
  }

  const table = qs("#newbulk-progress-table");
  if(table){
    table.innerHTML = items.length ? `
      <div class="assessment-table-wrap">
        <table class="assessment-table">
          <thead><tr><th>Repository</th><th>Scan Type</th><th>Progress</th><th>Current Finding</th></tr></thead>
          <tbody>
            ${items.map(item=>`
              <tr class="assessment-main-row ${item.repo_url === selectedRepo ? "selected-row" : ""}">
                <td>${escapeHtml(item.application_name || inferRepoDisplayName(item.repo_url))}</td>
                <td>${escapeHtml(item.phase || "Queued")}</td>
                <td>
                  <div class="mini-progress"><div class="kpi-bar-fill" style="width:${Math.max(0,Math.min(100, Number(item.progress||0)))}%"></div></div>
                  <div class="mini-help">${escapeHtml(String(item.progress || 0))}%</div>
                </td>
                <td>${escapeHtml(item.current_finding || "—")}</td>
              </tr>
            `).join("")}
          </tbody>
        </table>
      </div>` : '<div class="muted">No scan in progress.</div>';
  }

  const panel = qs("#newbulk-finding-panel");
  if(panel){
    if(!selected){
      panel.innerHTML = '<div class="muted">Start a bulk run to see details here.</div>';
    } else {
      const findings = selected.findings || [];
      const score = (selected.report || {}).score;
      const maturity = (selected.report || {}).maturity;
      panel.innerHTML = `
        <div class="finding-stack">
          <div class="finding-header">
            <div>
              <h3>${escapeHtml(selected.application_name || inferRepoDisplayName(selected.repo_url))}</h3>
              <div class="mini-help">${escapeHtml(selected.status || "queued")} • ${escapeHtml(selected.phase || "Queued")} • ${selected.saved ? "Saved" : "Not saved yet"}</div>
            </div>
            <div class="actions">
              <button type="button" class="secondary-btn" id="newbulk-open-detail-btn">Open Result</button>
              <button type="button" class="secondary-btn" id="newbulk-open-export-btn">Export This Scan</button>
            </div>
          </div>
          <div class="kv-list">
            <div class="kv"><span>Score</span><strong>${escapeHtml(String(score ?? "—"))}</strong></div>
            <div class="kv"><span>Maturity</span><strong>${escapeHtml(maturity || "—")}</strong></div>
            <div class="kv"><span>Repo</span><strong class="wrap-anywhere">${escapeHtml(selected.repo_url || "")}</strong></div>
          </div>
          <div class="terminal" style="margin-top:12px; height:160px;">${escapeHtml((selected.lines || []).slice(-30).join("\n"))}</div>
          <div class="finding-list" style="margin-top:14px">
            ${findings.length ? findings.map(f=>`
              <div class="finding-card ${findingToneClass(f.severity)}">
                <div class="finding-title">${escapeHtml(f.severity || "Medium")}: ${escapeHtml(f.title || "Finding")}</div>
                <div class="mini-help">${escapeHtml(f.detail || "")}</div>
                ${Array.isArray(f.sample_files) && f.sample_files.length ? `<div class="mini-help" style="margin-top:6px">Files: ${escapeHtml(f.sample_files.join(", "))}</div>` : ""}
              </div>
            `).join("") : '<div class="muted">No findings yet for this repository.</div>'}
          </div>
        </div>`;
      const openBtn = qs("#newbulk-open-detail-btn");
      if(openBtn){
        openBtn.onclick = ()=>{
          if(selected.report){
            renderResults(selected.report);
            setPage("details");
          }
        };
      }
      const exportBtn = qs("#newbulk-open-export-btn");
      if(exportBtn){
        exportBtn.onclick = ()=>{
          if(selected.saved){
            window.location.href = `/reports/export/scan/${(selected.report || {}).saved_assessment_id || ""}`; // harmless if absent
          }
        };
      }
    }
  }
}

async function pollNewBulkStatus(){
  try{
    const r = await fetch("/bulk-v2/status");
    const data = await r.json();
    renderNewBulkStatus(data);
    if(data.is_running){
      newBulkPollHandle = setTimeout(pollNewBulkStatus, 1200);
    }
  }catch(e){
    newBulkPollHandle = setTimeout(pollNewBulkStatus, 1800);
  }
}

function startNewBulk(){
  parseNewBulkText();
  if(!newBulkInventory.length){
    alert("Paste repositories first.");
    return;
  }
  const payload = {
    items: newBulkInventory,
    scanner_profile: qs("#newbulk-scanner-profile")?.value || "scanner_v1",
    save_results: !!qs("#newbulk-save-results")?.checked
  };
  fetch("/bulk-v2/start", {
    method:"POST",
    headers:{"Content-Type":"application/json"},
    body: JSON.stringify(payload)
  }).then(r=>r.json()).then(data=>{
    if(data.status !== "started"){
      alert(data.message || "Could not start New Bulk Scan.");
      return;
    }
    setPage("newbulk");
    if(newBulkPollHandle) clearTimeout(newBulkPollHandle);
    pollNewBulkStatus();
  });
}

function exportNewBulkRun(){
  fetch("/bulk-v2/status").then(r=>r.json()).then(data=>{
    const runId = data.scan_run_id;
    if(runId){
      window.location.href = `/batch/export/summary/${runId}`;
    } else {
      alert("No completed bulk run available to export yet.");
    }
  });
}


let liveBulkPollHandle = null;
let liveBulkInventory = [];

function parseLiveBulkText(){
  const raw = qs("#livebulk-text")?.value || "";
  const lines = raw.split(/\r?\n/).map(x=>x.trim()).filter(Boolean);
  liveBulkInventory = lines.map(line=>{
    const parts = line.split(",").map(x=>x.trim());
    if(parts.length === 2){
      return { application_name: inferRepoDisplayName(parts[0]), repo_url: parts[0], token_alias: parts[1] || "" };
    }
    return {
      application_name: parts[0] || inferRepoDisplayName(parts[1] || parts[0] || ""),
      repo_url: parts[1] || parts[0] || "",
      token_alias: parts[2] || "",
      tier: "",
      portfolio: "",
      owner: "",
      criticality: "",
      notes: ""
    };
  }).filter(x=>x.repo_url);
}

function loadLiveBulkSample(){
  const sample = [
    "claims-api,https://dev.azure.com/org/proj/_git/claims-api,azure_pat_main",
    "member-ui,https://dev.azure.com/org/proj/_git/member-ui,azure_pat_main",
    "provider-worker,https://dev.azure.com/org/proj/_git/provider-worker,azure_pat_secondary",
  ].join("\n");
  const box = qs("#livebulk-text");
  if(box) box.value = sample;
  parseLiveBulkText();
}

function renderLiveBulkStatus(data){
  const summary = data.summary || {};
  const current = data.current || null;
  const queue = data.queue || [];
  const completed = data.completed || [];
  const failed = data.failed || [];
  const rows = completed.concat(failed);

  const setv = (id,val)=>{ const el = qs(id); if(el) el.textContent = val; };
  setv("#livebulk-total-kpi", summary.total || 0);
  setv("#livebulk-queued-kpi", summary.queued || 0);
  setv("#livebulk-running-kpi", summary.running || 0);
  setv("#livebulk-completed-kpi", summary.completed || 0);
  setv("#livebulk-saved-kpi", summary.saved || 0);
  setv("#livebulk-queue-pill", `${summary.queued || 0} queued`);
  setv("#livebulk-current-pill", current ? `${current.application_name || inferRepoDisplayName(current.repo_url)} • ${current.phase || "Running"}` : (data.is_running ? "Preparing..." : "No active run."));

  const currentHost = qs("#livebulk-current-card");
  if(currentHost){
    if(!current){
      currentHost.textContent = data.is_running ? "Waiting for the next repository to start..." : "Start Live Scan Bulk to watch the current repository here.";
    } else {
      currentHost.innerHTML = `
        <div class="parallel-scan-card">
          <div class="top-row">
            <strong class="wrap-anywhere">${escapeHtml(current.application_name || inferRepoDisplayName(current.repo_url))}</strong>
            <span class="status-pill running">${escapeHtml(current.phase || "Running")}</span>
          </div>
          <div class="kv-list">
            <div class="kv"><span>Repo</span><strong class="wrap-anywhere">${escapeHtml(current.repo_url || "")}</strong></div>
            <div class="kv"><span>Token</span><strong class="token-mask">${escapeHtml(maskTokenLike(current.token_alias || ""))}</strong></div>
          </div>
          <pre class="terminal" style="margin-top:12px; height:220px;">${escapeHtml((current.lines || []).slice(-40).join("\n"))}</pre>
        </div>`;
    }
  }

  const queueHost = qs("#livebulk-queue-list");
  if(queueHost){
    queueHost.innerHTML = queue.length ? queue.map(item=>`
      <div class="queued-chip"><strong>${escapeHtml(item.application_name || inferRepoDisplayName(item.repo_url))}</strong><span>queued</span></div>
    `).join("") : '<div class="muted">No queued repositories.</div>';
  }

  const tableHost = qs("#livebulk-completed-table");
  if(tableHost){
    if(!rows.length){
      tableHost.textContent = "No completed scans yet.";
    } else {
      tableHost.innerHTML = `
        <div class="assessment-table-wrap">
          <table class="assessment-table">
            <thead><tr><th>Application</th><th>Status</th><th>Saved</th><th>Score</th><th>Maturity</th><th>Action</th></tr></thead>
            <tbody>
              ${rows.map((item, idx)=>`
                <tr class="assessment-main-row">
                  <td>${escapeHtml(item.application_name || inferRepoDisplayName(item.repo_url))}</td>
                  <td><span class="status-pill ${escapeHtml(item.status || "failed")}">${escapeHtml(item.status || "failed")}</span></td>
                  <td>${item.saved ? "✓" : "—"}</td>
                  <td>${escapeHtml(String((item.report || {}).score ?? "—"))}</td>
                  <td>${escapeHtml((item.report || {}).maturity || "—")}</td>
                  <td><button type="button" class="secondary-btn livebulk-load-result-btn" data-livebulk-idx="${idx}">Open Details</button></td>
                </tr>
              `).join("")}
            </tbody>
          </table>
        </div>`;
      qsa(".livebulk-load-result-btn").forEach(btn=>{
        btn.addEventListener("click", ()=>{
          const item = rows[Number(btn.dataset.livebulkIdx)||0];
          if(item && item.report){
            renderResults(item.report);
            setPage("details");
          }
        });
      });
    }
  }
}

async function pollLiveBulkStatus(){
  try{
    const r = await fetch("/live-bulk/status");
    const data = await r.json();
    renderLiveBulkStatus(data);
    if(data.is_running){
      liveBulkPollHandle = setTimeout(pollLiveBulkStatus, 1200);
    }
  }catch(e){
    liveBulkPollHandle = setTimeout(pollLiveBulkStatus, 1800);
  }
}

function startLiveBulk(){
  parseLiveBulkText();
  if(!liveBulkInventory.length){
    alert("Paste repositories first.");
    return;
  }
  const payload = {
    items: liveBulkInventory,
    scanner_profile: qs("#livebulk-scanner-profile")?.value || "scanner_v1",
    save_results: !!qs("#livebulk-save-results")?.checked
  };
  fetch("/live-bulk/start", {
    method:"POST",
    headers:{"Content-Type":"application/json"},
    body: JSON.stringify(payload)
  }).then(r=>r.json()).then(data=>{
    if(data.status !== "started"){
      alert(data.message || "Could not start Live Scan Bulk.");
      return;
    }
    setPage("livebulk");
    if(liveBulkPollHandle) clearTimeout(liveBulkPollHandle);
    pollLiveBulkStatus();
  });
}


let multiscanPollHandle = null;
let multiscanInventory = [];

function parseMultiScanText(){
  const raw = qs("#multiscan-text")?.value || "";
  const lines = raw.split(/\r?\n/).map(x=>x.trim()).filter(Boolean);
  multiscanInventory = lines.map(line=>{
    const parts = line.split(",").map(x=>x.trim());
    if(parts.length === 2){
      return { application_name: inferRepoDisplayName(parts[0]), repo_url: parts[0], token_alias: parts[1] || "" };
    }
    return {
      application_name: parts[0] || inferRepoDisplayName(parts[1] || parts[0] || ""),
      repo_url: parts[1] || parts[0] || "",
      token_alias: parts[2] || "",
      tier: "",
      portfolio: "",
      owner: "",
      criticality: "",
      notes: ""
    };
  }).filter(x=>x.repo_url);
}

function loadMultiScanSample(){
  const sample = [
    "claims-api,https://dev.azure.com/org/proj/_git/claims-api,azure_pat_main",
    "member-ui,https://dev.azure.com/org/proj/_git/member-ui,azure_pat_main",
    "provider-worker,https://dev.azure.com/org/proj/_git/provider-worker,azure_pat_secondary",
  ].join("\n");
  const box = qs("#multiscan-text");
  if(box) box.value = sample;
  parseMultiScanText();
}

function renderMultiScanStatus(data){
  const summary = data.summary || {};
  const current = data.current || null;
  const queue = data.queue || [];
  const completed = data.completed || [];
  const failed = data.failed || [];
  const rows = completed.concat(failed);
  const savedCount = completed.filter(x=>x.saved).length;

  const setv = (id,val)=>{ const el = qs(id); if(el) el.textContent = val; };
  setv("#multiscan-total-kpi", summary.total || 0);
  setv("#multiscan-queued-kpi", summary.queued || 0);
  setv("#multiscan-running-kpi", summary.running || 0);
  setv("#multiscan-completed-kpi", summary.completed || 0);
  setv("#multiscan-saved-kpi", savedCount);
  setv("#multiscan-queue-pill", `${summary.queued || 0} queued`);
  setv("#multiscan-current-pill", current ? `${current.application_name || inferRepoDisplayName(current.repo_url)} • ${current.phase || "Running"}` : (data.is_running ? "Preparing..." : "No active multi scan."));

  const currentHost = qs("#multiscan-current-card");
  if(currentHost){
    if(!current){
      currentHost.textContent = data.is_running ? "Waiting for the next repository to start..." : "Start a multi scan to watch the current repository here.";
    } else {
      currentHost.innerHTML = `
        <div class="parallel-scan-card">
          <div class="top-row">
            <strong class="wrap-anywhere">${escapeHtml(current.application_name || inferRepoDisplayName(current.repo_url))}</strong>
            <span class="status-pill running">${escapeHtml(current.phase || "Running")}</span>
          </div>
          <div class="kv-list">
            <div class="kv"><span>Repo</span><strong class="wrap-anywhere">${escapeHtml(current.repo_url || "")}</strong></div>
            <div class="kv"><span>Token</span><strong class="token-mask">${escapeHtml(maskTokenLike(current.token_alias || ""))}</strong></div>
          </div>
          <pre class="terminal" style="margin-top:12px; height:220px;">${escapeHtml((current.lines || []).slice(-40).join("\n"))}</pre>
        </div>`;
    }
  }

  const queueHost = qs("#multiscan-queue-list");
  if(queueHost){
    queueHost.innerHTML = queue.length ? queue.map(item=>`
      <div class="queued-chip"><strong>${escapeHtml(item.application_name || inferRepoDisplayName(item.repo_url))}</strong><span>queued</span></div>
    `).join("") : '<div class="muted">No queued repositories.</div>';
  }

  const tableHost = qs("#multiscan-completed-table");
  if(tableHost){
    if(!rows.length){
      tableHost.textContent = "No completed scans yet.";
    } else {
      tableHost.innerHTML = `
        <div class="assessment-table-wrap">
          <table class="assessment-table">
            <thead><tr><th>Application</th><th>Status</th><th>Saved</th><th>Score</th><th>Maturity</th><th>Action</th></tr></thead>
            <tbody>
              ${rows.map((item, idx)=>`
                <tr class="assessment-main-row">
                  <td>${escapeHtml(item.application_name || inferRepoDisplayName(item.repo_url))}</td>
                  <td><span class="status-pill ${escapeHtml(item.status || "failed")}">${escapeHtml(item.status || "failed")}</span></td>
                  <td>${item.saved ? "Yes" : "No"}</td>
                  <td>${escapeHtml(String((item.report || {}).score ?? "—"))}</td>
                  <td>${escapeHtml((item.report || {}).maturity || "—")}</td>
                  <td><button type="button" class="secondary-btn multiscan-load-result-btn" data-multiscan-idx="${idx}">Open Details</button></td>
                </tr>
              `).join("")}
            </tbody>
          </table>
        </div>`;
      qsa(".multiscan-load-result-btn").forEach(btn=>{
        btn.addEventListener("click", ()=>{
          const item = rows[Number(btn.dataset.multiscanIdx)||0];
          if(item && item.report){
            renderResults(item.report);
            setPage("details");
          }
        });
      });
    }
  }
}

async function pollMultiScanStatus(){
  try{
    const r = await fetch("/multiscan/status");
    const data = await r.json();
    renderMultiScanStatus(data);
    if(data.is_running){
      multiscanPollHandle = setTimeout(pollMultiScanStatus, 1200);
    }
  }catch(e){
    multiscanPollHandle = setTimeout(pollMultiScanStatus, 1800);
  }
}

function startMultiScan(){
  parseMultiScanText();
  if(!multiscanInventory.length){
    alert("Paste repositories first.");
    return;
  }
  const payload = {
    items: multiscanInventory,
    scanner_profile: qs("#multiscan-scanner-profile")?.value || "scanner_v1",
    save_results: !!qs("#multiscan-save-results")?.checked
  };
  fetch("/multiscan/start", {
    method:"POST",
    headers:{"Content-Type":"application/json"},
    body: JSON.stringify(payload)
  }).then(r=>r.json()).then(data=>{
    if(data.status !== "started"){
      alert(data.message || "Could not start multi scan.");
      return;
    }
    setPage("multiscan");
    if(multiscanPollHandle) clearTimeout(multiscanPollHandle);
    pollMultiScanStatus();
  });
}


let fifoPollHandle = null;
let fifoInventory = [];

function parseFifoText(){
  const raw = qs("#fifo-text")?.value || "";
  const lines = raw.split(/\r?\n/).map(x=>x.trim()).filter(Boolean);
  fifoInventory = lines.map(line=>{
    const parts = line.split(",").map(x=>x.trim());
    if(parts.length === 2){
      return { application_name: inferRepoDisplayName(parts[0]), repo_url: parts[0], token_alias: parts[1] || "" };
    }
    return { application_name: parts[0] || inferRepoDisplayName(parts[1] || parts[0] || ""), repo_url: parts[1] || parts[0] || "", token_alias: parts[2] || "" };
  }).filter(x=>x.repo_url);
}

function loadFifoSample(){
  const sample = [
    "claims-api,https://dev.azure.com/org/proj/_git/claims-api,azure_pat_main",
    "member-ui,https://dev.azure.com/org/proj/_git/member-ui,azure_pat_main",
    "provider-worker,https://dev.azure.com/org/proj/_git/provider-worker,azure_pat_secondary",
  ].join("\n");
  const box = qs("#fifo-text");
  if(box) box.value = sample;
  parseFifoText();
}

function renderFifoStatus(data){
  const summary = data.summary || {};
  const current = data.current || null;
  const queue = data.queue || [];
  const completed = data.completed || [];
  const failed = data.failed || [];
  const rows = completed.concat(failed);
  const setv = (id,val)=>{ const el = qs(id); if(el) el.textContent = val; };
  setv("#fifo-total-kpi", summary.total || 0);
  setv("#fifo-queued-kpi", summary.queued || 0);
  setv("#fifo-running-kpi", summary.running || 0);
  setv("#fifo-completed-kpi", summary.completed || 0);
  setv("#fifo-failed-kpi", summary.failed || 0);
  setv("#fifo-queue-pill", `${summary.queued || 0} queued`);
  setv("#fifo-current-pill", current ? `${current.application_name || inferRepoDisplayName(current.repo_url)} • ${current.phase || "Running"}` : (data.is_running ? "Preparing..." : "No active queue scan."));

  const currentHost = qs("#fifo-current-card");
  if(currentHost){
    if(!current){
      currentHost.textContent = data.is_running ? "Waiting for the next repository to start..." : "Start a queue to watch the current repository scan here.";
    } else {
      currentHost.innerHTML = `
        <div class="parallel-scan-card">
          <div class="top-row">
            <strong class="wrap-anywhere">${escapeHtml(current.application_name || inferRepoDisplayName(current.repo_url))}</strong>
            <span class="status-pill running">${escapeHtml(current.phase || "Running")}</span>
          </div>
          <div class="kv-list">
            <div class="kv"><span>Repo</span><strong class="wrap-anywhere">${escapeHtml(current.repo_url || "")}</strong></div>
            <div class="kv"><span>Token</span><strong class="token-mask">${escapeHtml(maskTokenLike(current.token_alias || ""))}</strong></div>
          </div>
          <pre class="terminal" style="margin-top:12px; height:220px;">${escapeHtml((current.lines || []).slice(-40).join("\n"))}</pre>
        </div>`;
    }
  }

  const queueHost = qs("#fifo-queue-list");
  if(queueHost){
    queueHost.innerHTML = queue.length ? queue.map(item=>`
      <div class="queued-chip"><strong>${escapeHtml(item.application_name || inferRepoDisplayName(item.repo_url))}</strong><span>queued</span></div>
    `).join("") : '<div class="muted">No queued repositories.</div>';
  }

  const tableHost = qs("#fifo-completed-table");
  if(tableHost){
    if(!rows.length){
      tableHost.textContent = "No completed scans yet.";
    } else {
      tableHost.innerHTML = `
        <div class="assessment-table-wrap">
          <table class="assessment-table">
            <thead><tr><th>Application</th><th>Status</th><th>Score</th><th>Maturity</th><th>Action</th></tr></thead>
            <tbody>
              ${rows.map((item, idx)=>`
                <tr class="assessment-main-row">
                  <td>${escapeHtml(item.application_name || inferRepoDisplayName(item.repo_url))}</td>
                  <td><span class="status-pill ${escapeHtml(item.status || "failed")}">${escapeHtml(item.status || "failed")}</span></td>
                  <td>${escapeHtml(String((item.report || {}).score ?? "—"))}</td>
                  <td>${escapeHtml((item.report || {}).maturity || "—")}</td>
                  <td><button type="button" class="secondary-btn fifo-load-result-btn" data-fifo-idx="${idx}">Open Details</button></td>
                </tr>
              `).join("")}
            </tbody>
          </table>
        </div>`;
      qsa(".fifo-load-result-btn").forEach(btn=>{
        btn.addEventListener("click", ()=>{
          const item = rows[Number(btn.dataset.fifoIdx)||0];
          if(item && item.report){
            renderResults(item.report);
            setPage("details");
          }
        });
      });
    }
  }
}

async function pollFifoStatus(){
  try{
    const r = await fetch("/fifo/status");
    const data = await r.json();
    renderFifoStatus(data);
    if(data.is_running){
      fifoPollHandle = setTimeout(pollFifoStatus, 1200);
    }
  }catch(e){
    fifoPollHandle = setTimeout(pollFifoStatus, 1800);
  }
}

function startFifoScan(){
  parseFifoText();
  if(!fifoInventory.length){
    alert("Paste repositories first.");
    return;
  }
  const payload = {
    items: fifoInventory,
    scanner_profile: qs("#fifo-scanner-profile")?.value || "scanner_v1"
  };
  fetch("/fifo/start", {
    method:"POST",
    headers:{"Content-Type":"application/json"},
    body: JSON.stringify(payload)
  }).then(r=>r.json()).then(data=>{
    if(data.status !== "started"){
      alert(data.message || "Could not start queue scan.");
      return;
    }
    setPage("fifo");
    if(fifoPollHandle) clearTimeout(fifoPollHandle);
    pollFifoStatus();
  });
}


function bindTopTileDrilldowns(report){
  qsa("#results-top-kpis .tile-drilldown").forEach(card=>{
    card.addEventListener("click", ()=>{
      const tile = card.dataset.tile;
      if(tile === "score"){
        const rows = Object.entries(report.bucket_overview || {}).map(([k,v])=>`
          <div class="evidence-card">
            <div class="evidence-top"><strong>${escapeHtml(v.title || k)}</strong><span class="status-pill ${escapeHtml(v.status || "red")}">${escapeHtml(v.status || "red")}</span></div>
            <div class="mini-help">This bucket contributed ${escapeHtml(String(v.score || 0))}/${escapeHtml(String(v.weight || 0))} to the overall score.</div>
          </div>
        `).join("");
        renderTileDetailPanel("Observability Score", "Overall score is the weighted sum of bucket contributions.", rows);
      } else if(tile === "signals"){
        const rows = Object.entries(report.bucket_overview || {}).map(([k,v])=>`
          <div class="evidence-card">
            <div class="evidence-top"><strong>${escapeHtml(v.title || k)}</strong><span class="status-pill ${escapeHtml(v.status || "red")}">${escapeHtml(v.evidence_count || 0)} signal(s)</span></div>
            <div class="mini-help">${escapeHtml(v.evidence_label || "Not detected")}</div>
          </div>
        `).join("");
        renderTileDetailPanel("Signals Detected", "Signal counts come from matched patterns inside repository files.", rows);
      } else if(tile === "services"){
        const services = (report.inferred_services || report.service_ids || []).map(s=>typeof s === "string" ? {name:s, source:"service_id"} : s);
        const rows = services.length ? services.map(s=>`
          <div class="evidence-card">
            <div class="evidence-top"><strong>${escapeHtml(s.name || "—")}</strong><span class="status-pill completed">${escapeHtml(s.source || "service_id")}</span></div>
            <div class="mini-help">This service was counted because it matched the service ID extraction and validation rules.</div>
          </div>
        `).join("") : '<div class="muted">No services detected.</div>';
        renderTileDetailPanel("Services Detected", "Services are counted only when they pass the stricter validation rules.", rows);
      } else if(tile === "vendors"){
        const items = (report.vendor_tools || []);
        const rows = items.length ? items.map(v=>`
          <div class="evidence-card">
            <div class="evidence-top"><strong>${escapeHtml(v)}</strong><span class="status-pill amber">detected</span></div>
            <div class="mini-help">Vendor tools are counted only from stronger operational/config evidence and not from docs/tests/examples.</div>
          </div>
        `).join("") : '<div class="muted">No vendor tools detected.</div>';
        renderTileDetailPanel("Vendor Tools", "Vendor tools are counted only from strong evidence sources.", rows);
      } else if(tile === "profile"){
        renderTileDetailPanel("Scanner Profile", `This scan used ${report.scanner_profile === "scanner_v2" ? "OBS Custom" : "OBS Industry"}.`, `<div class="mini-help">Profile selection changes how evidence is grouped and how verdicts are produced.</div>`);
      }
    });
  });
}

function renderTileDetailPanel(title, subtitle, itemsHtml){
  const host = qs("#summary-panel");
  if(!host) return;
  host.innerHTML = `
    <div class="scan-insights">
      <div class="scan-section">
        <h4>${escapeHtml(title || "Scan Detail")}</h4>
        <div class="mini-help">${escapeHtml(subtitle || "")}</div>
      </div>
      <div class="scan-section">${itemsHtml || '<div class="muted">No additional detail available.</div>'}</div>
    </div>
  `;
}

function renderKpiDrilldown(report, key){
  const host = qs("#summary-panel");
  if(!host) return;
  const meta = ((report || {}).kpi_details || {})[key];
  if(!meta){
    host.innerHTML = '<div class="muted">No details available.</div>';
    return;
  }
  let body = "";
  if(key === "observability_score"){
    body = `<div class="evidence-list">` + (meta.parts || []).map(item=>`
      <div class="evidence-card">
        <div class="evidence-top">
          <strong>${escapeHtml(item.bucket || "")}</strong>
          <span class="status-pill ${escapeHtml(item.rating || "amber")}">${escapeHtml(item.rating || "amber")}</span>
        </div>
        <div class="kv-list" style="margin-top:8px">
          <div class="kv"><span>Evidence Count</span><strong>${escapeHtml(String(item.count || 0))}</strong></div>
          <div class="kv"><span>Target Evidence</span><strong>${escapeHtml(String(item.target_evidence || 0))}</strong></div>
          <div class="kv"><span>Score</span><strong>${escapeHtml(String(item.score || 0))}/${escapeHtml(String(item.weight || 0))}</strong></div>
        </div>
        <div class="mini-help" style="margin-top:8px">${escapeHtml(item.reason || "")}</div>
      </div>
    `).join("") + `</div>`;
  } else if(key === "signals_detected"){
    body = `<div class="evidence-list">` + (meta.parts || []).map(item=>`
      <div class="evidence-card">
        <strong>${escapeHtml(BUCKET_LABELS[item.bucket] || item.bucket || "")}</strong>
        <div class="kv" style="margin-top:8px"><span>Matched evidence items</span><strong>${escapeHtml(String(item.count || 0))}</strong></div>
      </div>
    `).join("") + `</div>`;
  } else if(key === "services_detected"){
    body = `<div class="evidence-list">` + (meta.parts || []).map(item=>`
      <div class="evidence-card">
        <strong>${escapeHtml(item.service || "")}</strong>
        <div class="mini-help" style="margin-top:8px">Detected from: ${escapeHtml(item.source || "service_id")}</div>
      </div>
    `).join("") + `</div>`;
  } else if(key === "vendor_tools"){
    body = (meta.parts || []).length ? `<div class="meta-chip-row">` + (meta.parts || []).map(item=>`<span class="meta-chip">${escapeHtml(item.tool || "")}</span>`).join("") + `</div>` : '<div class="muted">Not detected</div>';
  } else {
    body = '<div class="muted">No details available.</div>';
  }
  host.innerHTML = `
    <div class="scan-section">
      <h4>${escapeHtml(KPI_LABELS[key] || key)}</h4>
      <div class="mini-help">${escapeHtml(meta.reason || "")}</div>
      <div style="margin-top:12px">${body}</div>
    </div>
  `;
}

const KPI_LABELS = {
  observability_score: "Observability Score",
  signals_detected: "Signals Detected",
  services_detected: "Services Detected",
  vendor_tools: "Vendor Tools"
};

function bindTopKpiCards(report){
  qsa("#results-top-kpis .kpi-card").forEach((card)=>{
    card.addEventListener("click", ()=>{
      const key = card.dataset.kpi;
      if(key) renderKpiDrilldown(report, key);
    });
  });
}


function bindBucketCards(report){
  qsa("#bucket-grid .bucket-card").forEach(card=>{
    card.addEventListener("click", ()=>{
      const key = card.dataset.bucket;
      if(!key) return;
      const meta = (report.bucket_overview || {})[key];
      renderBucketDetail(key, meta);
    });
  });
}

function renderEvidenceItems(items){
  const list = Array.isArray(items) ? items : [];
  if(!list.length){
    return '<div class="muted">Not detected</div>';
  }
  return `<div class="evidence-list">` + list.map((item, idx)=>`
    <div class="evidence-card">
      <div class="evidence-top">
        <strong>${idx + 1}. ${escapeHtml(item.file || "Unknown file")}</strong>
        <span class="status-pill ${escapeHtml(item.severity || "amber")}">${escapeHtml(item.severity || "amber")}</span>
      </div>
      <div class="mini-help" style="margin-top:8px">Why this was counted</div>
      <div class="mini-help">${escapeHtml(item.why_counted || "The scanner matched one or more configured patterns in this file.")}</div>
      <div class="mini-help" style="margin-top:10px">Matched patterns</div>
      <div class="meta-chip-row" style="margin-top:8px">
        ${(item.patterns || []).length ? (item.patterns || []).map(p=>`<span class="meta-chip">${escapeHtml(String(p))}</span>`).join("") : '<span class="muted">No explicit pattern list.</span>'}
      </div>
    </div>
  `).join("") + `</div>`;
}

let scannerRegistry = [];

function renderScannerOptions(items){
  const live = qs("#scanner-profile");
  const batch = qs("#batch-scanner-profile");
  const fifo = qs("#fifo-scanner-profile");
  const multiscan = qs("#multiscan-scanner-profile");
  const livebulk = qs("#livebulk-scanner-profile");
  const newbulk = qs("#newbulk-scanner-profile");
  const fallback = [
    {id:"scanner_v1", label:"OBS Industry", visible:true},
    {id:"scanner_v2", label:"OBS Custom", visible:true}
  ];
  const source = Array.isArray(items) && items.length ? items : fallback;
  const visible = source.filter(x => x.visible !== false);
  const finalItems = visible.length ? visible : fallback;
  const optionsHtml = finalItems.map(item=>`<option value="${escapeHtml(item.id)}">${escapeHtml(item.label)}</option>`).join("");
  if(live){
    const current = live.value || "scanner_v1";
    live.innerHTML = optionsHtml;
    live.value = finalItems.some(x=>x.id === current) ? current : finalItems[0].id;
  }
  if(batch){
    const current = batch.value || "scanner_v1";
    batch.innerHTML = optionsHtml;
    batch.value = finalItems.some(x=>x.id === current) ? current : finalItems[0].id;
  }
  if(fifo){
    const current = fifo.value || "scanner_v1";
    fifo.innerHTML = optionsHtml;
    fifo.value = finalItems.some(x=>x.id === current) ? current : finalItems[0].id;
  }
  if(multiscan){
    const current = multiscan.value || "scanner_v1";
    multiscan.innerHTML = optionsHtml;
    multiscan.value = finalItems.some(x=>x.id === current) ? current : finalItems[0].id;
  }
  if(livebulk){
    const current = livebulk.value || "scanner_v1";
    livebulk.innerHTML = optionsHtml;
    livebulk.value = finalItems.some(x=>x.id === current) ? current : finalItems[0].id;
  }
  if(newbulk){
    const current = newbulk.value || "scanner_v1";
    newbulk.innerHTML = optionsHtml;
    newbulk.value = finalItems.some(x=>x.id === current) ? current : finalItems[0].id;
  }
}

function renderScannerRegistry(items){
  const host = qs("#scanner-registry-grid");
  if(!host) return;
  host.innerHTML = (items || []).map(item=>`
    <div class="scanner-registry-card">
      <div>
        <strong>${escapeHtml(item.label)}</strong>
        <div class="mini-help">${escapeHtml(item.id)} • ${item.built_in ? "Built-in profile" : "Discovered from scanners folder"}</div>
        <div class="mini-help wrap-anywhere">${escapeHtml(item.script_path || "")}</div>
      </div>
      <label class="switch">
        <input type="checkbox" class="scanner-visibility-toggle" data-scanner-id="${escapeHtml(item.id)}" ${item.visible === false ? "" : "checked"}>
        <span class="slider"></span>
      </label>
    </div>
  `).join("") || "No scanners found.";
  qsa(".scanner-visibility-toggle").forEach(el=>{
    el.addEventListener("change", ()=>{
      scannerRegistry = scannerRegistry.map(item => item.id === el.dataset.scannerId ? {...item, visible: !!el.checked} : item);
      renderScannerOptions(scannerRegistry);
    });
  });
}

async function loadScannerRegistry(){
  try{
    const res = await fetch("/config/scanners");
    const data = await res.json();
    if(data.status === "ok"){
      scannerRegistry = data.items || [];
      renderScannerOptions(scannerRegistry);
      renderScannerRegistry(scannerRegistry);
      return;
    }
  }catch(e){}
  renderScannerOptions([]);
  renderScannerRegistry(scannerRegistry && scannerRegistry.length ? scannerRegistry : [
    {id:"scanner_v1", label:"OBS Industry", built_in:true, visible:true, script_path:"observability_scanner.py"},
    {id:"scanner_v2", label:"OBS Custom", built_in:true, visible:true, script_path:"observability_scanner.py"}
  ]);
}

async function saveScannerRegistry(){
  const res = await fetch("/config/scanners", {
    method:"POST",
    headers:{"Content-Type":"application/json"},
    body: JSON.stringify({items: scannerRegistry})
  });
  const data = await res.json();
  if(data.status === "ok"){
    scannerRegistry = data.items || [];
    renderScannerOptions(scannerRegistry);
    renderScannerRegistry(scannerRegistry);
    alert("Scanner visibility saved.");
  } else {
    alert(data.message || "Could not save scanner visibility.");
  }
}


const MENU_KEYS = [
  ["dashboard","Dashboard"],
  ["scan","Live Scan"],
  ["applications","Scans Register"],
  ["details","Assessment Details"],
  ["enterprise","Enterprise Scan"],
  ["audit","Audit & History"],
  ["docs","Documentation"],
  ["admin","Administration"],
  ["settings","Settings"]
];
let menuVisibilityConfig = {};

function applyMenuVisibility(config){
  menuVisibilityConfig = {...config};
  qsa(".topnav .nav-btn").forEach(btn=>{
    const view = btn.dataset.view;
    btn.style.display = config[view] === false ? "none" : "";
  });
}

function renderMenuVisibilityConfig(config){
  const host = qs("#menu-visibility-grid");
  if(!host) return;
  host.innerHTML = MENU_KEYS.map(([key, label])=>`
    <div class="menu-visibility-card">
      <div>
        <strong>${escapeHtml(label)}</strong>
        <div class="mini-help">Toggle this top menu item on or off.</div>
      </div>
      <label class="switch">
        <input type="checkbox" class="menu-visibility-toggle" data-menu-key="${key}" ${config[key] === false ? "" : "checked"}>
        <span class="slider"></span>
      </label>
    </div>
  `).join("");
  qsa(".menu-visibility-toggle").forEach(el=>{
    el.addEventListener("change", ()=>{
      menuVisibilityConfig[el.dataset.menuKey] = !!el.checked;
    });
  });
}

async function loadMenuVisibilityConfig(){
  try{
    const res = await fetch("/config/menu-visibility");
    const data = await res.json();
    if(data.status === "ok"){
      applyMenuVisibility(data.menu_visibility || {});
      renderMenuVisibilityConfig(data.menu_visibility || {});
    }
  }catch(e){}
}

async function saveMenuVisibilityConfig(){
  const res = await fetch("/config/menu-visibility", {
    method:"POST",
    headers:{"Content-Type":"application/json"},
    body: JSON.stringify({menu_visibility: menuVisibilityConfig})
  });
  const data = await res.json();
  if(data.status === "ok"){
    applyMenuVisibility(data.menu_visibility || {});
    alert("Menu visibility saved.");
  } else {
    alert(data.message || "Could not save menu visibility.");
  }
}


function renderAppsRegister(items){
  const list = Array.isArray(items) ? items : [];
  const host = qs("#apps-register-table");
  const query=(qs("#app-search")?.value||"").trim().toLowerCase();
  if(!host){
    return;
  }
  if(!list.length){
    host.textContent = "No assessed applications saved yet.";
    return;
  }

  const filtered = list.filter(item=>{
    const blob = [
      item.application_name, item.repo_input, item.stack, item.archetype, item.maturity, item.tier,
      item.portfolio, item.owner, item.criticality,
      ...(item.service_ids||[]), ...(item.vendor_tools||[])
    ].join(" ").toLowerCase();
    return !query || blob.includes(query);
  });

  const totalEl = qs("#register-total");
  const l4El = qs("#register-l4");
  const l3El = qs("#register-l3");
  const l12El = qs("#register-l12");
  if(totalEl) totalEl.textContent = filtered.length;
  if(l4El) l4El.textContent = filtered.filter(x=>String(x.maturity||"").includes("L4")).length;
  if(l3El) l3El.textContent = filtered.filter(x=>String(x.maturity||"").includes("L3")).length;
  if(l12El) l12El.textContent = filtered.filter(x=>/L1|L2/.test(String(x.maturity||""))).length;

  if(!filtered.length){
    host.textContent = "No matching applications.";
    return;
  }

  host.innerHTML = `
    <div class="assessment-table-wrap">
      <table class="assessment-table scans-register-table">
        <thead>
          <tr>
            <th></th>
            <th>Application</th>
            <th>Repo</th>
            <th>Tier</th>
            <th>Score</th>
            <th>Maturity</th>
            <th>Services</th>
            <th>Tools</th>
            <th>Profile</th>
            <th>Profile</th>
            <th>Last Scan</th>
          </tr>
        </thead>
        <tbody>
          ${filtered.map((item, idx)=>{
            const report = normalizeReportFromRow(item);
            const services = (report.service_ids || item.service_ids || []);
            const tools = (report.vendor_tools || item.vendor_tools || []);
            const bucketEntries = Object.entries(report.bucket_overview || {});
            return `
              <tr class="assessment-main-row">
                <td><button class="expand-row-btn scans-expand-btn" data-scan-expand="${idx}">+</button></td>
                <td>${escapeHtml(item.application_name||"unknown")}</td>
                <td class="wrap-anywhere table-repo-cell">${escapeHtml(item.repo_input || "")}</td>
                <td>${escapeHtml(item.tier || "—")}</td>
                <td>${escapeHtml(String(item.score ?? "—"))}</td>
                <td><span class="status-pill ${item.score>=75?"completed":item.score>=40?"running":"failed"}">${escapeHtml(item.maturity || "—")}</span></td>
                <td>${services.length}</td>
                <td>${tools.length}</td>
                <td>${escapeHtml(item.scanner_profile === "scanner_v2" ? "OBS Custom" : "OBS Industry")}</td>
                <td>${formatDateTime(item.saved_at)}</td>
              </tr>
              <tr class="assessment-expand-row" id="scans-expand-${idx}">
                <td colspan="10">
                  <div class="assessment-expand-panel">
                    <div class="assessment-expand-grid">
                      <div class="assessment-expand-card">
                        <h4>Metadata</h4>
                        <div class="kv-list">
                          <div class="kv"><span>Application</span><strong>${escapeHtml(item.application_name||"unknown")}</strong></div>
                          <div class="kv"><span>Repo</span><strong class="wrap-anywhere">${escapeHtml(item.repo_input || "")}</strong></div>
                          <div class="kv"><span>Tier</span><strong>${escapeHtml(item.tier || "—")}</strong></div>
                          <div class="kv"><span>Portfolio</span><strong>${escapeHtml(item.portfolio || "—")}</strong></div>
                          <div class="kv"><span>Owner</span><strong>${escapeHtml(item.owner || "—")}</strong></div>
                          <div class="kv"><span>Criticality</span><strong>${escapeHtml(item.criticality || "—")}</strong></div>
                        </div>
                      </div>

                      <div class="assessment-expand-card">
                        <h4>Last Scan Outcomes</h4>
                        <div class="kv-list">
                          <div class="kv"><span>Score</span><strong>${escapeHtml(String(item.score ?? "—"))}</strong></div>
                          <div class="kv"><span>Maturity</span><strong>${escapeHtml(item.maturity || "—")}</strong></div>
                          <div class="kv"><span>Stack</span><strong>${escapeHtml(item.stack || "—")}</strong></div>
                          <div class="kv"><span>Archetype</span><strong>${escapeHtml(item.archetype || "—")}</strong></div>
                          <div class="kv"><span>Signals</span><strong>${Object.values(report.signal_counts || {}).reduce((a,b)=>a+Number(b||0),0)}</strong></div>
                        </div>
                      </div>
                    </div>

                    <div class="assessment-expand-grid" style="margin-top:14px">
                      <div class="assessment-expand-card">
                        <h4>Detected Services</h4>
                        <div class="meta-chip-row">
                          ${services.length ? services.slice(0,12).map(v=>`<span class="meta-chip">${escapeHtml(String(v))}</span>`).join("") : '<span class="muted">No services detected.</span>'}
                        </div>
                      </div>
                      <div class="assessment-expand-card">
                        <h4>Detected Tools</h4>
                        <div class="meta-chip-row">
                          ${tools.length ? tools.slice(0,10).map(v=>`<span class="meta-chip">${escapeHtml(String(v))}</span>`).join("") : '<span class="muted">No vendor tools detected.</span>'}
                        </div>
                      </div>
                    </div>

                    <div class="assessment-bucket-row">
                      ${bucketEntries.length ? bucketEntries.map(([k,v])=>`
                        <div class="assessment-mini-bucket">
                          <div class="mini-bucket-title">${escapeHtml(v.title || k)}</div>
                          <div class="mini-bucket-score">${escapeHtml(String(v.score || 0))}/${escapeHtml(String(v.weight || 0))}</div>
                          <div class="mini-progress"><div class="${bucketProgressClass(v.status || "green")}" style="width:${scoreWidth(v.score || 0, v.weight || 1)}%"></div></div>
                        </div>
                      `).join("") : '<div class="muted">No bucket breakdown available.</div>'}
                    </div>

                    <div class="assessment-expand-card" style="margin-top:14px">
                      <h4>Observations & Recommendations</h4>
                      <div class="split-two">
                        <div>
                          <strong>Strengths</strong>
                          <div class="meta-chip-row" style="margin-top:10px">
                            ${(report.strengths || []).length ? (report.strengths || []).slice(0,8).map(v=>`<span class="meta-chip">${escapeHtml(String(v))}</span>`).join("") : '<span class="muted">No strengths listed.</span>'}
                          </div>
                        </div>
                        <div>
                          <strong>Gaps</strong>
                          <div class="meta-chip-row" style="margin-top:10px">
                            ${(report.gaps || []).length ? (report.gaps || []).slice(0,8).map(v=>`<span class="meta-chip">${escapeHtml(String(v))}</span>`).join("") : '<span class="muted">No gaps listed.</span>'}
                          </div>
                        </div>
                      </div>
                    </div>

                    <div class="actions" style="margin-top:14px">
                      <button class="secondary-btn scans-load-btn" data-load-id="${item.id}">Load details</button><button class="secondary-btn scans-export-btn" data-export-id="${item.id}">Export This Scan</button>
                    </div>
                  </div>
                </td>
              </tr>
            `;
          }).join("")}
        </tbody>
      </table>
    </div>
  `;

  qsa(".scans-expand-btn").forEach(btn=>{
    btn.addEventListener("click", ()=>{
      const idx = btn.dataset.scanExpand;
      const row = qs(`#scans-expand-${idx}`);
      const isOpen = row.classList.contains("open");
      qsa(".assessment-expand-row").forEach(x=>x.classList.remove("open"));
      qsa(".scans-expand-btn").forEach(x=>x.textContent = "+");
      if(!isOpen){
        row.classList.add("open");
        btn.textContent = "–";
      }
    });
  });

  qsa(".scans-load-btn").forEach(btn=>{
    btn.addEventListener("click", ()=>{
      const item = filtered.find(x=>String(x.id) === btn.dataset.loadId);
      if(!item) return;
      renderBottomApp(normalizeReportFromRow(item), item);
      setPage("details");
    });
  });
  qsa(".scans-export-btn").forEach(btn=>{
    btn.addEventListener("click", ()=>{
      window.location.href = `/reports/export/scan/${btn.dataset.exportId}`;
    });
  });
}


function bucketPct(v){
  const n = Number(v || 0);
  return Math.max(0, Math.min(100, n));
}


function renderScanInsights(report){
  const host = document.createElement("div");
  host.className = "scan-insights";

  const totalSignals = Object.values(report.signal_counts || {}).reduce((a,b)=>a + Number(b||0), 0);
  const services = (report.inferred_services || report.service_ids || []).length;
  const scannerProfile = report.scanner_profile || "scanner_v1";
  const scanner2 = report.scanner2 || null;

  host.innerHTML = `
    <div class="scan-kpi-row">
      <div class="scan-kpi"><span>Signals</span><strong>${totalSignals}</strong></div>
      <div class="scan-kpi"><span>Services</span><strong>${services}</strong></div>
      <div class="scan-kpi"><span>Score</span><strong>${report.score}</strong></div>
      <div class="scan-kpi"><span>Profile</span><strong>${scannerProfile === "scanner_v2" ? "OBS Custom" : "OBS Industry"}</strong></div>
    </div>

    <div class="scan-section">
      <h4>Observations</h4>
      <div class="obs-row">
        <div><strong>Strong:</strong> ${(report.strengths||[]).join(", ") || "—"}</div>
        <div><strong>Gaps:</strong> ${(report.gaps||[]).join(", ") || "—"}</div>
      </div>
    </div>

    <div class="scan-section">
      <h4>Recommendations</h4>
      <div class="obs-row">
        <div><strong>Management:</strong> ${(report.management_focus||[]).map(x=>x.text||x).join(", ") || "—"}</div>
        <div><strong>Developers:</strong> ${(report.developer_focus||[]).map(x=>x.text||x).join(", ") || "—"}</div>
      </div>
    </div>
    ${
      scanner2 ? `
      <div class="scan-section">
        <h4>Scanner 2 Verdict</h4>
        <div class="obs-row">
          <div><strong>Verdict:</strong> ${escapeHtml(scanner2.verdict || "—")}</div>
          <div><strong>Commit:</strong> ${escapeHtml((scanner2.commit_hash || "—").slice(0,12) || "—")}</div>
        </div>
        <div class="scanner2-grid" style="margin-top:12px">
          ${Object.entries(scanner2.bucket_summary || {}).map(([name, item])=>`
            <div class="scanner2-card ${item.status || "amber"}">
              <div class="top-row"><strong>${escapeHtml(name)}</strong><span class="status-pill ${item.status || "amber"}">${escapeHtml(item.status || "amber")}</span></div>
              <div class="mini-bucket-score">${item.passed}/${item.total}</div>
            </div>
          `).join("")}
        </div>
      </div>` : ``
    }
  `;

  return host;
}

function normalizeReportFromRow(row){
  return Object.keys(row.report_json || {}).length ? row.report_json : {
    application_name: row.application_name,
    repository_input: row.repo_input,
    stack: row.stack,
    archetype: row.archetype,
    maturity: row.maturity,
    score: row.score,
    service_ids: row.service_ids || [],
    vendor_tools: row.vendor_tools || [],
    bucket_scores: row.bucket_scores || {},
    management_focus: [],
    developer_focus: [],
    strengths: [],
    gaps: []
  };
}

function renderAssessmentRegister(items){
  const host = qs("#assessment-register");
  const count = qs("#assessment-register-count");
  if(count) count.textContent = `${items.length} applications`;
  if(!host) return;
  if(!items.length){
    host.textContent = "No scanned applications yet.";
    return;
  }
  host.innerHTML = `
    <div class="assessment-table-wrap">
      <table class="assessment-table">
        <thead>
          <tr>
            <th></th>
            <th>Application</th>
            <th>Repo</th>
            <th>Tier</th>
            <th>Score</th>
            <th>Maturity</th>
            <th>Services</th>
            <th>Profile</th>
            <th>Profile</th>
            <th>Last Scan</th>
          </tr>
        </thead>
        <tbody>
          ${items.map((item, idx)=>{
            const report = normalizeReportFromRow(item);
            const serviceCount = (report.service_ids || item.service_ids || []).length;
            const bucketEntries = Object.entries(report.bucket_overview || {});
            return `
              <tr class="assessment-main-row" data-expand="${idx}">
                <td><button class="expand-row-btn" data-expand-btn="${idx}">+</button></td>
                <td>${escapeHtml(item.application_name || "unknown")}</td>
                <td class="wrap-anywhere table-repo-cell">${escapeHtml(item.repo_input || "")}</td>
                <td>${escapeHtml(item.tier || "—")}</td>
                <td>${escapeHtml(String(item.score ?? report.score ?? "—"))}</td>
                <td><span class="status-pill ${item.score>=75?"completed":item.score>=40?"running":"failed"}">${escapeHtml(item.maturity || report.maturity || "—")}</span></td>
                <td>${serviceCount}</td>
                <td>${formatDateTime(item.saved_at)}</td>
              </tr>
              <tr class="assessment-expand-row" id="assessment-expand-${idx}">
                <td colspan="8">
                  <div class="assessment-expand-panel">
                    <div class="assessment-expand-grid">
                      <div class="assessment-expand-card">
                        <h4>Metadata</h4>
                        <div class="kv-list">
                          <div class="kv"><span>Application</span><strong>${escapeHtml(item.application_name || "unknown")}</strong></div>
                          <div class="kv"><span>Repo</span><strong class="wrap-anywhere">${escapeHtml(item.repo_input || "")}</strong></div>
                          <div class="kv"><span>Tier</span><strong>${escapeHtml(item.tier || "—")}</strong></div>
                          <div class="kv"><span>Portfolio</span><strong>${escapeHtml(item.portfolio || "—")}</strong></div>
                          <div class="kv"><span>Owner</span><strong>${escapeHtml(item.owner || "—")}</strong></div>
                        </div>
                      </div>
                      <div class="assessment-expand-card">
                        <h4>Detected Services & Tools</h4>
                        <div class="meta-chip-row">
                          ${(report.service_ids || item.service_ids || []).slice(0,8).map(v=>`<span class="meta-chip">${escapeHtml(String(v))}</span>`).join("") || '<span class="muted">No services detected.</span>'}
                        </div>
                        <div class="meta-chip-row" style="margin-top:10px">
                          ${(report.vendor_tools || item.vendor_tools || []).slice(0,6).map(v=>`<span class="meta-chip">${escapeHtml(String(v))}</span>`).join("") || '<span class="muted">No vendor tools detected.</span>'}
                        </div>
                      </div>
                    </div>
                    <div class="assessment-bucket-row">
                      ${bucketEntries.length ? bucketEntries.map(([k,v])=>`
                        <div class="assessment-mini-bucket">
                          <div class="mini-bucket-title">${escapeHtml(v.title || k)}</div>
                          <div class="mini-bucket-score">${escapeHtml(String(v.score || 0))}/${escapeHtml(String(v.weight || 0))}</div>
                          <div class="mini-progress"><div class="${bucketProgressClass(v.status || "green")}" style="width:${scoreWidth(v.score || 0, v.weight || 1)}%"></div></div>
                        </div>
                      `).join("") : '<div class="muted">No bucket breakdown available.</div>'}
                    </div>
                    <div class="actions" style="margin-top:14px">
                      <button class="secondary-btn assessment-load-btn" data-load-id="${item.id}">Load in details view</button>
                    </div>
                  </div>
                </td>
              </tr>
            `;
          }).join("")}
        </tbody>
      </table>
    </div>
  `;
  qsa(".expand-row-btn").forEach(btn=>{
    btn.addEventListener("click", ()=>{
      const id = btn.dataset.expandBtn;
      const row = qs(`#assessment-expand-${id}`);
      const isOpen = row.classList.contains("open");
      qsa(".assessment-expand-row").forEach(x=>x.classList.remove("open"));
      qsa(".expand-row-btn").forEach(x=>x.textContent = "+");
      if(!isOpen){
        row.classList.add("open");
        btn.textContent = "–";
      }
    });
  });
  qsa(".assessment-load-btn").forEach(btn=>{
    btn.addEventListener("click", ()=>{
      const item = items.find(x=>String(x.id) === btn.dataset.loadId);
      if(!item) return;
      renderBottomApp(normalizeReportFromRow(item), item);
      const detailsTop = qs("#page-details");
      if(detailsTop) detailsTop.scrollIntoView({behavior:"smooth", block:"start"});
    });
  });
}

function renderBatchCurrent(data){
  const stage = qs("#batch-current-stage");
  const body = qs("#batch-current-body");
  if(!stage || !body) return;
  const items = data.items || [];
  const running = items.filter(x=>String(x.status||"").toLowerCase() === "running");
  const queued = items.filter(x=>String(x.status||"").toLowerCase() === "queued");
  const latestDone = items.filter(x=>["completed","failed"].includes(String(x.status||"").toLowerCase())).slice(-1)[0];
  const active = running[0] || queued[0] || latestDone;
  if(!active){
    stage.textContent = "Waiting to start.";
    body.textContent = "When batch scan starts, the current repository being processed will appear here.";
    return;
  }
  const status = String(active.status || "queued");
  stage.textContent = status === "running" ? "Scanning current repository..." : `Current state: ${status}`;
  const lines = [];
  lines.push(`Application: ${active.application_name || inferRepoDisplayName(active.repo_url)}`);
  lines.push(`Repository: ${active.repo_url || ""}`);
  lines.push(`Status: ${status}`);
  if(active.score !== undefined && active.score !== null) lines.push(`Score: ${active.score}`);
  if(active.maturity) lines.push(`Maturity: ${active.maturity}`);
  body.innerHTML = `
    <div class="batch-current-grid">
      <div class="batch-current-panel">
        <div class="repo-line wrap-anywhere">${escapeHtml(active.application_name || inferRepoDisplayName(active.repo_url))}</div>
        <div class="kv-list">
          <div class="kv"><span>Repo</span><strong class="wrap-anywhere">${escapeHtml(active.repo_url || "")}</strong></div>
          <div class="kv"><span>Status</span><strong>${escapeHtml(status)}</strong></div>
          <div class="kv"><span>Token</span><strong class="token-mask">${escapeHtml(maskTokenLike(active.token_alias || ""))}</strong></div>
        </div>
      </div>
      <div class="batch-current-panel">
        <div class="batch-current-terminal">${escapeHtml(lines.join("\n"))}</div>
      </div>
    </div>
  `;
  const card = qs("#batch-current-card");
  if(card && status === "running"){
    card.scrollIntoView({behavior:"smooth", block:"start"});
  }
}

function maskTokenLike(value){
  const raw = String(value || "");
  if(!raw) return "";
  if(raw.length <= 18) return raw;
  return raw.slice(0, 6) + "..." + raw.slice(-4);
}
function inferRepoDisplayName(repoUrl){
  const clean = String(repoUrl || "").trim();
  if(!clean) return "Repository";
  const tail = clean.split("/").filter(Boolean).pop() || "repository";
  return tail.replace(/^_git\//i, "").replace(/^_git/i, "");
}

function loadAdminStatus(){
  fetch("/api/admin").then(r=>r.json()).then(data=>{
    const mode = document.querySelector("#admin-db-mode");
    const file = document.querySelector("#admin-db-file");
    const status = document.querySelector("#admin-db-status");
    if(mode) mode.textContent = data.database_mode || "sqlite";
    if(file) file.textContent = data.database_file || "observability.db";
    if(status) status.textContent = "Ready";
  }).catch(()=>{});
}

function renderMetaGroup(title, values){
  const items = (values || []).filter(Boolean);
  return `
    <div class="metadata-card">
      <h4>${escapeHtml(title)}</h4>
      ${items.length ? `<div class="meta-chip-row">${items.map(v => `<span class="meta-chip">${escapeHtml(String(v))}</span>`).join("")}</div>` : `<div class="muted">No data detected.</div>`}
    </div>
  `;
}

function renderLandingPanels(landscape){
  const activityHost = qs("#recent-activity-panel");
  const recHost = qs("#landing-recommendations-panel");
  if(activityHost){
    fetch("/audit/history").then(r=>r.json()).then(data=>{
      const items = (data.items || []).slice(0,4);
      if(!items.length){
        activityHost.textContent = "No recent scans yet.";
        return;
      }
      activityHost.innerHTML = items.map(item => `
        <div class="activity-item">
          <div class="activity-left">
            <div class="activity-title">${escapeHtml((item.scan_type || "scan").toUpperCase())} #${item.id}</div>
            <div class="activity-meta">${escapeHtml(item.run_mode || "manual")} • ${escapeHtml(formatDateTime(item.started_at))}</div>
          </div>
          <div class="activity-badge">Score ${escapeHtml(String(item.avg_score ?? 0))}</div>
        </div>
      `).join("");
    }).catch(()=>{
      activityHost.textContent = "No recent scans yet.";
    });
  }
  if(recHost){
    const bucketScores = landscape?.bucket_average_scores || {};
    const sorted = Object.entries(bucketScores).sort((a,b)=>Number(a[1]) - Number(b[1])).slice(0,4);
    if(!sorted.length){
      recHost.textContent = "No recommendations yet.";
      return;
    }
    recHost.innerHTML = sorted.map(([bucket, score]) => `
      <div class="recommend-item">
        <div class="recommend-left">
          <div class="recommend-title">${escapeHtml(bucket)}</div>
          <div class="recommend-meta">Lower average score suggests focus area for portfolio improvement.</div>
        </div>
        <div class="recommend-badge">${escapeHtml(String(score))}</div>
      </div>
    `).join("");
    bindBucketCards(report);
    bindTopTileDrilldowns(report);
    const firstBucketKey = Object.keys(report.bucket_overview || {})[0];
    if(firstBucketKey){
      renderBucketDetail(firstBucketKey, (report.bucket_overview || {})[firstBucketKey]);
    }
  }
}

function setDashboardDetail(title, content){
  const host = qs("#dashboard-detail-panel");
  if(!host) return;
  host.innerHTML = `
    <div class="service-detail-grid">
      <div class="service-detail-card">
        <div class="kv"><span>Selection</span><strong>${escapeHtml(title)}</strong></div>
        <div class="mini-help" style="margin-top:12px">${escapeHtml(content)}</div>
      </div>
      <div class="service-detail-card">
        <div class="mini-help">Dashboard cards are clickable in this version so users can inspect what each KPI or chart is trying to communicate.</div>
      </div>
    </div>
  `;
}

function setDocsDetail(key){
  const host = qs("#docs-detail-panel");
  if(!host) return;
  const mapping = {
    "L1":"Foundational coverage: basic telemetry and limited operational visibility.",
    "L2":"Operational coverage: core telemetry supports monitoring and routine support.",
    "L3":"Distributed coverage: stronger cross-service instrumentation and correlation.",
    "L4":"Advanced coverage: broad observability adoption and stronger platform readiness.",
    "live-scan":"Use Live Scan to assess one repository directly with repo input and token.",
    "applications":"Use Applications to browse saved scans and compare saved maturity results.",
    "enterprise-scan":"Use Enterprise Scan to process repository inventories in controlled batch mode.",
    "audit-history":"Use Audit & History to inspect scan timelines, prior runs, and maturity movement."
  };
  host.innerHTML = `
    <div class="service-detail-card">
      <div class="mini-help">${escapeHtml(mapping[key] || "Documentation detail not available.")}</div>
    </div>
  `;
}

function bindClickableDocs(){
  qsa(".clickable-doc").forEach(el=>{
    el.addEventListener("click", ()=> setDocsDetail(el.dataset.doc || ""));
  });
}

const BUCKET_LABELS = {
  logging:"Logging",
  metrics:"Metrics",
  tracing:"Tracing",
  health:"Health",
  resilience:"Resilience",
  config:"Configuration",
  governance:"Governance",
  cloud_observability:"Cloud / Vendor"
};

function bucketMeaning(status){
  if(status === "green") return "Strong evidence is present for this bucket.";
  if(status === "amber") return "Partial evidence is present for this bucket. It likely needs deeper implementation or cleaner standards.";
  return "Little or no evidence is present for this bucket.";
}

function renderBucketDetail(bucketKey, bucketMeta){
  const host = qs("#bucket-detail-panel");
  if(!host || !bucketMeta) return;
  const sampleFiles = (bucketMeta.sample_files || []).slice(0,6);
  const evidenceItems = bucketMeta.evidence_items || [];
  const score = Number(bucketMeta.score || 0);
  const weight = Number(bucketMeta.weight || 0);
  const scoreDetail = (((currentReport || {}).bucket_score_details || {})[bucketKey]) || null;
  let reason = "No evidence was detected for this bucket, so it is red.";
  if(bucketMeta.status === "green"){
    reason = "This bucket is green because the score is strong and multiple evidence items were found.";
  } else if(bucketMeta.status === "amber"){
    reason = "This bucket is amber because some signals were found, but the evidence is not yet strong enough for green.";
  }

  host.innerHTML = `
    <div class="service-detail-grid">
      <div class="service-detail-card">
        <div class="kv-list">
          <div class="kv"><span>Bucket</span><strong>${escapeHtml(bucketMeta.title || bucketKey)}</strong></div>
          <div class="kv"><span>Status</span><strong>${escapeHtml(bucketMeta.status || "—")}</strong></div>
          <div class="kv"><span>Score</span><strong>${escapeHtml(String(score))}/${escapeHtml(String(weight))}</strong></div>
          <div class="kv"><span>Evidence</span><strong>${escapeHtml(bucketMeta.evidence_label || String(bucketMeta.evidence_count || 0))}</strong></div>
        </div>
      </div>
      <div class="service-detail-card">
        <div class="mini-help">${escapeHtml(reason)}</div>
        <div style="margin-top:10px"><strong>Why this score happened</strong></div>
        <div class="mini-help" style="margin-top:8px">
          ${scoreDetail ? escapeHtml(scoreDetail.reason || "") : "The scanner counts matched files and matched signal patterns for this bucket. More evidence increases the score."}
        </div>
        <div class="kv-list" style="margin-top:10px">
          <div class="kv"><span>Evidence Count</span><strong>${escapeHtml(String(scoreDetail?.count ?? bucketMeta.evidence_count ?? 0))}</strong></div>
          <div class="kv"><span>Target Evidence</span><strong>${escapeHtml(String(scoreDetail?.target_evidence ?? "—"))}</strong></div>
          <div class="kv"><span>Points Used</span><strong>${escapeHtml(String(scoreDetail?.evidence_points_used ?? "—"))}</strong></div>
        </div>
        <div style="margin-top:12px"><strong>Sample files</strong></div>
        <div class="sample-files" style="margin-top:8px">${sampleFiles.length ? escapeHtml(sampleFiles.join(", ")) : "Not detected"}</div>
      </div>
    </div>
    <div style="margin-top:16px">
      <h4>Matched Evidence</h4>
      ${renderEvidenceItems(evidenceItems)}
    </div>
  `;
}

function bucketCellMeaning(bucketKey, value){
  const label = BUCKET_LABELS[bucketKey] || bucketKey;
  if(value >= 4) return `${label} is strong for this service because there is repeated evidence for this bucket.`;
  if(value >= 2) return `${label} is partial for this service because only limited evidence was found.`;
  return `${label} is weak or not detected for this service.`;
}

function renderHeatmapDetail(serviceName, bucketKey, value, overall, maturity, source, technology="Not detected", evidenceCount=0){
  const host = qs("#heatmap-detail-panel");
  if(!host) return;
  host.innerHTML = `
    <div class="service-detail-grid">
      <div class="service-detail-card">
        <div class="kv-list">
          <div class="kv"><span>Service</span><strong class="wrap-anywhere">${escapeHtml(serviceName || "—")}</strong></div>
          <div class="kv"><span>Bucket</span><strong>${escapeHtml(BUCKET_LABELS[bucketKey] || bucketKey || "Overall")}</strong></div>
          <div class="kv"><span>Bubble Score</span><strong>${escapeHtml(String(value ?? overall ?? 0))}</strong></div>
          <div class="kv"><span>Maturity</span><strong>${escapeHtml(maturity || "—")}</strong></div>
        </div>
      </div>
      <div class="service-detail-card">
        <div class="mini-help">${escapeHtml(bucketKey ? bucketCellMeaning(bucketKey, Number(value || 0)) : "This shows the rolled-up overall service score.")}</div>
        <div style="margin-top:10px" class="kv-list">
          <div class="kv"><span>Detection Source</span><strong>${escapeHtml(source || "service_id")}</strong></div>
          <div class="kv"><span>Technology</span><strong>${escapeHtml(technology || "Not detected")}</strong></div>
          <div class="kv"><span>Bucket Evidence</span><strong>${escapeHtml(String(evidenceCount || 0))}</strong></div>
          <div class="kv"><span>Overall Service Score</span><strong>${escapeHtml(String(overall || 0))}</strong></div>
        </div>
      </div>
    </div>
    <div style="margin-top:16px">
      <h4>Evidence Details</h4>
      <div id="heatmap-evidence-items"></div>
    </div>
  `;
}

function bindInteractiveLinks(scope=document){
  scope.querySelectorAll(".repo-link").forEach(link=>{
    link.addEventListener("click", (e)=>{
      e.stopPropagation();
    });
  });
}

function asRepoLink(url){
  const raw = String(url || "").trim();
  if(!raw) return "—";
  const safe = escapeHtml(raw);
  if(/^https?:\/\//i.test(raw) || /^git@/i.test(raw)){
    return `<a class="linkish repo-link" href="${safe}" target="_blank" rel="noopener noreferrer" data-href="${safe}">${safe}</a>`;
  }
  return `<span class="wrap-anywhere">${safe}</span>`;
}

function bucketAccentClass(status){
  if(status === "green") return "green-accent";
  if(status === "amber") return "amber-accent";
  return "red-accent";
}
function bucketProgressClass(status){
  if(status === "green") return "progress-green";
  if(status === "amber") return "progress-amber";
  return "progress-red";
}
function scoreWidth(score, weight){
  const pct = weight ? Math.max(0, Math.min(100, Math.round((Number(score||0)/Number(weight||1))*100))) : 0;
  return pct;
}

const BUCKETS = ["logging","metrics","tracing","health","resilience","config","governance","cloud_observability"];
let currentReport = null;

function qs(s){return document.querySelector(s)}
function qsa(s){return Array.from(document.querySelectorAll(s))}
function escapeHtml(v){return String(v).replaceAll("&","&amp;").replaceAll("<","&lt;").replaceAll(">","&gt;")}

function applyTheme(theme){
  document.documentElement.setAttribute("data-theme", theme);
  const toggle = qs("#theme-toggle");
  const icon = qs("#theme-toggle-icon");
  if(toggle){
    toggle.setAttribute("aria-label", theme === "dark" ? "Switch to light mode" : "Switch to dark mode");
    toggle.setAttribute("title", theme === "dark" ? "Light mode" : "Dark mode");
  }
  if(icon){
    icon.textContent = theme === "dark" ? "☀︎" : "◐";
  }
  localStorage.setItem("obs_theme", theme);
}

function setPage(name){
  qsa(".page").forEach(p=>p.classList.remove("active"));
  const page = qs("#page-"+name);
  if(!page) return;
  page.classList.add("active");
  qsa(".nav-btn").forEach(b=>b.classList.toggle("active", b.dataset.view===name));
  if(name==="applications" || name==="dashboard") loadAssessments();
  if(name==="audit") loadAuditHistory();
  if(name==="docs") bindClickableDocs();
  if(name==="admin"){ loadAdminStatus(); loadScannerRegistry(); }
  if(name==="settings") loadMenuVisibilityConfig();
  if(name==="multiscan" && !multiscanPollHandle){ pollMultiScanStatus(); }
  if(name==="livebulk" && !liveBulkPollHandle){ pollLiveBulkStatus(); }
  if(name==="newbulk" && !newBulkPollHandle){ pollNewBulkStatus(); }
}

function appendLine(type,text){
  const div=document.createElement("div");
  div.className=`line ${type}`;
  div.textContent=text;
  const t=qs("#terminal");
  t.appendChild(div);
  t.scrollTop=t.scrollHeight;
}

function resetBucketCards(){
  BUCKETS.forEach(bucket=>{
    qs(`#score-${bucket}`).textContent="--";
    qs(`#result-${bucket}`).textContent="Waiting for detections";
    qs(`#feed-${bucket}`).innerHTML="";
    const badge=qs(`.bucket-live-card[data-bucket="${bucket}"] .bucket-badge`);
    badge.textContent="Running";
    badge.className="bucket-badge running";
  });
}

function setBucketBadge(bucket, level, text){
  const badge=qs(`.bucket-live-card[data-bucket="${bucket}"] .bucket-badge`);
  if(!badge) return;
  badge.textContent=text;
  badge.className=`bucket-badge ${level}`;
}

function pushBucketFeed(bucket, text){
  const feed=qs(`#feed-${bucket}`);
  if(!feed) return;
  const div=document.createElement("div");
  div.className="item";
  div.textContent=text;
  feed.prepend(div);
}

function updateBucketFromLine(type, line){
  const lower = line.toLowerCase();
  BUCKETS.forEach(bucket=>{
    const key = bucket.replace("_"," ");
    if(lower.includes(bucket) || lower.includes(key)){
      if(type==="pass"){
        setBucketBadge(bucket, "green", "Signal");
        qs(`#result-${bucket}`).textContent = line.replace(/^\[[A-Z]+\]\s*/, "");
        pushBucketFeed(bucket, line);
      } else if(type==="warn"){
        setBucketBadge(bucket, "amber", "Partial");
        qs(`#result-${bucket}`).textContent = line.replace(/^\[[A-Z]+\]\s*/, "");
        pushBucketFeed(bucket, line);
      } else if(type==="fail"){
        setBucketBadge(bucket, "red", "Missing");
        qs(`#result-${bucket}`).textContent = line.replace(/^\[[A-Z]+\]\s*/, "");
        pushBucketFeed(bucket, line);
      } else if(type==="result"){
        const clean=line.replace("[RESULT] ","");
        const parts=clean.split("=");
        if(parts.length===2 && parts[0].trim()===bucket){
          qs(`#score-${bucket}`).textContent = parts[1].trim();
          pushBucketFeed(bucket, `Final score ${parts[1].trim()}`);
        }
      }
    }
  });
}

function resetLive(){
  qs("#terminal").innerHTML="";
  qs("#live-evidence").textContent="No evidence yet.";
  qs("#green-count").textContent="0";
  qs("#amber-count").textContent="0";
  qs("#red-count").textContent="0";
  qs("#result-count").textContent="0";
  qs("#scan-pill").textContent="Running";
  qs("#scan-pill").className="pill blue";
  resetBucketCards();
}

function addEvidence(level,text){
  const box=qs("#live-evidence");
  if(box.textContent==="No evidence yet.") box.innerHTML="";
  const div=document.createElement("div");
  div.className="kv";
  div.innerHTML=`<span><span class="dot ${level}"></span> ${escapeHtml(text)}</span>`;
  box.prepend(div);
}

function updateCounters(type,line){
  if(type==="pass"){qs("#green-count").textContent=String(Number(qs("#green-count").textContent)+1);addEvidence("green",line)}
  if(type==="warn"){qs("#amber-count").textContent=String(Number(qs("#amber-count").textContent)+1);addEvidence("amber",line)}
  if(type==="fail"){qs("#red-count").textContent=String(Number(qs("#red-count").textContent)+1)}
  if(type==="result"){qs("#result-count").textContent=String(Number(qs("#result-count").textContent)+1)}
  updateBucketFromLine(type,line);
}

function renderSimpleList(target, items, formatter){
  const el=qs(target);
  if(!items || !items.length){el.textContent="No data available.";return;}
  el.innerHTML="<ul>"+items.slice(0,8).map(x=>`<li>${formatter?formatter(x):escapeHtml(String(x))}</li>`).join("")+"</ul>";
}

function renderServiceDetail(serviceRow, report){
  const host = qs("#service-detail-panel");
  if(!host){
    return;
  }
  if(!serviceRow){
    host.textContent = "Click a heatmap row to inspect a detected service.";
    return;
  }
  const bucketLabels = {
    logging:"Logging",
    metrics:"Metrics",
    tracing:"Tracing",
    health:"Health",
    resilience:"Resilience",
    config:"Configuration",
    governance:"Governance",
    cloud_observability:"Cloud / Vendor"
  };
  const bucketHtml = Object.entries(serviceRow.buckets || {}).map(([k,v]) => `
    <div class="kv"><span>${escapeHtml(bucketLabels[k] || k)}</span><strong>${escapeHtml(String(v))}/5</strong></div>
  `).join("");
  host.innerHTML = `
    <div class="service-detail-grid">
      <div class="service-detail-card">
        <div class="kv-list">
          <div class="kv"><span>Service</span><strong class="wrap-anywhere">${escapeHtml(serviceRow.service || "—")}</strong></div>
          <div class="kv"><span>Detection Source</span><strong>${escapeHtml(serviceRow.source || "service_id")}</strong></div>
          <div class="kv"><span>Overall</span><strong>${escapeHtml(String(serviceRow.overall || 0))}</strong></div>
          <div class="kv"><span>Maturity</span><strong>${escapeHtml(serviceRow.maturity || "—")}</strong></div>
        </div>
        <div class="service-chip-row">
          <span class="service-chip">${escapeHtml(serviceRow.service || "service")}</span>
          <span class="service-chip">${escapeHtml(serviceRow.source || "detected")}</span>
        </div>
      </div>
      <div class="service-detail-card">
        <div class="kv-list">${bucketHtml}</div>
      </div>
    </div>
  `;
  bindInteractiveLinks(qs("#selected-app-bottom"));
}

function renderHeatmap(report){
  const host = qs("#heatmap-panel");
  if(!host){
    return;
  }
  const rows = report.service_heatmap || [];
  if(!rows.length){
    host.textContent = "No service heatmap is available because no explicit services were detected.";
    renderHeatmapDetail("", "", "", 0, "", "", "Not detected", 0);
    return;
  }
  const bucketOrder = ["logging","metrics","tracing","health","resilience","config","governance","cloud_observability"];
  host.innerHTML = `
    <div class="heat-table">
      <div class="heat-head">
        <div class="heat-cell left"><strong>Service</strong></div>
        <div class="heat-cell"><strong>Log</strong></div>
        <div class="heat-cell"><strong>Met</strong></div>
        <div class="heat-cell"><strong>Trc</strong></div>
        <div class="heat-cell"><strong>Hlt</strong></div>
        <div class="heat-cell"><strong>Res</strong></div>
        <div class="heat-cell"><strong>Cfg</strong></div>
        <div class="heat-cell"><strong>Gov</strong></div>
        <div class="heat-cell"><strong>Cld</strong></div>
        <div class="heat-cell"><strong>Overall</strong></div>
      </div>
      ${rows.map((r, idx) => `
        <div class="heat-row" data-row-index="${idx}">
          <div class="heat-cell left heat-service-cell">${escapeHtml(r.service)}</div>
          ${bucketOrder.map(b => `<div class="heat-cell heat-bubble heat-${r.buckets[b]||0}" data-row-index="${idx}" data-bucket="${b}" data-value="${r.buckets[b]||0}" data-evidence="${(r.bucket_evidence||{})[b]||0}" data-tech="${escapeHtml(r.technology||"Not detected")}">${r.buckets[b]||0}</div>`).join("")}
          <div class="heat-cell heat-bubble" data-row-index="${idx}" data-bucket="" data-value="${r.overall||0}" data-evidence="0" data-tech="${escapeHtml(r.technology||"Not detected")}">${r.overall}</div>
        </div>
      `).join("")}
    </div>
  `;
  qsa(".heat-bubble").forEach(el=>{
    el.addEventListener("click", ()=>{
      const idx = Number(el.dataset.rowIndex || 0);
      const row = rows[idx];
      renderHeatmapDetail(row.service, el.dataset.bucket || "", el.dataset.value || "", row.overall, row.maturity, row.source);
    });
  });
  if(rows.length){
    renderHeatmapDetail(rows[0].service, "logging", rows[0].buckets?.logging || 0, rows[0].overall, rows[0].maturity, rows[0].source);
  }
}

function renderBuckets(report){
  const grid=qs("#bucket-grid");
  const entries=Object.entries(report.bucket_overview||{});
  if(!entries.length){grid.textContent="No buckets yet.";return;}
  grid.innerHTML=entries.map(([k,v])=>{
    const width = scoreWidth(v.score, v.weight);
    const sampleFiles = (v.sample_files||[]).slice(0,2).join(", ") || "—";
    return `
      <div class="bucket-report-card ${bucketAccentClass(v.status)}" data-bucket-key="${escapeHtml(k)}">
        <div class="top-row">
          <div class="bucket-report-title">${escapeHtml(v.title)}</div>
          <span class="status-dot ${escapeHtml(v.status)}"></span>
        </div>
        <div class="score-line">
          <span>Score</span>
          <strong>${v.score}/${v.weight}</strong>
        </div>
        <div class="mini-progress"><div class="${bucketProgressClass(v.status)}" style="width:${width}%"></div></div>
        <div class="kv-list">
          <div class="kv"><span>Evidence</span><strong>${v.evidence_count}<span class="meta-badge">signals</span></strong></div>
          <div class="kv"><span>Sample files</span><strong class="sample-files">${escapeHtml(sampleFiles)}</strong></div>
        </div>
      </div>
    `;
  }).join("");
  qsa(".bucket-report-card").forEach((card, idx)=>{
    card.addEventListener("click", ()=>{
      const [bucketKey, bucketMeta] = entries[idx];
      renderBucketDetail(bucketKey, bucketMeta);
    });
  });
  if(entries.length){
    renderBucketDetail(entries[0][0], entries[0][1]);
  }
}

function renderResults(report){
  currentReport=report;
  qs("#overall-score").textContent=report.score;
  qs("#overall-maturity").textContent=`${report.maturity} • ${report.stack} • ${report.archetype}`;
  const appEl = qs("#current-application"); if(appEl) appEl.textContent = report.application_name || "—";
  const repoEl = qs("#current-repository"); if(repoEl) repoEl.textContent = report.repository_input || "—";
  const sigSvcEl = qs("#current-signals-services"); if(sigSvcEl) sigSvcEl.textContent = `${Object.values(report.signal_counts || {}).reduce((a,b)=>a + Number(b||0), 0)} / ${(report.inferred_services || report.service_ids || []).length}`;
  const signalCount = Object.values(report.signal_counts || {}).reduce((a,b)=>a + Number(b||0), 0);
  const serviceCount = (report.inferred_services || []).length;
  const overallHost = qs("#overall-maturity");
  const bucketGrid = qs("#bucket-grid");
  const insightsHost = qs("#summary-panel");
  if(insightsHost){ insightsHost.innerHTML = ""; insightsHost.appendChild(renderScanInsights(report)); }
  let kpiWrap = document.getElementById("results-top-kpis");
  if(!kpiWrap && bucketGrid){
    kpiWrap = document.createElement("div");
    kpiWrap.id = "results-top-kpis";
    kpiWrap.className = "results-top-kpis";
    bucketGrid.parentElement.insertBefore(kpiWrap, bucketGrid);
  }
  if(kpiWrap){
    kpiWrap.innerHTML = `
      <button class="kpi-card" type="button" data-kpi="observability_score"><div class="kpi-label">Observability Score</div><div class="kpi-value">${report.score}</div><div class="kpi-sub">${escapeHtml(report.maturity || "—")}</div><div class="kpi-bar"><div class="kpi-bar-fill" style="width:${Math.max(0,Math.min(100, Number(report.score||0)))}%"></div></div><div class="bucket-click-hint">Click for scoring breakdown</div></button>
      <button class="kpi-card" type="button" data-kpi="signals_detected"><div class="kpi-label">Signals Detected</div><div class="kpi-value">${signalCount}</div><div class="kpi-sub">Across enabled buckets</div><div class="bucket-click-hint">Click for signal counts</div></button>
      <button class="kpi-card" type="button" data-kpi="services_detected"><div class="kpi-label">Services Detected</div><div class="kpi-value">${serviceCount}</div><div class="kpi-sub">${serviceCount ? "Explicit service IDs" : "No explicit services"}</div><div class="bucket-click-hint">Click for service evidence</div></button>
      <button class="kpi-card" type="button" data-kpi="vendor_tools"><div class="kpi-label">Vendor Tools</div><div class="kpi-value">${(report.vendor_tools||[]).length}</div><div class="kpi-sub">${escapeHtml((report.vendor_tools||[]).slice(0,2).join(", ") || "None detected")}</div><div class="bucket-click-hint">Click for vendor evidence</div></button>
      <div class="kpi-card"><div class="kpi-label">Scanner Profile</div><div class="kpi-value">${escapeHtml(report.scanner_profile === "scanner_v2" ? "OBS Custom" : "OBS Industry")}</div><div class="kpi-sub">${escapeHtml(report.scanner_profile || "scanner_v1")}</div></div>
    `;
    qsa("#results-top-kpis .kpi-card").forEach((card, idx)=>{
      const titles = ["Observability Score","Signals Detected","Services Detected","Vendor Tools","Scanner Profile"];
      const texts = [
        "This is the normalized rolled-up observability score for the application.",
        "This is the total count of detected signals across enabled buckets.",
        "This is the count of explicit detected service identifiers used for service-level summaries.",
        "This is the number of detected vendor observability tools.",
        "This is the scanner profile used to generate this assessment."
      ];
      card.addEventListener("click", ()=> renderBucketDetail("summary", {title: titles[idx], status:"green", score: report.score || 0, weight: 100, evidence_count: signalCount || 0, sample_files:[texts[idx]]}));
    });
  }
  qs("#summary-panel").innerHTML=`
    <div class="kv-list">
      <div class="kv"><span>Application</span><strong>${escapeHtml(report.application_name||"unknown")}</strong></div>
      <div class="kv"><span>Repository</span><strong class="wrap-anywhere">${asRepoLink(report.repository_input)}</strong></div>
      <div class="kv"><span>Stack</span><strong>${escapeHtml(report.stack)}</strong></div>
      <div class="kv"><span>Archetype</span><strong>${escapeHtml(report.archetype)}</strong></div>
      <div class="kv"><span>Inferred Tier</span><strong>${escapeHtml(report.inferred_tier || "Not inferred")}</strong></div>
      <div class="kv"><span>Files scanned</span><strong>${report.files_scanned}</strong></div>
      <div class="kv"><span>Scan errors</span><strong>${report.scan_errors}</strong></div>
      <div class="kv"><span>Duration</span><strong>${report.duration_seconds}s</strong></div>
    </div>
  `;
  bindInteractiveLinks(qs("#summary-panel"));
  qs("#tier-override").value = report.inferred_tier || "";
  renderBuckets(report);
  renderHeatmap(report);
  renderSimpleList("#strengths", report.strengths);
  renderSimpleList("#gaps", report.gaps);
  renderSimpleList("#mgmt-recs", report.management_focus, x=>`${escapeHtml(x.bucket)} — ${escapeHtml(x.text)}`);
  renderSimpleList("#dev-recs", report.developer_focus, x=>`${escapeHtml(x.bucket)} — ${escapeHtml(x.text)}`);
  const assetMeta = report.asset_metadata || {};
  qs("#metadata-panel").innerHTML = `
    <div class="metadata-grid">
      ${renderMetaGroup("Application Names", assetMeta.application_names || [])}
      ${renderMetaGroup("App Service IDs", assetMeta.app_service_ids || [])}
      ${renderMetaGroup("Business Service IDs", assetMeta.business_service_ids || [])}
      ${renderMetaGroup("Technologies", assetMeta.technologies || [])}
      ${renderMetaGroup("Change Template IDs", assetMeta.change_template_ids || [])}
      ${renderMetaGroup("Vendor Tools", report.vendor_tools || [])}
    </div>
  `;
  Object.entries(report.bucket_overview||{}).forEach(([bucket, meta])=>{
    if(qs(`#score-${bucket}`)) qs(`#score-${bucket}`).textContent = `${meta.score}/${meta.weight}`;
    if(qs(`#result-${bucket}`)) qs(`#result-${bucket}`).textContent = `${meta.evidence_count} evidence items detected`;
    setBucketBadge(bucket, meta.status, meta.status === "green" ? "Complete" : meta.status === "amber" ? "Partial" : "Gap");
  });
}

function formatDateTime(value){
  if(!value) return "—";
  try{
    return new Date(value).toLocaleString();
  }catch{
    return value;
  }
}

function freshnessBadge(value){
  if(!value) return '<span class="fresh-badge fresh-red">No Scan</span>';
  const now = new Date();
  const then = new Date(value);
  const diffDays = (now - then) / (1000 * 60 * 60 * 24);
  if(diffDays < 7) return '<span class="fresh-badge fresh-green">Fresh</span>';
  if(diffDays < 30) return '<span class="fresh-badge fresh-amber">Ageing</span>';
  return '<span class="fresh-badge fresh-red">Stale</span>';
}

async function loadAuditHistory(){
  const res = await fetch("/audit/history");
  const data = await res.json();
  if(data.status !== "ok") return;
  renderAuditRuns(data.items || []);
}

function renderAuditRuns(items){
  const host = qs("#audit-runs-grid");
  const summary = qs("#last-scan-summary");
  if(!host || !summary) return;
  if(!items.length){
    host.textContent = "No scan runs yet.";
    summary.textContent = "No scan history yet.";
    return;
  }
  const latest = items[0];
  summary.innerHTML = `
    <div class="kv-list">
      <div class="kv"><span>Last Run Type</span><strong>${escapeHtml(latest.scan_type || "—")}</strong></div>
      <div class="kv"><span>Started</span><strong>${formatDateTime(latest.started_at)}</strong></div>
      <div class="kv"><span>Finished</span><strong>${formatDateTime(latest.finished_at)}</strong></div>
      <div class="kv"><span>Repositories</span><strong>${latest.repo_count ?? 0}</strong></div>
      <div class="kv"><span>Average Score</span><strong>${latest.avg_score ?? 0}</strong></div>
    </div>
  `;
  host.innerHTML = items.map(item=>`
    <div class="app-card inventory-card">
      <div class="top-row">
        <strong>${escapeHtml((item.scan_type || "scan").toUpperCase())} #${item.id}</strong>
        <span class="status-pill completed">${escapeHtml(item.run_mode || "manual")}</span>
      </div>
      <div class="kv-list">
        <div class="kv"><span>Started</span><strong>${formatDateTime(item.started_at)}</strong></div>
        <div class="kv"><span>Finished</span><strong>${formatDateTime(item.finished_at)}</strong></div>
        <div class="kv"><span>Repo Count</span><strong>${item.repo_count ?? 0}</strong></div>
        <div class="kv"><span>Average Score</span><strong>${item.avg_score ?? 0}</strong></div>
      </div>
    </div>
  `).join("");
}

async function loadApplicationHistory(applicationName){
  if(!applicationName) return;
  const res = await fetch(`/audit/application-history?application_name=${encodeURIComponent(applicationName)}`);
  const data = await res.json();
  if(data.status !== "ok") return;
  renderApplicationHistory(data.items || [], applicationName);
}

function renderApplicationHistory(items, applicationName){
  const host = qs("#application-history-grid");
  if(!host) return;
  if(!items.length){
    host.textContent = `No history for ${applicationName}.`;
    return;
  }
  host.innerHTML = items.map((item, idx)=>{
    const previous = items[idx + 1];
    const delta = previous ? (Number(item.score || 0) - Number(previous.score || 0)) : null;
    const deltaText = delta === null ? "New" : (delta > 0 ? `+${delta}` : String(delta));
    return `
      <div class="app-card inventory-card">
        <div class="top-row">
          <strong>${escapeHtml(applicationName)}</strong>
          ${freshnessBadge(item.saved_at)}
        </div>
        <div class="kv-list">
          <div class="kv"><span>Scanned</span><strong>${formatDateTime(item.saved_at)}</strong></div>
          <div class="kv"><span>Score</span><strong>${item.score ?? 0}</strong></div>
          <div class="kv"><span>Maturity</span><strong>${escapeHtml(item.maturity || "—")}</strong></div>
          <div class="kv"><span>Change</span><strong>${deltaText}</strong></div>
          <div class="kv"><span>Type</span><strong>${escapeHtml(item.scan_type || "single")}</strong></div>
        </div>
      </div>
    `;
  }).join("");
}

async function loadAssessments(){
  const res = await fetch("/assessments");
  const data = await res.json();
  if(data.status !== "ok") return;
  assessmentCache = data.items || [];
  renderLandscape(data.landscape);
  renderApps(assessmentCache);
  renderAssessmentRegister(assessmentCache);
  if(assessmentCache.length && !currentReport){
    renderBottomApp(normalizeReportFromRow(assessmentCache[0]), assessmentCache[0]);
  }
}

function renderLandscape(landscape){
  qs("#metric-total-apps").textContent = landscape.total_applications || 0;
  const mc = landscape.maturity_counts || {};
  qs("#metric-maturity-mix").textContent = `${mc.L1||0} / ${mc.L2||0} / ${mc.L3||0} / ${mc.L4||0}`;
  const ta = landscape.tier_average_scores || {};
  qs("#metric-tier-summary").textContent = `T1:${ta.T1||0} T2:${ta.T2||0} T3:${ta.T3||0} T4:${ta.T4||0}`;

  const maturityRows = ["L1","L2","L3","L4"].map(level => `
    <div class="chart-row" data-detail-title="${level} maturity" data-detail-text="Applications currently grouped at ${level}.">
      <div class="top-row"><strong>${level}</strong><span>${mc[level]||0}</span></div>
      <div class="bar-wrap"><div class="bar"><div class="bar-fill" style="width:${Math.min(100, (mc[level]||0) * 12)}%"></div></div></div>
    </div>`).join("") || "No saved assessments yet.";
  qs("#maturity-chart").innerHTML = maturityRows;

  const tierRows = Object.entries(ta).map(([tier, score]) => `
    <div class="chart-row" data-detail-title="${escapeHtml(tier)} average" data-detail-text="Average observability score for ${escapeHtml(tier)} applications.">
      <div class="top-row"><strong>${escapeHtml(tier)}</strong><span>${score}</span></div>
      <div class="bar-wrap"><div class="bar"><div class="bar-fill" style="width:${Math.min(100, Number(score))}%"></div></div></div>
    </div>`).join("") || "No saved assessments yet.";
  qs("#tier-landscape").innerHTML = tierRows;

  const ba = landscape.bucket_average_scores || {};
  const bucketRows = Object.entries(ba).map(([bucket, score]) => `
    <div class="chart-row" data-detail-title="${escapeHtml(bucket)} coverage" data-detail-text="Average score across saved applications for ${escapeHtml(bucket)}.">
      <div class="top-row"><strong>${escapeHtml(bucket)}</strong><span>${score}</span></div>
      <div class="bar-wrap"><div class="bar"><div class="bar-fill" style="width:${Math.min(100, Number(score) * 6)}%"></div></div></div>
    </div>`).join("") || "No saved assessments yet.";
  qs("#bucket-landscape").innerHTML = bucketRows;

  const sortedBuckets = Object.entries(ba).sort((a,b)=>a[1]-b[1]);
  const gapRows = sortedBuckets.map(([bucket, score]) => `
    <div class="chart-row" data-detail-title="${escapeHtml(bucket)} gap" data-detail-text="Lower values indicate more room to improve in ${escapeHtml(bucket)}.">
      <div class="top-row"><strong>${escapeHtml(bucket)}</strong><span>${score}</span></div>
      <div class="bar-wrap"><div class="bar"><div class="bar-fill" style="width:${Math.min(100, Number(score) * 6)}%"></div></div></div>
    </div>`).join("") || "No saved assessments yet.";
  qs("#priority-gaps").innerHTML = gapRows;

  qsa(".chart-row").forEach(row=>{
    row.addEventListener("click", ()=> setDashboardDetail(row.dataset.detailTitle || "Chart", row.dataset.detailText || ""));
  });

  renderLandingPanels(landscape);
  const actCard = qs("#recent-activity-card");
  if(actCard) actCard.addEventListener("click", ()=> setDashboardDetail("Recent Scan Activity", "Shows the latest single and enterprise scan runs with mode and average score."));
  const recCard = qs("#landing-recommendations-card");
  if(recCard) recCard.addEventListener("click", ()=> setDashboardDetail("Recommended Focus Areas", "Shows the portfolio buckets with the lowest average coverage so teams know where to improve."));
  qsa(".metric-card").forEach((card, idx)=>{
    const titles = ["Applications assessed","Maturity mix","Tier averages"];
    const texts = [
      "This shows how many applications are currently saved in the platform.",
      "This summarizes the current L1 to L4 distribution.",
      "This summarizes average observability score by tier."
    ];
    card.addEventListener("click", ()=> setDashboardDetail(titles[idx] || "Metric", texts[idx] || ""));
  });
}

function renderApps(items){
  const list = Array.isArray(items) ? items : [];
  renderAppsRegister(list);
}

function renderBottomApp(report, row){
  const normalized = Object.keys(report).length ? report : {
    application_name: row.application_name,
    repository_input: row.repo_input,
    stack: row.stack,
    archetype: row.archetype,
    maturity: row.maturity,
    score: row.score,
    service_ids: row.service_ids || [],
    vendor_tools: row.vendor_tools || [],
    bucket_scores: row.bucket_scores || {},
    management_focus: [],
    developer_focus: [],
    strengths: [],
    gaps: []
  };
  renderResults(normalized);
  qs("#selected-app-bottom").innerHTML=`
    <div class="kv-list">
      <div class="kv"><span>Application</span><strong>${escapeHtml(row.application_name||"unknown")}</strong></div>
      <div class="kv"><span>Tier</span><strong>${escapeHtml(row.tier || "Unassigned")}</strong></div>
      <div class="kv"><span>Portfolio</span><strong>${escapeHtml(row.portfolio || "—")}</strong></div>
      <div class="kv"><span>Last Scan</span><strong>${formatDateTime(row.saved_at)}</strong></div>
      <div class="kv"><span>Focus Gaps</span><strong>${escapeHtml((normalized.gaps||[]).slice(0,3).join(", ") || "None")}</strong></div>
    </div>
  `;
  bindInteractiveLinks(qs("#selected-app-bottom"));
}

function startScan(){
  const repoInput=qs("#repo_input").value.trim();
  const token=qs("#token").value.trim();
  const scannerProfile=(qs("#scanner-profile")?.value||"scanner_v1");
  resetLive();
  setPage("scan");
  fetch("/start-scan",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({repo_input:repoInput,token:token,scanner_profile:scannerProfile})})
    .then(r=>r.json())
    .then(data=>{
      if(data.status!=="started"){
        appendLine("fail", `[FAIL] ${data.message||"Could not start scan"}`);
        qs("#scan-pill").textContent="Error";
        qs("#scan-pill").className="pill red";
        return;
      }
      const evt=new EventSource("/scan-stream");
      evt.onmessage=function(event){
        const payload=JSON.parse(event.data);
        appendLine(payload.type,payload.line);
        updateCounters(payload.type,payload.line);
        if(payload.type==="done"){
          try{
            const report=JSON.parse(payload.line.replace("[DONE] ",""));
            renderResults(report);
            qs("#scan-pill").textContent="Completed";
            qs("#scan-pill").className="pill green";
            setPage("details");
          }catch{
            qs("#scan-pill").textContent="Parse error";
            qs("#scan-pill").className="pill red";
          }
        }
        if(payload.type==="fail"){
          qs("#scan-pill").textContent="Failed";
          qs("#scan-pill").className="pill red";
        }
        if(payload.type==="complete") evt.close();
      };
    })
    .catch(err=>{
      appendLine("fail", `[FAIL] Could not start scan: ${err}`);
      qs("#scan-pill").textContent="Error";
      qs("#scan-pill").className="pill red";
    });
}

function loadLast(){
  fetch("/last-report").then(r=>r.json()).then(data=>{
    if(data.status!=="ok") return alert("No last report available.");
    renderResults(data.report);
    setPage("details");
  });
}

function saveCurrent(){
  if(!currentReport) return alert("No current report to save.");
  const payload = {
    report: currentReport,
    tier_override: qs("#tier-override").value,
    portfolio: qs("#portfolio-input").value,
    criticality: qs("#criticality-input").value,
    owner: qs("#owner-input").value,
    notes: qs("#notes-input").value
  };
  fetch("/save-assessment", {method:"POST", headers:{"Content-Type":"application/json"}, body:JSON.stringify(payload)})
    .then(r=>r.json()).then(data=>{
      alert(data.status === "ok" ? "Saved to database." : (data.message || "Save failed."));
      loadAssessments();
    });
}

const DEFAULT_BUCKETS = {
  logging:{enabled:true,weight:15,threshold:"normal",title:"Logging"},
  metrics:{enabled:true,weight:15,threshold:"normal",title:"Metrics"},
  tracing:{enabled:true,weight:15,threshold:"normal",title:"Tracing"},
  health:{enabled:true,weight:15,threshold:"normal",title:"Health"},
  resilience:{enabled:true,weight:10,threshold:"normal",title:"Resilience"},
  config:{enabled:true,weight:10,threshold:"normal",title:"Configuration"},
  governance:{enabled:true,weight:10,threshold:"normal",title:"Governance"},
  cloud_observability:{enabled:true,weight:10,threshold:"normal",title:"Cloud / Vendor"}
};

let currentConfig = {db_enabled:true, db_path:"", buckets: JSON.parse(JSON.stringify(DEFAULT_BUCKETS)), token_aliases:{azure_pat_main:"", azure_pat_secondary:""}};

let enterpriseInventory = [];
let batchPollHandle = null;

function parseInventoryText(){
  const raw = qs("#inventory-text")?.value || "";
  const lines = raw.split(/\r?\n/).map(x=>x.trim()).filter(Boolean);
  enterpriseInventory = lines.map(line=>{
    const parts = line.split(",").map(x=>x.trim());
    if(parts.length === 2){
      const repoUrl = parts[0] || "";
      const tokenAlias = parts[1] || "azure_pat_main";
      return {
        application_name: inferRepoDisplayName(repoUrl),
        repo_url: repoUrl,
        token_alias: tokenAlias,
        tier: "",
        portfolio: "",
        owner: "",
        criticality: "",
        enabled: true,
        notes: ""
      };
    }
    if(parts.length === 3 && /^https?:/i.test(parts[1] || "")){
      return {
        application_name: parts[0] || inferRepoDisplayName(parts[1]),
        repo_url: parts[1] || "",
        token_alias: parts[2] || "azure_pat_main",
        tier: "",
        portfolio: "",
        owner: "",
        criticality: "",
        enabled: true,
        notes: ""
      };
    }
    return {
      application_name: parts[0] || inferRepoDisplayName(parts[1] || parts[0] || ""),
      repo_url: parts[1] || parts[0] || "",
      token_alias: parts[2] || "azure_pat_main",
      tier: parts[3] || "",
      portfolio: parts[4] || "",
      owner: parts[5] || "",
      criticality: parts[6] || "",
      enabled: String(parts[7] || "true").toLowerCase() !== "false",
      notes: parts[8] || ""
    };
  }).filter(x=>x.repo_url);
  renderEnterpriseInventory();
}

function renderEnterpriseInventory(){
  const host = qs("#inventory-grid");
  const count = qs("#inventory-count");
  if(count) count.textContent = `${enterpriseInventory.length} repositories loaded`;
  if(!host) return;
  if(!enterpriseInventory.length){
    host.textContent = "No inventory parsed yet.";
    return;
  }
  host.innerHTML = enterpriseInventory.map(item=>`
    <div class="app-card inventory-card">
      <div class="top-row">
        <strong class="wrap-anywhere">${escapeHtml(item.application_name || inferRepoDisplayName(item.repo_url))}</strong>
        <span class="status-pill ${item.enabled === false ? "failed" : "completed"}">${item.enabled === false ? "Disabled" : "Open"}</span>
      </div>
      <div class="kv-list">
        <div class="kv"><span>Repo</span><strong class="wrap-anywhere inventory-repo">${escapeHtml(item.repo_url || "")}</strong></div>
        <div class="kv"><span>Token</span><strong class="token-mask">${escapeHtml(maskTokenLike(item.token_alias || ""))}</strong></div>
        <div class="kv"><span>Profile</span><strong>${escapeHtml(item.scanner_profile === "scanner_v2" ? "OBS Custom" : "OBS Industry")}</strong></div>
        <div class="kv"><span>Tier</span><strong>${escapeHtml(item.tier || "—")}</strong></div>
      </div>
    </div>
  `).join("");
}

function loadSampleInventory(){
  const sample = [
    "https://dev.azure.com/org/proj/_git/claims-api,azure_pat_main",
    "https://dev.azure.com/org/proj/_git/member-ui,azure_pat_main",
    "https://dev.azure.com/org/proj/_git/provider-worker,azure_pat_secondary"
  ].join("\n");
  const box = qs("#inventory-text");
  if(box) box.value = sample;
  parseInventoryText();
}

function renderBatchStatus(data){
  const summary = data.summary || {};
  const items = data.items || [];
  const total = Number(summary.total || 0);
  const done = Number(summary.completed || 0) + Number(summary.failed || 0);
  const pct = total ? Math.round((done / total) * 100) : 0;

  const fill = qs("#batch-progress-fill");
  if(fill) fill.style.width = `${pct}%`;

  const summaryText = qs("#batch-summary-text");
  if(summaryText){
    summaryText.textContent = total ? `${done} of ${total} repositories processed` : "No batch started.";
  }

  const mapValue = (id, value) => { const el = qs(id); if(el) el.textContent = value; };
  mapValue("#batch-total-kpi", total);
  mapValue("#batch-running-kpi", Number(summary.running || 0));
  mapValue("#batch-completed-kpi", Number(summary.completed || 0));
  mapValue("#batch-queued-kpi", Number(summary.queued || 0));
  mapValue("#batch-avg-score-kpi", Number(summary.avg_score || 0));
  mapValue("#batch-completed-count", `${Number(summary.completed || 0)} complete`);

  const runningHost = qs("#batch-running-grid");
  if(runningHost){
    const runningItems = items.filter(x => String(x.status || "").toLowerCase() === "running");
    runningHost.innerHTML = runningItems.length ? runningItems.map(item => `
      <div class="parallel-scan-card">
        <div class="top-row">
          <strong class="wrap-anywhere">${escapeHtml(item.application_name || inferRepoDisplayName(item.repo_url))}</strong>
          <span class="status-pill running">${escapeHtml(item.phase || "Running")}</span>
        </div>
        <div class="ring-line">
          <div class="mini-ring"><span>${Math.round(Number(item.progress || 0))}%</span></div>
          <div>
            <div class="scan-phase-title">${escapeHtml(item.phase || "Scanning")}</div>
            <div class="muted">Analysis Phase ${Math.max(1, Math.min(5, Number(item.phase_index || 1)))}/5</div>
          </div>
        </div>
        <div class="metric-line"><span>Logs Analysis</span><strong>${bucketPct((item.bucket_progress||{}).logging)}%</strong></div>
        <div class="mini-progress"><div class="progress-blue" style="width:${bucketPct((item.bucket_progress||{}).logging)}%"></div></div>
        <div class="metric-line"><span>Metrics Health Check</span><strong>${bucketPct((item.bucket_progress||{}).metrics)}%</strong></div>
        <div class="mini-progress"><div class="progress-green" style="width:${bucketPct((item.bucket_progress||{}).metrics)}%"></div></div>
        <div class="metric-line"><span>Distributed Tracing</span><strong>${bucketPct((item.bucket_progress||{}).tracing)}%</strong></div>
        <div class="mini-progress"><div class="progress-amber" style="width:${bucketPct((item.bucket_progress||{}).tracing)}%"></div></div>
        <div class="metric-line"><span>Health Signals</span><strong>${bucketPct((item.bucket_progress||{}).health)}%</strong></div>
        <div class="mini-progress"><div class="progress-slate" style="width:${bucketPct((item.bucket_progress||{}).health)}%"></div></div>
      </div>
    `).join("") : '<div class="muted">No repositories are actively running right now.</div>';
  }

  const queuedHost = qs("#batch-queued-grid");
  if(queuedHost){
    const queuedItems = items.filter(x => String(x.status || "").toLowerCase() === "queued");
    queuedHost.innerHTML = queuedItems.length ? queuedItems.map(item => `
      <div class="queued-chip">
        <strong>${escapeHtml(item.application_name || inferRepoDisplayName(item.repo_url))}</strong>
        <span>queued</span>
      </div>
    `).join("") : '<div class="muted">No queued repositories.</div>';
  }

  const completedHost = qs("#batch-completed-list");
  if(completedHost){
    const completedItems = items.filter(x => String(x.status || "").toLowerCase() === "completed");
    completedHost.innerHTML = completedItems.length ? completedItems.map(item => `
      <div class="completed-scan-card">
        <div class="check-circle">✓</div>
        <div class="completed-meta">
          <strong class="wrap-anywhere">${escapeHtml(item.application_name || inferRepoDisplayName(item.repo_url))}</strong>
          <div class="muted">${escapeHtml(item.maturity || "Done")} • ${escapeHtml(String(item.score ?? "—"))}</div>
        </div>
      </div>
    `).join("") : '<div class="muted">No completed scans yet.</div>';
  }

  const tableHost = qs("#batch-results-table");
  if(tableHost){
    const completedItems = items.filter(x => ["completed","failed"].includes(String(x.status || "").toLowerCase()));
    if(!completedItems.length){
      tableHost.textContent = "No completed results yet.";
    } else {
      tableHost.innerHTML = `
        <div class="assessment-table-wrap">
          <table class="assessment-table batch-results-grid">
            <thead>
              <tr>
                <th></th>
                <th>Repository</th>
                <th>Status</th>
                <th>Score</th>
                <th>Maturity</th>
                <th>Message</th>
              </tr>
            </thead>
            <tbody>
              ${completedItems.map((item, idx) => `
                <tr class="assessment-main-row">
                  <td><button class="expand-row-btn batch-expand-btn" data-batch-expand="${idx}">+</button></td>
                  <td class="wrap-anywhere table-repo-cell">${escapeHtml(item.application_name || inferRepoDisplayName(item.repo_url))}</td>
                  <td><span class="status-pill ${escapeHtml(item.status || "queued")}">${escapeHtml(item.status || "queued")}</span></td>
                  <td>${escapeHtml(String(item.score ?? "—"))}</td>
                  <td>${escapeHtml(item.maturity || "—")}</td>
                  <td class="wrap-anywhere">${escapeHtml(item.message || "—")}</td>
                </tr>
                <tr class="assessment-expand-row" id="batch-expand-${idx}">
                  <td colspan="6">
                    <div class="assessment-expand-panel">
                      <div class="assessment-expand-grid">
                        <div class="assessment-expand-card">
                          <h4>Repository Outcome</h4>
                          <div class="kv-list">
                            <div class="kv"><span>Application</span><strong>${escapeHtml(item.application_name || inferRepoDisplayName(item.repo_url))}</strong></div>
                            <div class="kv"><span>Repo</span><strong class="wrap-anywhere">${escapeHtml(item.repo_url || "")}</strong></div>
                            <div class="kv"><span>Token</span><strong class="token-mask">${escapeHtml(maskTokenLike(item.token_alias || ""))}</strong></div>
                          </div>
                        </div>
                        <div class="assessment-expand-card">
                          <h4>Outcome</h4>
                          <div class="kv-list">
                            <div class="kv"><span>Status</span><strong>${escapeHtml(item.status || "—")}</strong></div>
                            <div class="kv"><span>Score</span><strong>${escapeHtml(String(item.score ?? "—"))}</strong></div>
                            <div class="kv"><span>Maturity</span><strong>${escapeHtml(item.maturity || "—")}</strong></div>
                          </div>
                        </div>
                      </div>
                      <div class="assessment-bucket-row">
                        <div class="assessment-mini-bucket"><div class="mini-bucket-title">Logs Analysis</div><div class="mini-bucket-score">${bucketPct((item.bucket_progress||{}).logging)}%</div><div class="mini-progress"><div class="progress-blue" style="width:${bucketPct((item.bucket_progress||{}).logging)}%"></div></div></div>
                        <div class="assessment-mini-bucket"><div class="mini-bucket-title">Metrics Health Check</div><div class="mini-bucket-score">${bucketPct((item.bucket_progress||{}).metrics)}%</div><div class="mini-progress"><div class="progress-green" style="width:${bucketPct((item.bucket_progress||{}).metrics)}%"></div></div></div>
                        <div class="assessment-mini-bucket"><div class="mini-bucket-title">Distributed Tracing</div><div class="mini-bucket-score">${bucketPct((item.bucket_progress||{}).tracing)}%</div><div class="mini-progress"><div class="progress-amber" style="width:${bucketPct((item.bucket_progress||{}).tracing)}%"></div></div></div>
                        <div class="assessment-mini-bucket"><div class="mini-bucket-title">Health Signals</div><div class="mini-bucket-score">${bucketPct((item.bucket_progress||{}).health)}%</div><div class="mini-progress"><div class="progress-slate" style="width:${bucketPct((item.bucket_progress||{}).health)}%"></div></div></div>
                      </div>
                    </div>
                  </td>
                </tr>
              `).join("")}
            </tbody>
          </table>
        </div>
      `;
      qsa(".batch-expand-btn").forEach(btn=>{
        btn.addEventListener("click", ()=>{
          const row = qs(`#batch-expand-${btn.dataset.batchExpand}`);
          const isOpen = row.classList.contains("open");
          qsa(".assessment-expand-row").forEach(x=>x.classList.remove("open"));
          qsa(".batch-expand-btn").forEach(x=>x.textContent = "+");
          if(!isOpen){
            row.classList.add("open");
            btn.textContent = "–";
          }
        });
      });
    }
  }
}

function pollBatchStatus(){
  fetch("/batch/status").then(r=>r.json()).then(data=>{
    renderBatchStatus(data);
    if(data.is_running){
      batchPollHandle = setTimeout(pollBatchStatus, 1500);
    }
  });
}

function startBatchScan(){
  if(!enterpriseInventory.length){
    alert("Load or parse repository inventory first.");
    return;
  }
  const payload = {
    items: enterpriseInventory,
    run_mode: qs("#batch-run-mode").value,
    save_results: !!qs("#batch-save-results").checked,
    scanner_profile: qs("#batch-scanner-profile")?.value || "scanner_v1"
  };
  fetch("/batch/start", {
    method:"POST",
    headers:{"Content-Type":"application/json"},
    body:JSON.stringify(payload)
  }).then(r=>r.json()).then(data=>{
    if(data.status !== "started"){
      alert(data.message || "Could not start batch scan.");
      return;
    }
    if(batchPollHandle) clearTimeout(batchPollHandle);
    setPage("enterprise");
    setTimeout(()=>{ const card = qs("#batch-current-card"); if(card) card.scrollIntoView({behavior:"smooth", block:"start"}); }, 120);
    pollBatchStatus();
  });
}

function mergedBuckets(buckets){
  const merged = JSON.parse(JSON.stringify(DEFAULT_BUCKETS));
  Object.keys(buckets || {}).forEach(k=>{
    if(merged[k]){
      merged[k].enabled = !!buckets[k].enabled;
      merged[k].weight = Number(buckets[k].weight ?? merged[k].weight);
      merged[k].threshold = String((buckets[k].threshold ?? merged[k].threshold) || "normal");
    }
  });
  return merged;
}

function renderBucketConfigCards(){
  const host = qs("#bucket-config-grid");
  if(!host) return;
  const buckets = currentConfig.buckets || DEFAULT_BUCKETS;
  host.innerHTML = Object.entries(buckets).map(([key, meta]) => `
    <div class="bucket-config-card">
      <div class="bucket-config-top">
        <div>
          <strong>${escapeHtml(meta.title || key)}</strong>
          <div class="mini-help">Controls whether this signal family is scanned and how much it influences maturity.</div>
        </div>
        <label class="switch">
          <input type="checkbox" class="bucket-enabled" data-bucket="${key}" ${meta.enabled ? "checked" : ""}>
          <span class="slider"></span>
        </label>
      </div>
      <div class="weight-row">
        <input type="range" min="0" max="25" step="1" value="${Number(meta.weight || 0)}" class="range-input bucket-weight" data-bucket="${key}">
        <div class="weight-value" id="weight-display-${key}">${Number(meta.weight || 0)}</div>
      </div>
    </div>
  `).join("");

  qsa(".bucket-enabled").forEach(el=>{
    el.addEventListener("change", ()=>{
      const key = el.dataset.bucket;
      currentConfig.buckets[key].enabled = el.checked;
    });
  });
  qsa(".bucket-weight").forEach(el=>{
    el.addEventListener("input", ()=>{
      const key = el.dataset.bucket;
      const value = Number(el.value);
      currentConfig.buckets[key].weight = value;
      const display = qs(`#weight-display-${key}`);
      if(display) display.textContent = String(value);
    });
  });
}

function resetConfigToDefaults(){
  currentConfig = {db_enabled:true, db_path:"", buckets: JSON.parse(JSON.stringify(DEFAULT_BUCKETS))};
  const dbToggle = qs("#db-enabled-toggle");
  const dbPath = qs("#db-path");
  if(dbToggle) dbToggle.checked = true;
  if(dbPath) dbPath.value = "";
  renderBucketConfigCards();
}

function saveConfig(){
  currentConfig.db_enabled = !!qs("#db-enabled-toggle").checked;
  currentConfig.db_path = qs("#db-path").value;
  currentConfig.token_aliases = {
    azure_pat_main: qs("#token-alias-azure_pat_main")?.value || "",
    azure_pat_secondary: qs("#token-alias-azure_pat_secondary")?.value || ""
  };
  const safeBuckets = {};
  Object.entries(currentConfig.buckets || {}).forEach(([k, v])=>{
    safeBuckets[k] = {
      enabled: !!v.enabled,
      weight: Number(v.weight || 0),
      threshold: String(v.threshold || "normal")
    };
  });
  const payload = {
    db_enabled: currentConfig.db_enabled,
    db_path: currentConfig.db_path,
    buckets: safeBuckets,
    token_aliases: currentConfig.token_aliases
  };
  fetch("/config/database", {
    method:"POST",
    headers:{"Content-Type":"application/json"},
    body:JSON.stringify(payload)
  })
    .then(async r => {
      const data = await r.json().catch(()=>({}));
      if(!r.ok || data.status === "error"){
        throw new Error(data.message || "Could not save configuration.");
      }
      return data;
    })
    .then(()=>{
      alert("Configuration saved. Python will use these toggles, weights, and thresholds in the next scan.");
    })
    .catch(err=>{
      console.error(err);
      alert("Configuration save hit an issue. Existing settings are preserved; please try again.");
    });
}

function loadConfig(){
  fetch("/config/database").then(r=>r.json()).then(data=>{
    if(data.status !== "ok") return;
    currentConfig = {
      db_enabled: !!data.config.db_enabled,
      db_path: data.config.db_path || "",
      buckets: mergedBuckets(data.config.buckets || {}),
      token_aliases: data.config.token_aliases || {azure_pat_main:"", azure_pat_secondary:""}
    };
    const dbToggle = qs("#db-enabled-toggle");
    const dbPath = qs("#db-path");
    if(dbToggle) dbToggle.checked = currentConfig.db_enabled;
    if(dbPath) dbPath.value = currentConfig.db_path;
    const t1 = qs("#token-alias-azure_pat_main");
    const t2 = qs("#token-alias-azure_pat_secondary");
    if(t1) t1.value = currentConfig.token_aliases.azure_pat_main || "";
    if(t2) t2.value = currentConfig.token_aliases.azure_pat_secondary || "";
    renderBucketConfigCards();
  });
}

function exportExcel(){ window.location.href = "/export/excel"; }

document.addEventListener("DOMContentLoaded", ()=>{
  const savedTheme = localStorage.getItem("obs_theme") || "light";
  applyTheme(savedTheme);
  qs("#theme-toggle").addEventListener("click", ()=>{
    const current = document.documentElement.getAttribute("data-theme") || "light";
    applyTheme(current === "light" ? "dark" : "light");
  });
  qsa(".nav-btn").forEach(btn=>btn.addEventListener("click", ()=>setPage(btn.dataset.view)));
  qs("#go-scan").addEventListener("click", ()=>setPage("scan"));
  qs("#go-apps").addEventListener("click", ()=>{loadAssessments(); setPage("applications");});
  qs("#start-scan-btn").addEventListener("click", startScan);
  qs("#load-last-btn").addEventListener("click", loadLast);
  qs("#app-search").addEventListener("input", ()=>loadAssessments());
  qs("#save-current-btn").addEventListener("click", saveCurrent);
  qs("#save-config-btn").addEventListener("click", saveConfig);
  const resetBtn = qs("#reset-config-btn"); if(resetBtn) resetBtn.addEventListener("click", resetConfigToDefaults);
  qs("#export-excel-btn").addEventListener("click", exportExcel);
  qs("#export-excel-btn-2").addEventListener("click", exportExcel);
  const sampleBtn = qs("#load-sample-inventory-btn"); if(sampleBtn) sampleBtn.addEventListener("click", loadSampleInventory);
  const parseBtn = qs("#parse-inventory-btn"); if(parseBtn) parseBtn.addEventListener("click", parseInventoryText);
  const clearBtn = qs("#clear-inventory-btn"); if(clearBtn) clearBtn.addEventListener("click", ()=>{ const box=qs("#inventory-text"); if(box) box.value=""; enterpriseInventory=[]; renderEnterpriseInventory(); });
  const batchBtn = qs("#start-batch-btn"); if(batchBtn) batchBtn.addEventListener("click", startBatchScan);
  renderEnterpriseInventory();
  const exportHistoryBtn = qs("#export-history-btn");
  if(exportHistoryBtn){ exportHistoryBtn.addEventListener("click", ()=>{ window.location.href = "/api/history/export"; }); }
  const exportAssessmentsBtn = qs("#export-assessments-btn");
  if(exportAssessmentsBtn){ exportAssessmentsBtn.addEventListener("click", ()=>{ window.location.href = "/assessments/export"; }); }
  const exportHolisticBtn = qs("#export-holistic-btn");
  if(exportHolisticBtn){ exportHolisticBtn.addEventListener("click", ()=>{ window.location.href = "/reports/export/holistic"; }); }
  const saveMenuVisibilityBtn = qs("#save-menu-visibility-btn");
  if(saveMenuVisibilityBtn){ saveMenuVisibilityBtn.addEventListener("click", saveMenuVisibilityConfig); }
  const saveScannerRegistryBtn = qs("#save-scanner-registry-btn");
  if(saveScannerRegistryBtn){ saveScannerRegistryBtn.addEventListener("click", saveScannerRegistry); }
  const livebulkSampleBtn = qs("#livebulk-load-sample-btn"); if(livebulkSampleBtn) livebulkSampleBtn.addEventListener("click", loadLiveBulkSample);
  const livebulkStartBtn = qs("#livebulk-start-btn"); if(livebulkStartBtn) livebulkStartBtn.addEventListener("click", startLiveBulk);
  const newbulkSampleBtn = qs("#newbulk-load-sample-btn"); if(newbulkSampleBtn) newbulkSampleBtn.addEventListener("click", loadNewBulkSample);
  const newbulkStartBtn = qs("#newbulk-start-btn"); if(newbulkStartBtn) newbulkStartBtn.addEventListener("click", startNewBulk);
  const newbulkExportBtn = qs("#newbulk-export-btn"); if(newbulkExportBtn) newbulkExportBtn.addEventListener("click", exportNewBulkRun);
  const appSearch = qs("#app-search");
  if(appSearch){ appSearch.addEventListener("input", ()=> renderAppsRegister(assessmentCache)); }
  bindClickableDocs();
  renderScannerOptions([]);
  loadMenuVisibilityConfig();
  loadScannerRegistry();
  loadConfig();
  loadAssessments();
  loadAuditHistory();
});

document.addEventListener("click", (e)=>{
  const nav = e.target.closest("[data-nav]");
  if(nav){
    const view = nav.getAttribute("data-nav");
    if(view) setPage(view);
  }
});
