import json
import os
import queue
import sqlite3
import subprocess
import threading
import sys
import time
from pathlib import Path
from datetime import datetime
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Optional
import csv
import io

from fastapi import FastAPI
from fastapi.responses import StreamingResponse, FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel
from openpyxl import Workbook

BASE_DIR = Path(__file__).resolve().parent
DB_PATH = BASE_DIR / "assessments.db"
CONFIG_JSON_PATH = BASE_DIR / "scanner_config.json"

app = FastAPI()
app.mount("/static", StaticFiles(directory=str(BASE_DIR / "static")), name="static")

event_queue = queue.Queue()
current_process = {"proc": None}
last_report = {"data": None, "updated_at": None}
batch_state = {
    "is_running": False,
    "items": [],
    "summary": {"queued": 0, "running": 0, "completed": 0, "failed": 0, "total": 0, "avg_score": 0},
    "started_at": None,
    "finished_at": None,
    "active_index": None,
}
batch_lock = threading.Lock()

fifo_state = {
    "is_running": False,
    "scanner_profile": "scanner_v1",
    "queue": [],
    "current": None,
    "completed": [],
    "failed": [],
    "started_at": None,
    "finished_at": None,
}
fifo_lock = threading.Lock()

multiscan_state = {
    "is_running": False,
    "scanner_profile": "scanner_v1",
    "queue": [],
    "current": None,
    "completed": [],
    "failed": [],
    "started_at": None,
    "finished_at": None,
    "scan_run_id": None,
}
multiscan_lock = threading.Lock()

live_bulk_state = {
    "is_running": False,
    "scanner_profile": "scanner_v1",
    "queue": [],
    "current": None,
    "completed": [],
    "failed": [],
    "started_at": None,
    "finished_at": None,
    "scan_run_id": None,
}
live_bulk_lock = threading.Lock()

bulk_v2_state = {
    "is_running": False,
    "scanner_profile": "scanner_v1",
    "items": [],
    "started_at": None,
    "finished_at": None,
    "scan_run_id": None,
    "selected_repo": None,
}
bulk_v2_lock = threading.Lock()

def default_bucket_config():
    return {
        "logging": {"enabled": True, "weight": 15, "threshold": "normal"},
        "metrics": {"enabled": True, "weight": 15, "threshold": "normal"},
        "tracing": {"enabled": True, "weight": 15, "threshold": "normal"},
        "health": {"enabled": True, "weight": 15, "threshold": "normal"},
        "resilience": {"enabled": True, "weight": 10, "threshold": "normal"},
        "config": {"enabled": True, "weight": 10, "threshold": "normal"},
        "governance": {"enabled": True, "weight": 10, "threshold": "normal"},
        "cloud_observability": {"enabled": True, "weight": 10, "threshold": "normal"},
    }

def write_runtime_config_json(config_obj: dict):
    with open(CONFIG_JSON_PATH, "w", encoding="utf-8") as fh:
        json.dump(config_obj, fh, indent=2)

def default_token_aliases():
    return {
        "azure_pat_main": "",
        "azure_pat_secondary": ""
    }

def resolve_token_alias(alias: str) -> str:
    cfg = get_config()
    aliases = cfg.get("token_aliases", {}) or {}
    return aliases.get(alias, "")

class ScanRequest(BaseModel):
    repo_input: str
    token: str = ""
    scanner_profile: str = "scanner_v1"

class SaveAssessmentRequest(BaseModel):
    report: dict
    tier_override: str = ""
    portfolio: str = ""
    criticality: str = ""
    owner: str = ""
    notes: str = ""
    scanner_profile: str = "scanner_v1"

class DbConfigRequest(BaseModel):
    db_enabled: bool = True
    db_path: str = ""
    buckets: dict = {}
    token_aliases: dict = {}

class BatchScanItem(BaseModel):
    application_name: str = ""
    repo_url: str
    token_alias: str = ""
    tier: str = ""
    portfolio: str = ""
    owner: str = ""
    criticality: str = ""
    enabled: bool = True
    notes: str = ""

class BatchScanRequest(BaseModel):
    items: list[BatchScanItem]
    run_mode: str = "sequential"
    save_results: bool = True
    scanner_profile: str = "scanner_v1"

class FifoScanItem(BaseModel):
    application_name: str = ""
    repo_url: str
    token_alias: str = ""

class FifoScanRequest(BaseModel):
    items: list[FifoScanItem]
    scanner_profile: str = "scanner_v1"

class MultiScanItem(BaseModel):
    application_name: str = ""
    repo_url: str
    token_alias: str = ""
    tier: str = ""
    portfolio: str = ""
    owner: str = ""
    criticality: str = ""
    notes: str = ""

class MultiScanRequest(BaseModel):
    items: list[MultiScanItem]
    scanner_profile: str = "scanner_v1"
    save_results: bool = True

class LiveBulkItem(BaseModel):
    application_name: str = ""
    repo_url: str
    token_alias: str = ""
    tier: str = ""
    portfolio: str = ""
    owner: str = ""
    criticality: str = ""
    notes: str = ""

class LiveBulkRequest(BaseModel):
    items: list[LiveBulkItem]
    scanner_profile: str = "scanner_v1"
    save_results: bool = True

class BulkV2Item(BaseModel):
    application_name: str = ""
    repo_url: str
    token_alias: str = ""
    tier: str = ""
    portfolio: str = ""
    owner: str = ""
    criticality: str = ""
    notes: str = ""

class BulkV2Request(BaseModel):
    items: list[BulkV2Item]
    scanner_profile: str = "scanner_v1"
    save_results: bool = True

def init_db():
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.execute("""
    CREATE TABLE IF NOT EXISTS assessments (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        saved_at TEXT,
        application_name TEXT,
        repo_input TEXT,
        stack TEXT,
        archetype TEXT,
        tier TEXT,
        portfolio TEXT,
        criticality TEXT,
        owner TEXT,
        notes TEXT,
        maturity TEXT,
        score INTEGER,
        service_ids TEXT,
        vendor_tools TEXT,
        bucket_scores TEXT,
        recommendations TEXT,
        report_json TEXT,
        scan_run_id INTEGER,
        scan_type TEXT,
        scan_duration REAL,
        scanner_profile TEXT DEFAULT "scanner_v1"
    )
    """)
    try:
        cur.execute('ALTER TABLE assessments ADD COLUMN scanner_profile TEXT DEFAULT "scanner_v1"')
    except Exception:
        pass
    cur.execute("""
    CREATE TABLE IF NOT EXISTS scan_runs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        scan_type TEXT,
        started_at TEXT,
        finished_at TEXT,
        run_mode TEXT,
        repo_count INTEGER,
        success_count INTEGER,
        failed_count INTEGER,
        avg_score REAL,
        summary_json TEXT
    )
    """)
    cur.execute("""
    CREATE TABLE IF NOT EXISTS app_config (
        config_key TEXT PRIMARY KEY,
        config_value TEXT
    )
    """)
    conn.commit()
    conn.close()

def get_config():
    init_db()
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.execute("SELECT config_key, config_value FROM app_config")
    rows = dict(cur.fetchall())
    conn.close()
    buckets = default_bucket_config()
    try:
        stored_buckets = json.loads(rows.get("buckets_json", "{}"))
        for k, v in stored_buckets.items():
            if k in buckets:
                buckets[k]["enabled"] = bool(v.get("enabled", buckets[k]["enabled"]))
                buckets[k]["weight"] = float(v.get("weight", buckets[k]["weight"]))
                buckets[k]["threshold"] = str(v.get("threshold", buckets[k]["threshold"]))
    except Exception:
        pass
    config = {
        "db_enabled": rows.get("db_enabled", "true").lower() == "true",
        "db_path": rows.get("db_path", str(DB_PATH)),
        "buckets": buckets
    }
    write_runtime_config_json(config)
    return config

def save_config(db_enabled: bool, db_path: str, buckets: dict, token_aliases: dict | None = None):
    init_db()
    merged_buckets = default_bucket_config()
    for k, v in (buckets or {}).items():
        if k in merged_buckets:
            merged_buckets[k]["enabled"] = bool(v.get("enabled", merged_buckets[k]["enabled"]))
            merged_buckets[k]["weight"] = float(v.get("weight", merged_buckets[k]["weight"]))
            merged_buckets[k]["threshold"] = str(v.get("threshold", merged_buckets[k]["threshold"]))
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.execute("INSERT OR REPLACE INTO app_config(config_key, config_value) VALUES (?,?)", ("db_enabled", str(db_enabled).lower()))
    cur.execute("INSERT OR REPLACE INTO app_config(config_key, config_value) VALUES (?,?)", ("db_path", db_path or str(DB_PATH)))
    merged_aliases = default_token_aliases()
    for k, v in (token_aliases or {}).items():
        merged_aliases[k] = v
    cur.execute("INSERT OR REPLACE INTO app_config(config_key, config_value) VALUES (?,?)", ("buckets_json", json.dumps(merged_buckets)))
    cur.execute("INSERT OR REPLACE INTO app_config(config_key, config_value) VALUES (?,?)", ("token_aliases_json", json.dumps(merged_aliases)))
    conn.commit()
    conn.close()
    write_runtime_config_json({"db_enabled": db_enabled, "db_path": db_path or str(DB_PATH), "buckets": merged_buckets, "token_aliases": merged_aliases})

def emit(event_type: str, line: str):
    event_queue.put({"type": event_type, "line": line})

def classify_line(line: str) -> str:
    if line.startswith("[PASS]"): return "pass"
    if line.startswith("[WARN]"): return "warn"
    if line.startswith("[FAIL]"): return "fail"
    if line.startswith("[STAGE]"): return "stage"
    if line.startswith("[INFO]"): return "info"
    if line.startswith("[RESULT]"): return "result"
    if line.startswith("[DONE]"): return "done"
    return "plain"

def run_scan(repo_input: str, token: str, scanner_profile: str = "scanner_v1"):
    scanner_path = str(BASE_DIR / "observability_scanner.py")
    cmd = [sys.executable, scanner_path, repo_input, token, scanner_profile]
    proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, bufsize=1)
    current_process["proc"] = proc
    try:
        for raw_line in proc.stdout:
            line = raw_line.rstrip()
            emit(classify_line(line), line)
            if line.startswith("[DONE] "):
                try:
                    last_report["data"] = json.loads(line.replace("[DONE] ", "", 1))
                    last_report["updated_at"] = time.time()
                except Exception:
                    pass
        proc.wait()
        emit("complete", "[SYSTEM] Stream completed")
    except Exception as e:
        emit("fail", f"[FAIL] Server error while streaming scanner output: {e}")
        emit("complete", "[SYSTEM] Stream completed after error")
    finally:
        current_process["proc"] = None

def save_assessment_row(payload: SaveAssessmentRequest, scan_run_id: int | None = None, scan_type: str = "single", scan_duration: float | None = None):
    init_db()
    cfg = get_config()
    if not cfg["db_enabled"]:
        return {"status": "disabled", "message": "Database saving is disabled in configuration."}
    report = payload.report or {}
    tier = payload.tier_override or report.get("inferred_tier") or ""
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.execute("""
    INSERT INTO assessments (
        saved_at, application_name, repo_input, stack, archetype, tier, portfolio, criticality, owner, notes,
        maturity, score, service_ids, vendor_tools, bucket_scores, recommendations, report_json, scan_run_id, scan_type, scan_duration, scanner_profile
    ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
    """, (
        datetime.utcnow().isoformat(),
        report.get("application_name", ""),
        report.get("repository_input", ""),
        report.get("stack", ""),
        report.get("archetype", ""),
        tier,
        payload.portfolio,
        payload.criticality,
        payload.owner,
        payload.notes,
        report.get("maturity", ""),
        int(report.get("score", 0)),
        json.dumps(report.get("service_ids", [])),
        json.dumps(report.get("vendor_tools", [])),
        json.dumps(report.get("bucket_scores", {})),
        json.dumps(report.get("recommendations", [])),
        json.dumps(report),
        scan_run_id,
        scan_type,
        float(scan_duration or report.get("duration_seconds", 0) or 0),
        payload.scanner_profile or report.get("scanner_profile", "scanner_v1")
    ))
    conn.commit()
    saved_id = cur.lastrowid
    conn.close()
    return {"status": "ok", "saved_id": saved_id}

def fetch_assessments():
    init_db()
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    cur = conn.cursor()
    cur.execute("SELECT * FROM assessments ORDER BY id DESC")
    rows = [dict(r) for r in cur.fetchall()]
    conn.close()
    for row in rows:
        for k in ("service_ids", "vendor_tools", "bucket_scores", "recommendations", "report_json"):
            try:
                row[k] = json.loads(row[k]) if row[k] else ([] if k in ("service_ids","vendor_tools","recommendations") else {})
            except Exception:
                row[k] = [] if k in ("service_ids","vendor_tools","recommendations") else {}
    return rows

def fetch_scan_runs():
    init_db()
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    cur = conn.cursor()
    cur.execute("SELECT * FROM scan_runs ORDER BY id DESC")
    rows = [dict(r) for r in cur.fetchall()]
    conn.close()
    for row in rows:
        try:
            row["summary_json"] = json.loads(row["summary_json"]) if row.get("summary_json") else {}
        except Exception:
            row["summary_json"] = {}
    return rows

def fetch_application_history(application_name: str):
    init_db()
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    cur = conn.cursor()
    cur.execute(
        "SELECT id, saved_at, score, maturity, scan_type, scan_duration, scan_run_id FROM assessments WHERE application_name = ? ORDER BY id DESC LIMIT 25",
        (application_name,)
    )
    rows = [dict(r) for r in cur.fetchall()]
    conn.close()
    return rows

def create_scan_run(scan_type: str, run_mode: str, repo_count: int):
    init_db()
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.execute(
        "INSERT INTO scan_runs(scan_type, started_at, finished_at, run_mode, repo_count, success_count, failed_count, avg_score, summary_json) VALUES (?,?,?,?,?,?,?,?,?)",
        (scan_type, datetime.utcnow().isoformat(), None, run_mode, repo_count, 0, 0, 0, json.dumps({}))
    )
    conn.commit()
    run_id = cur.lastrowid
    conn.close()
    return run_id

def finalize_scan_run(run_id: int, scan_type: str):
    init_db()
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    cur = conn.cursor()
    cur.execute("SELECT score, maturity FROM assessments WHERE scan_run_id = ?", (run_id,))
    rows = [dict(r) for r in cur.fetchall()]
    repo_count = len(rows)
    success_count = len(rows)
    failed_count = 0
    avg_score = round(sum((r.get("score") or 0) for r in rows) / repo_count, 2) if repo_count else 0
    maturity_mix = {"L1": 0, "L2": 0, "L3": 0, "L4": 0}
    for r in rows:
        if r.get("maturity") in maturity_mix:
            maturity_mix[r["maturity"]] += 1
    summary = {"maturity_mix": maturity_mix}
    cur.execute(
        "UPDATE scan_runs SET finished_at = ?, success_count = ?, failed_count = ?, avg_score = ?, summary_json = ? WHERE id = ?",
        (datetime.utcnow().isoformat(), success_count, failed_count, avg_score, json.dumps(summary), run_id)
    )
    conn.commit()
    conn.close()

def build_landscape(rows):
    total = len(rows)
    maturity_counts = {"L1": 0, "L2": 0, "L3": 0, "L4": 0}
    tier_scores = {"T1": [], "T2": [], "T3": [], "T4": [], "Unknown": []}
    bucket_totals = {}
    for r in rows:
        maturity = r.get("maturity") or ""
        if maturity in maturity_counts:
            maturity_counts[maturity] += 1
        tier = r.get("tier") or "Unknown"
        tier_scores.setdefault(tier, []).append(r.get("score", 0))
        for b, s in (r.get("bucket_scores") or {}).items():
            bucket_totals.setdefault(b, []).append(float(s))
    tier_avg = {k: round(sum(v)/len(v), 2) if v else 0 for k, v in tier_scores.items()}
    bucket_avg = {k: round(sum(v)/len(v), 2) if v else 0 for k, v in bucket_totals.items()}
    return {
        "total_applications": total,
        "maturity_counts": maturity_counts,
        "tier_average_scores": tier_avg,
        "bucket_average_scores": bucket_avg
    }

def run_single_scan_sync(repo_input: str, token: str, scanner_profile: str = "scanner_v1"):
    scanner_def = resolve_scanner(scanner_profile)
    scanner_path = scanner_def["script_path"]
    if scanner_def.get("mode") == "profile":
        cmd = [sys.executable, scanner_path, repo_input, token, scanner_profile]
    else:
        cmd = [sys.executable, scanner_path, repo_input, token, scanner_profile]
    proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, bufsize=1)
    lines = []
    report = None
    try:
        for raw_line in proc.stdout:
            line = raw_line.rstrip()
            lines.append(line)
            if line.startswith("[DONE] "):
                try:
                    report = json.loads(line.replace("[DONE] ", "", 1))
                except Exception:
                    report = None
        proc.wait()
    except Exception as e:
        lines.append(f"[FAIL] Batch execution error: {e}")
    return {
        "returncode": proc.returncode if proc else 1,
        "lines": lines[-50:],
        "report": report
    }

def update_batch_summary():
    items = batch_state["items"]
    counts = {"queued": 0, "running": 0, "completed": 0, "failed": 0, "total": len(items), "avg_score": 0}
    scores = []
    for item in items:
        status = item.get("status", "queued")
        if status in counts:
            counts[status] += 1
        if item.get("score") is not None:
            try:
                scores.append(float(item.get("score") or 0))
            except Exception:
                pass
    if scores:
        counts["avg_score"] = round(sum(scores) / len(scores), 1)
    batch_state["summary"] = counts

def batch_item_payload(item):
    return {
        "application_name": item.get("application_name", ""),
        "repo_url": item.get("repo_url", ""),
        "token_alias": item.get("token_alias", ""),
        "tier": item.get("tier", ""),
        "portfolio": item.get("portfolio", ""),
        "owner": item.get("owner", ""),
        "criticality": item.get("criticality", ""),
        "enabled": item.get("enabled", True),
        "notes": item.get("notes", ""),
        "status": item.get("status", "queued"),
        "message": item.get("message", ""),
        "score": item.get("score"),
        "maturity": item.get("maturity"),
        "progress": 0,
        "phase": "Queued",
        "phase_index": 0,
        "bucket_progress": {"logging": 0, "metrics": 0, "tracing": 0, "health": 0},
        "report": {},
        "started_at": None,
        "finished_at": None,
        "scanner_profile": item.get("scanner_profile", "scanner_v1"),
    }


def update_batch_item(idx: int, **changes):
    with batch_lock:
        if idx < 0 or idx >= len(batch_state["items"]):
            return
        batch_state["items"][idx].update(changes)
        update_batch_summary()

def process_batch_item(idx: int, save_results: bool, scan_run_id: int | None = None):
    item = batch_state["items"][idx]
    if not item.get("enabled", True):
        update_batch_item(idx, status="failed", message="Repository disabled in inventory.", progress=100, phase="Skipped", phase_index=5)
        return

    phases = [
        ("Repository Connect", 12, {"logging": 5, "metrics": 0, "tracing": 0, "health": 0}),
        ("Inventory & File Discovery", 28, {"logging": 20, "metrics": 10, "tracing": 5, "health": 8}),
        ("Signal Detection", 56, {"logging": 55, "metrics": 42, "tracing": 28, "health": 35}),
        ("Maturity Scoring", 82, {"logging": 70, "metrics": 68, "tracing": 55, "health": 58}),
    ]

    update_batch_item(idx, status="running", message="Scanning repository...", started_at=time.time())
    token = resolve_token_alias(item.get("token_alias", "")) or item.get("token", "") or ""

    for phase_idx, (phase_name, progress, bucket_progress) in enumerate(phases, start=1):
        update_batch_item(
            idx,
            phase=phase_name,
            phase_index=phase_idx,
            progress=progress,
            bucket_progress=bucket_progress,
            message=f"{phase_name}..."
        )
        time.sleep(0.12)

    result = run_single_scan_sync(item.get("repo_url", ""), token, item.get("scanner_profile", "scanner_v1"))
    report = result.get("report")
    if report:
        if item.get("application_name"):
            report["application_name"] = item["application_name"]
        final_bucket_progress = {
            "logging": 100 if (report.get("bucket_overview", {}).get("logging", {}) or {}).get("score", 0) else 35,
            "metrics": 100 if (report.get("bucket_overview", {}).get("metrics", {}) or {}).get("score", 0) else 35,
            "tracing": 100 if (report.get("bucket_overview", {}).get("tracing", {}) or {}).get("score", 0) else 35,
            "health": 100 if (report.get("bucket_overview", {}).get("health", {}) or {}).get("score", 0) else 35,
        }
        update_batch_item(
            idx,
            score=report.get("score"),
            maturity=report.get("maturity"),
            message="Completed",
            status="completed",
            progress=100,
            phase="Completed",
            phase_index=5,
            bucket_progress=final_bucket_progress,
            report=report,
            finished_at=time.time()
        )
        if save_results:
            save_assessment_row(SaveAssessmentRequest(
                report=report,
                tier_override=item.get("tier", ""),
                portfolio=item.get("portfolio", ""),
                criticality=item.get("criticality", ""),
                owner=item.get("owner", ""),
                notes=item.get("notes", ""),
                scanner_profile=item.get("scanner_profile", "scanner_v1")
            ), scan_run_id=scan_run_id, scan_type="enterprise", scan_duration=(report or {}).get("duration_seconds", 0))
    else:
        lines = result.get("lines") or []
        update_batch_item(
            idx,
            status="failed",
            message=lines[-1] if lines else "Scan failed",
            progress=100,
            phase="Failed",
            phase_index=5,
            finished_at=time.time()
        )
        return
    item["status"] = "running"
    item["message"] = "Scanning repository..."
    update_batch_summary()
    token = resolve_token_alias(item.get("token_alias", "")) or item.get("token", "") or ""
    result = run_single_scan_sync(item.get("repo_url", ""), token, item.get("scanner_profile", "scanner_v1"))
    report = result.get("report")
    if report:
        if item.get("application_name"):
            report["application_name"] = item["application_name"]
        item["score"] = report.get("score")
        item["maturity"] = report.get("maturity")
        item["message"] = "Completed"
        item["status"] = "completed"
        if save_results:
            save_assessment_row(SaveAssessmentRequest(
                report=report,
                tier_override=item.get("tier", ""),
                portfolio=item.get("portfolio", ""),
                criticality=item.get("criticality", ""),
                owner=item.get("owner", ""),
                notes=item.get("notes", ""),
                scanner_profile=item.get("scanner_profile", "scanner_v1")
            ), scan_run_id=scan_run_id, scan_type="enterprise", scan_duration=(report or {}).get("duration_seconds", 0))
    else:
        item["status"] = "failed"
        item["message"] = result.get("lines", ["Scan failed"])[-1] if result.get("lines") else "Scan failed"
    update_batch_summary()


def fifo_item_payload(item: dict):
    return {
        "application_name": item.get("application_name", ""),
        "repo_url": item.get("repo_url", ""),
        "token_alias": item.get("token_alias", ""),
        "status": "queued",
        "progress": 0,
        "phase": "Queued",
        "lines": [],
        "report": None,
        "started_at": None,
        "finished_at": None,
    }

def reset_fifo_state(scanner_profile: str, items: list[dict]):
    fifo_state["is_running"] = True
    fifo_state["scanner_profile"] = scanner_profile
    fifo_state["queue"] = [fifo_item_payload(x) for x in items]
    fifo_state["current"] = None
    fifo_state["completed"] = []
    fifo_state["failed"] = []
    fifo_state["started_at"] = time.time()
    fifo_state["finished_at"] = None

def fifo_summary():
    total = len(fifo_state["queue"]) + len(fifo_state["completed"]) + len(fifo_state["failed"]) + (1 if fifo_state["current"] else 0)
    return {
        "total": total,
        "queued": len(fifo_state["queue"]),
        "completed": len(fifo_state["completed"]),
        "failed": len(fifo_state["failed"]),
        "running": 1 if fifo_state["current"] else 0,
    }

def run_fifo_scan(req: FifoScanRequest):
    items = [x.model_dump() for x in req.items]
    with fifo_lock:
        reset_fifo_state(req.scanner_profile, items)

    while True:
        with fifo_lock:
            if not fifo_state["queue"]:
                fifo_state["current"] = None
                fifo_state["is_running"] = False
                fifo_state["finished_at"] = time.time()
                break
            current = fifo_state["queue"].pop(0)
            current["status"] = "running"
            current["started_at"] = time.time()
            current["phase"] = "Repository Connect"
            fifo_state["current"] = current

        token = resolve_token_alias(current.get("token_alias", "")) or ""
        for name, pct in [("Repository Connect", 12), ("Inventory & File Discovery", 30), ("Signal Detection", 58), ("Maturity Scoring", 82)]:
            with fifo_lock:
                if fifo_state["current"]:
                    fifo_state["current"]["phase"] = name
                    fifo_state["current"]["progress"] = pct
                    fifo_state["current"]["lines"].append(f"[INFO] {name}")
            time.sleep(0.08)

        result = run_single_scan_sync(current.get("repo_url", ""), token, req.scanner_profile)
        lines = result.get("lines") or []
        report = result.get("report")
        with fifo_lock:
            if fifo_state["current"]:
                fifo_state["current"]["lines"] = (fifo_state["current"]["lines"] + lines)[-120:]
                fifo_state["current"]["progress"] = 100
                fifo_state["current"]["phase"] = "Completed" if report else "Failed"
                fifo_state["current"]["status"] = "completed" if report else "failed"
                fifo_state["current"]["report"] = report
                fifo_state["current"]["finished_at"] = time.time()
                done = dict(fifo_state["current"])
                if report:
                    fifo_state["completed"].append(done)
                else:
                    fifo_state["failed"].append(done)
                fifo_state["current"] = None


def multiscan_item_payload(item: dict):
    return {
        "application_name": item.get("application_name", ""),
        "repo_url": item.get("repo_url", ""),
        "token_alias": item.get("token_alias", ""),
        "tier": item.get("tier", ""),
        "portfolio": item.get("portfolio", ""),
        "owner": item.get("owner", ""),
        "criticality": item.get("criticality", ""),
        "notes": item.get("notes", ""),
        "status": "queued",
        "progress": 0,
        "phase": "Queued",
        "lines": [],
        "report": None,
        "started_at": None,
        "finished_at": None,
        "saved": False,
    }

def reset_multiscan_state(scanner_profile: str, items: list[dict], scan_run_id: int | None = None):
    multiscan_state["is_running"] = True
    multiscan_state["scanner_profile"] = scanner_profile
    multiscan_state["queue"] = [multiscan_item_payload(x) for x in items]
    multiscan_state["current"] = None
    multiscan_state["completed"] = []
    multiscan_state["failed"] = []
    multiscan_state["started_at"] = time.time()
    multiscan_state["finished_at"] = None
    multiscan_state["scan_run_id"] = scan_run_id

def multiscan_summary():
    total = len(multiscan_state["queue"]) + len(multiscan_state["completed"]) + len(multiscan_state["failed"]) + (1 if multiscan_state["current"] else 0)
    scores = [float((x.get("report") or {}).get("score", 0) or 0) for x in multiscan_state["completed"] if x.get("report")]
    return {
        "total": total,
        "queued": len(multiscan_state["queue"]),
        "completed": len(multiscan_state["completed"]),
        "failed": len(multiscan_state["failed"]),
        "running": 1 if multiscan_state["current"] else 0,
        "avg_score": round(sum(scores)/len(scores),1) if scores else 0,
    }

def run_multiscan(req: MultiScanRequest):
    items = [x.model_dump() for x in req.items]
    scan_run_id = create_scan_run("multiscan", "sequential", len(items))
    with multiscan_lock:
        reset_multiscan_state(req.scanner_profile, items, scan_run_id)

    while True:
        with multiscan_lock:
            if not multiscan_state["queue"]:
                multiscan_state["current"] = None
                multiscan_state["is_running"] = False
                multiscan_state["finished_at"] = time.time()
                finalize_scan_run(scan_run_id, "multiscan")
                break
            current = multiscan_state["queue"].pop(0)
            current["status"] = "running"
            current["started_at"] = time.time()
            current["phase"] = "Repository Connect"
            multiscan_state["current"] = current

        token = resolve_token_alias(current.get("token_alias", "")) or ""
        for name, pct in [("Repository Connect", 12), ("Inventory & File Discovery", 30), ("Signal Detection", 58), ("Maturity Scoring", 82)]:
            with multiscan_lock:
                if multiscan_state["current"]:
                    multiscan_state["current"]["phase"] = name
                    multiscan_state["current"]["progress"] = pct
                    multiscan_state["current"]["lines"].append(f"[INFO] {name}")
            time.sleep(0.08)

        result = run_single_scan_sync(current.get("repo_url", ""), token, req.scanner_profile)
        lines = result.get("lines") or []
        report = result.get("report")
        saved_ok = False

        if report and req.save_results:
            try:
                save_assessment_row(SaveAssessmentRequest(
                    report=report,
                    tier_override=current.get("tier", ""),
                    portfolio=current.get("portfolio", ""),
                    criticality=current.get("criticality", ""),
                    owner=current.get("owner", ""),
                    notes=current.get("notes", ""),
                    scanner_profile=req.scanner_profile
                ), scan_run_id=scan_run_id, scan_type="multiscan", scan_duration=(report or {}).get("duration_seconds", 0))
                saved_ok = True
            except Exception:
                saved_ok = False

        with multiscan_lock:
            if multiscan_state["current"]:
                multiscan_state["current"]["lines"] = (multiscan_state["current"]["lines"] + lines)[-120:]
                multiscan_state["current"]["progress"] = 100
                multiscan_state["current"]["phase"] = "Completed" if report else "Failed"
                multiscan_state["current"]["status"] = "completed" if report else "failed"
                multiscan_state["current"]["report"] = report
                multiscan_state["current"]["saved"] = saved_ok
                multiscan_state["current"]["finished_at"] = time.time()
                done = dict(multiscan_state["current"])
                if report:
                    multiscan_state["completed"].append(done)
                else:
                    multiscan_state["failed"].append(done)
                multiscan_state["current"] = None


def live_bulk_item_payload(item: dict):
    return {
        "application_name": item.get("application_name", ""),
        "repo_url": item.get("repo_url", ""),
        "token_alias": item.get("token_alias", ""),
        "tier": item.get("tier", ""),
        "portfolio": item.get("portfolio", ""),
        "owner": item.get("owner", ""),
        "criticality": item.get("criticality", ""),
        "notes": item.get("notes", ""),
        "status": "queued",
        "progress": 0,
        "phase": "Queued",
        "lines": [],
        "report": None,
        "started_at": None,
        "finished_at": None,
        "saved": False,
    }

def reset_live_bulk_state(scanner_profile: str, items: list[dict], scan_run_id: int | None = None):
    live_bulk_state["is_running"] = True
    live_bulk_state["scanner_profile"] = scanner_profile
    live_bulk_state["queue"] = [live_bulk_item_payload(x) for x in items]
    live_bulk_state["current"] = None
    live_bulk_state["completed"] = []
    live_bulk_state["failed"] = []
    live_bulk_state["started_at"] = time.time()
    live_bulk_state["finished_at"] = None
    live_bulk_state["scan_run_id"] = scan_run_id

def live_bulk_summary():
    total = len(live_bulk_state["queue"]) + len(live_bulk_state["completed"]) + len(live_bulk_state["failed"]) + (1 if live_bulk_state["current"] else 0)
    scores = [float((x.get("report") or {}).get("score", 0) or 0) for x in live_bulk_state["completed"] if x.get("report")]
    saved_count = len([x for x in live_bulk_state["completed"] if x.get("saved")])
    return {
        "total": total,
        "queued": len(live_bulk_state["queue"]),
        "completed": len(live_bulk_state["completed"]),
        "failed": len(live_bulk_state["failed"]),
        "running": 1 if live_bulk_state["current"] else 0,
        "saved": saved_count,
        "avg_score": round(sum(scores)/len(scores),1) if scores else 0,
    }

def run_live_bulk(req: LiveBulkRequest):
    items = [x.model_dump() for x in req.items]
    scan_run_id = create_scan_run("live_bulk", "sequential", len(items))
    with live_bulk_lock:
        reset_live_bulk_state(req.scanner_profile, items, scan_run_id)

    while True:
        with live_bulk_lock:
            if not live_bulk_state["queue"]:
                live_bulk_state["current"] = None
                live_bulk_state["is_running"] = False
                live_bulk_state["finished_at"] = time.time()
                finalize_scan_run(scan_run_id, "live_bulk")
                break
            current = live_bulk_state["queue"].pop(0)
            current["status"] = "running"
            current["started_at"] = time.time()
            current["phase"] = "Repository Connect"
            current["lines"] = [f"[STAGE] Starting bulk live scan using profile: {req.scanner_profile}"]
            live_bulk_state["current"] = current

        token = resolve_token_alias(current.get("token_alias", "")) or ""
        for name, pct in [("Repository Connect", 12), ("Inventory & File Discovery", 28), ("Signal Detection", 56), ("Maturity Scoring", 82)]:
            with live_bulk_lock:
                if live_bulk_state["current"]:
                    live_bulk_state["current"]["phase"] = name
                    live_bulk_state["current"]["progress"] = pct
                    live_bulk_state["current"]["lines"].append(f"[INFO] {name}")
            time.sleep(0.1)

        result = run_single_scan_sync(current.get("repo_url", ""), token, req.scanner_profile)
        lines = result.get("lines") or []
        report = result.get("report")
        saved_ok = False

        if report and req.save_results:
            try:
                save_assessment_row(SaveAssessmentRequest(
                    report=report,
                    tier_override=current.get("tier", ""),
                    portfolio=current.get("portfolio", ""),
                    criticality=current.get("criticality", ""),
                    owner=current.get("owner", ""),
                    notes=current.get("notes", ""),
                    scanner_profile=req.scanner_profile
                ), scan_run_id=scan_run_id, scan_type="live_bulk", scan_duration=(report or {}).get("duration_seconds", 0))
                saved_ok = True
            except Exception as e:
                lines.append(f"[FAIL] Save failed: {e}")

        with live_bulk_lock:
            if live_bulk_state["current"]:
                live_bulk_state["current"]["lines"] = (live_bulk_state["current"]["lines"] + lines)[-150:]
                live_bulk_state["current"]["progress"] = 100
                live_bulk_state["current"]["phase"] = "Completed" if report else "Failed"
                live_bulk_state["current"]["status"] = "completed" if report else "failed"
                live_bulk_state["current"]["report"] = report
                live_bulk_state["current"]["saved"] = saved_ok
                live_bulk_state["current"]["finished_at"] = time.time()
                done = dict(live_bulk_state["current"])
                if report:
                    live_bulk_state["completed"].append(done)
                else:
                    live_bulk_state["failed"].append(done)
                live_bulk_state["current"] = None


def bulk_v2_item_payload(item: dict, idx: int):
    repo = item.get("repo_url", "")
    app = item.get("application_name", "") or infer_app_name_from_repo(repo)
    return {
        "id": idx + 1,
        "application_name": app,
        "repo_url": repo,
        "token_alias": item.get("token_alias", ""),
        "tier": item.get("tier", ""),
        "portfolio": item.get("portfolio", ""),
        "owner": item.get("owner", ""),
        "criticality": item.get("criticality", ""),
        "notes": item.get("notes", ""),
        "status": "queued",
        "progress": 0,
        "phase": "Queued",
        "lines": [],
        "report": None,
        "saved": False,
        "started_at": None,
        "finished_at": None,
        "current_finding": "",
        "findings": [],
    }

def infer_app_name_from_repo(repo_url: str):
    if not repo_url:
        return "Repository"
    x = repo_url.rstrip("/").split("/")[-1]
    return x.replace(".git","") or "Repository"

def reset_bulk_v2_state(scanner_profile: str, items: list[dict], scan_run_id: int | None = None):
    bulk_v2_state["is_running"] = True
    bulk_v2_state["scanner_profile"] = scanner_profile
    bulk_v2_state["items"] = [bulk_v2_item_payload(x, i) for i, x in enumerate(items)]
    bulk_v2_state["started_at"] = time.time()
    bulk_v2_state["finished_at"] = None
    bulk_v2_state["scan_run_id"] = scan_run_id
    bulk_v2_state["selected_repo"] = bulk_v2_state["items"][0]["repo_url"] if bulk_v2_state["items"] else None

def bulk_v2_summary():
    items = bulk_v2_state["items"]
    return {
        "total": len(items),
        "queued": len([x for x in items if x.get("status") == "queued"]),
        "running": len([x for x in items if x.get("status") == "running"]),
        "completed": len([x for x in items if x.get("status") == "completed"]),
        "failed": len([x for x in items if x.get("status") == "failed"]),
        "saved": len([x for x in items if x.get("saved")]),
    }

def build_repo_findings(report: dict | None):
    findings = []
    if not report:
        return findings
    bucket_overview = report.get("bucket_overview") or {}
    for key, meta in bucket_overview.items():
        status = meta.get("status", "red")
        findings.append({
            "severity": "Critical" if status == "red" else ("Medium" if status == "amber" else "Success"),
            "title": meta.get("title", key),
            "detail": f'{meta.get("evidence_count", 0)} evidence item(s), score {meta.get("score", 0)}/{meta.get("weight", 0)}',
            "sample_files": meta.get("sample_files", [])[:3],
        })
    return findings[:12]

def run_bulk_v2(req: BulkV2Request):
    items = [x.model_dump() for x in req.items]
    scan_run_id = create_scan_run("bulk_v2", "sequential", len(items))
    with bulk_v2_lock:
        reset_bulk_v2_state(req.scanner_profile, items, scan_run_id)

    for i in range(len(bulk_v2_state["items"])):
        with bulk_v2_lock:
            item = bulk_v2_state["items"][i]
            item["status"] = "running"
            item["started_at"] = time.time()
            item["phase"] = "Repository Connect"
            item["progress"] = 8
            item["lines"] = [f'[STAGE] Starting Bulk Scan V2 using profile: {req.scanner_profile}']
            bulk_v2_state["selected_repo"] = item["repo_url"]

        token = resolve_token_alias(item.get("token_alias", "")) or ""
        stages = [
            ("Repository Connect", 15, "Connecting to repository"),
            ("Inventory & File Discovery", 32, "Discovering repository files"),
            ("Signal Detection", 58, "Scanning for observability signals"),
            ("Maturity Scoring", 82, "Calculating bucket scores"),
        ]
        for phase, pct, message in stages:
            with bulk_v2_lock:
                item["phase"] = phase
                item["progress"] = pct
                item["current_finding"] = message
                item["lines"].append(f"[INFO] {message}")
            time.sleep(0.12)

        result = run_single_scan_sync(item.get("repo_url", ""), token, req.scanner_profile)
        report = result.get("report")
        lines = result.get("lines") or []
        saved_ok = False

        if report and req.save_results:
            try:
                save_assessment_row(SaveAssessmentRequest(
                    report=report,
                    tier_override=item.get("tier", ""),
                    portfolio=item.get("portfolio", ""),
                    criticality=item.get("criticality", ""),
                    owner=item.get("owner", ""),
                    notes=item.get("notes", ""),
                    scanner_profile=req.scanner_profile
                ), scan_run_id=scan_run_id, scan_type="bulk_v2", scan_duration=(report or {}).get("duration_seconds", 0))
                saved_ok = True
            except Exception as e:
                lines.append(f"[FAIL] Save failed: {e}")

        with bulk_v2_lock:
            item["lines"] = (item["lines"] + lines)[-150:]
            item["report"] = report
            item["saved"] = saved_ok
            item["findings"] = build_repo_findings(report)
            item["current_finding"] = item["findings"][0]["title"] if item["findings"] else ("Completed successfully" if report else "Failed")
            item["progress"] = 100
            item["phase"] = "Completed" if report else "Failed"
            item["status"] = "completed" if report else "failed"
            item["finished_at"] = time.time()

    with bulk_v2_lock:
        bulk_v2_state["is_running"] = False
        bulk_v2_state["finished_at"] = time.time()
        finalize_scan_run(scan_run_id, "bulk_v2")
def run_batch_scan(batch_req: BatchScanRequest):
    scan_run_id = create_scan_run("enterprise", batch_req.run_mode or "sequential", len(batch_req.items))
    batch_state["scan_run_id"] = scan_run_id
    batch_state["is_running"] = True
    batch_state["started_at"] = time.time()
    batch_state["finished_at"] = None
    batch_state["items"] = [batch_item_payload({**i.model_dump(), "scanner_profile": batch_req.scanner_profile}) for i in batch_req.items]
    update_batch_summary()

    mode = (batch_req.run_mode or "sequential").lower()
    max_workers = 1
    if mode == "parallel_3":
        max_workers = 3
    elif mode == "parallel_5":
        max_workers = 5

    try:
        if max_workers == 1:
            for idx in range(len(batch_state["items"])):
                process_batch_item(idx, batch_req.save_results, scan_run_id)
        else:
            with ThreadPoolExecutor(max_workers=max_workers) as ex:
                futures = [ex.submit(process_batch_item, idx, batch_req.save_results, scan_run_id) for idx in range(len(batch_state["items"]))]
                for _ in as_completed(futures):
                    pass
    finally:
        batch_state["is_running"] = False
        batch_state["finished_at"] = time.time()
        update_batch_summary()
        finalize_scan_run(scan_run_id, "enterprise")

@app.on_event("startup")
def startup():
    init_db()
    get_config()


def get_menu_config():
    init_db()
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.execute("SELECT config_value FROM app_config WHERE config_key = ?", ("menu_visibility",))
    row = cur.fetchone()
    conn.close()
    default = {
        "dashboard": True,
        "scan": True,
        "applications": True,
        "details": True,
        "enterprise": True,
        "audit": True,
        "docs": True,
        "admin": True,
        "settings": True
    }
    if not row or not row[0]:
        return default
    try:
        saved = json.loads(row[0])
        default.update(saved or {})
    except Exception:
        pass
    return default

def save_menu_config(config: dict):
    init_db()
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.execute(
        "INSERT OR REPLACE INTO app_config(config_key, config_value) VALUES (?, ?)",
        ("menu_visibility", json.dumps(config))
    )
    conn.commit()
    conn.close()


def get_scanner_visibility():
    init_db()
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.execute("SELECT config_value FROM app_config WHERE config_key = ?", ("scanner_visibility",))
    row = cur.fetchone()
    conn.close()
    return json.loads(row[0]) if row and row[0] else {}

def save_scanner_visibility(config: dict):
    init_db()
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.execute(
        "INSERT OR REPLACE INTO app_config(config_key, config_value) VALUES (?, ?)",
        ("scanner_visibility", json.dumps(config))
    )
    conn.commit()
    conn.close()

def discover_scanners():
    """Return all available scanner definitions.

    Built-in profiles always exist. Any additional python script dropped into
    BASE_DIR/scanners is treated as a scanner candidate and will appear in
    administration for visibility control.
    """
    built_in = [
        {
            "id": "scanner_v1",
            "label": "OBS Industry",
            "script_path": str(BASE_DIR / "observability_scanner.py"),
            "mode": "profile",
            "built_in": True,
        },
        {
            "id": "scanner_v2",
            "label": "OBS Custom",
            "script_path": str(BASE_DIR / "observability_scanner.py"),
            "mode": "profile",
            "built_in": True,
        },
    ]
    extra = []
    scanners_dir = BASE_DIR / "scanners"
    if scanners_dir.exists():
        for path in sorted(scanners_dir.glob("*.py")):
            if path.name.startswith("_"):
                continue
            scanner_id = path.stem
            label = scanner_id.replace("_", " ").title()
            extra.append({
                "id": scanner_id,
                "label": label,
                "script_path": str(path),
                "mode": "script",
                "built_in": False,
            })
    visibility = get_scanner_visibility()
    all_items = built_in + extra
    for item in all_items:
        item["visible"] = bool(visibility.get(item["id"], True))
    return all_items

def resolve_scanner(scanner_id: str):
    items = discover_scanners()
    for item in items:
        if item["id"] == scanner_id:
            return item
    return next((x for x in items if x["id"] == "scanner_v1"), {
        "id": "scanner_v1",
        "label": "OBS Industry",
        "script_path": str(BASE_DIR / "observability_scanner.py"),
        "mode": "profile",
        "built_in": True,
        "visible": True
    })

def fetch_assessments_for_export(scan_id: int | None = None):
    init_db()
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    cur = conn.cursor()
    if scan_id is None:
        cur.execute("SELECT * FROM assessments ORDER BY saved_at DESC, id DESC")
    else:
        cur.execute("SELECT * FROM assessments WHERE id = ? ORDER BY saved_at DESC, id DESC", (scan_id,))
    rows = [dict(r) for r in cur.fetchall()]
    conn.close()
    parsed = []
    for row in rows:
        item = dict(row)
        for k in ("service_ids", "vendor_tools", "bucket_scores", "recommendations", "report_json"):
            try:
                item[k] = json.loads(item[k]) if item.get(k) else ([] if k in ("service_ids", "vendor_tools", "recommendations") else {})
            except Exception:
                item[k] = [] if k in ("service_ids", "vendor_tools", "recommendations") else {}
        parsed.append(item)
    return parsed


@app.get("/")
def root():
    return FileResponse(str(BASE_DIR / "static" / "index.html"))

@app.post("/start-scan")
def start_scan(req: ScanRequest):
    if current_process["proc"] is not None:
        return {"status": "busy", "message": "Another scan is already running"}
    if not req.repo_input.strip():
        return {"status": "error", "message": "Repository path or URL is required"}
    while not event_queue.empty():
        try:
            event_queue.get_nowait()
        except Exception:
            break
    threading.Thread(target=run_scan, args=(req.repo_input.strip(), req.token.strip(), req.scanner_profile), daemon=True).start()
    return {"status": "started"}

@app.get("/scan-stream")
def scan_stream():
    def event_generator():
        while True:
            event = event_queue.get()
            yield f"data: {json.dumps(event)}\n\n"
            if event["type"] == "complete":
                break
    return StreamingResponse(event_generator(), media_type="text/event-stream")

@app.get("/last-report")
def get_last_report():
    if not last_report["data"]:
        return JSONResponse({"status": "empty"})
    return JSONResponse({"status": "ok", "updated_at": last_report["updated_at"], "report": last_report["data"]})

@app.post("/save-assessment")
def save_assessment(req: SaveAssessmentRequest):
    run_id = create_scan_run("single", "manual", 1)
    result = save_assessment_row(req, scan_run_id=run_id, scan_type="single", scan_duration=(req.report or {}).get("duration_seconds", 0))
    finalize_scan_run(run_id, "single")
    return JSONResponse(result)

@app.get("/assessments")
def assessments():
    rows = fetch_assessments()
    return JSONResponse({"status": "ok", "items": rows, "landscape": build_landscape(rows)})

@app.post("/config/database")
def config_database(req: DbConfigRequest):
    save_config(req.db_enabled, req.db_path, req.buckets, getattr(req, "token_aliases", {}))
    return {"status": "ok"}

@app.get("/config/database")
def get_database_config():
    return JSONResponse({"status": "ok", "config": get_config()})





@app.post("/bulk-v2/start")
def bulk_v2_start(req: BulkV2Request):
    if bulk_v2_state["is_running"]:
        return JSONResponse({"status": "busy", "message": "A New Bulk Scan run is already running."})
    if not req.items:
        return JSONResponse({"status": "error", "message": "No repositories provided."}, status_code=400)
    threading.Thread(target=run_bulk_v2, args=(req,), daemon=True).start()
    return JSONResponse({"status": "started"})

@app.get("/bulk-v2/status")
def bulk_v2_status():
    return JSONResponse({
        "status": "ok",
        "is_running": bulk_v2_state["is_running"],
        "scanner_profile": bulk_v2_state["scanner_profile"],
        "summary": bulk_v2_summary(),
        "items": bulk_v2_state["items"],
        "selected_repo": bulk_v2_state["selected_repo"],
        "started_at": bulk_v2_state["started_at"],
        "finished_at": bulk_v2_state["finished_at"],
        "scan_run_id": bulk_v2_state["scan_run_id"],
    })

@app.post("/bulk-v2/select")
def bulk_v2_select(payload: dict):
    repo = payload.get("repo_url", "") if isinstance(payload, dict) else ""
    bulk_v2_state["selected_repo"] = repo
    return JSONResponse({"status": "ok", "selected_repo": repo})
@app.post("/live-bulk/start")
def live_bulk_start(req: LiveBulkRequest):
    if live_bulk_state["is_running"]:
        return JSONResponse({"status": "busy", "message": "A Live Scan Bulk run is already running."})
    if not req.items:
        return JSONResponse({"status": "error", "message": "No repositories provided."}, status_code=400)
    threading.Thread(target=run_live_bulk, args=(req,), daemon=True).start()
    return JSONResponse({"status": "started"})

@app.get("/live-bulk/status")
def live_bulk_status():
    return JSONResponse({
        "status": "ok",
        "is_running": live_bulk_state["is_running"],
        "scanner_profile": live_bulk_state["scanner_profile"],
        "summary": live_bulk_summary(),
        "queue": live_bulk_state["queue"],
        "current": live_bulk_state["current"],
        "completed": live_bulk_state["completed"],
        "failed": live_bulk_state["failed"],
        "started_at": live_bulk_state["started_at"],
        "finished_at": live_bulk_state["finished_at"],
        "scan_run_id": live_bulk_state["scan_run_id"],
    })

@app.post("/multiscan/start")
def multiscan_start(req: MultiScanRequest):
    if multiscan_state["is_running"]:
        return JSONResponse({"status": "busy", "message": "A multi scan is already running."})
    if not req.items:
        return JSONResponse({"status": "error", "message": "No repositories provided."}, status_code=400)
    threading.Thread(target=run_multiscan, args=(req,), daemon=True).start()
    return JSONResponse({"status": "started"})

@app.get("/multiscan/status")
def multiscan_status():
    return JSONResponse({
        "status": "ok",
        "is_running": multiscan_state["is_running"],
        "scanner_profile": multiscan_state["scanner_profile"],
        "summary": multiscan_summary(),
        "queue": multiscan_state["queue"],
        "current": multiscan_state["current"],
        "completed": multiscan_state["completed"],
        "failed": multiscan_state["failed"],
        "started_at": multiscan_state["started_at"],
        "finished_at": multiscan_state["finished_at"],
        "scan_run_id": multiscan_state["scan_run_id"],
    })

@app.post("/fifo/start")
def fifo_start(req: FifoScanRequest):
    if fifo_state["is_running"]:
        return JSONResponse({"status": "busy", "message": "A FIFO queue scan is already running."})
    if not req.items:
        return JSONResponse({"status": "error", "message": "No repositories provided."}, status_code=400)
    threading.Thread(target=run_fifo_scan, args=(req,), daemon=True).start()
    return JSONResponse({"status": "started"})

@app.get("/fifo/status")
def fifo_status():
    return JSONResponse({
        "status": "ok",
        "is_running": fifo_state["is_running"],
        "scanner_profile": fifo_state["scanner_profile"],
        "summary": fifo_summary(),
        "queue": fifo_state["queue"],
        "current": fifo_state["current"],
        "completed": fifo_state["completed"],
        "failed": fifo_state["failed"],
        "started_at": fifo_state["started_at"],
        "finished_at": fifo_state["finished_at"],
    })

@app.post("/batch/start")
def batch_start(req: BatchScanRequest):
    if batch_state["is_running"]:
        return JSONResponse({"status": "busy", "message": "A batch scan is already running."})
    threading.Thread(target=run_batch_scan, args=(req,), daemon=True).start()
    return JSONResponse({"status": "started"})

@app.get("/audit/history")
def audit_history():
    runs = fetch_scan_runs()
    return JSONResponse({"status": "ok", "items": runs})

@app.get("/audit/application-history")
def audit_application_history(application_name: str):
    return JSONResponse({"status": "ok", "items": fetch_application_history(application_name)})
@app.get("/batch/status")
def batch_status():
    return JSONResponse({
        "status": "ok",
        "is_running": batch_state["is_running"],
        "summary": batch_state["summary"],
        "items": batch_state["items"],
        "started_at": batch_state["started_at"],
        "finished_at": batch_state["finished_at"],
    })

@app.get("/export/excel")
def export_excel():
    rows = fetch_assessments()
    wb = Workbook()

    ws1 = wb.active
    ws1.title = "Applications"
    ws1.append(["Application", "Tier", "Portfolio", "Criticality", "Owner", "Maturity", "Score", "Stack", "Archetype", "Service IDs", "Vendor Tools"])
    for r in rows:
        ws1.append([
            r.get("application_name",""), r.get("tier",""), r.get("portfolio",""), r.get("criticality",""),
            r.get("owner",""), r.get("maturity",""), r.get("score",0), r.get("stack",""),
            r.get("archetype",""), ", ".join(r.get("service_ids",[])), ", ".join(r.get("vendor_tools",[]))
        ])

    ws2 = wb.create_sheet("Bucket Scores")
    bucket_names = ["logging","metrics","tracing","health","resilience","config","governance","cloud_observability"]
    ws2.append(["Application", "Tier"] + bucket_names)
    for r in rows:
        scores = r.get("bucket_scores", {})
        ws2.append([r.get("application_name",""), r.get("tier","")] + [scores.get(b,"") for b in bucket_names])

    ws3 = wb.create_sheet("Recommendations")
    ws3.append(["Application", "Audience", "Priority", "Bucket", "Recommendation"])
    for r in rows:
        recs = r.get("recommendations", [])
        for rec in recs:
            ws3.append([r.get("application_name",""), rec.get("audience",""), rec.get("priority",""), rec.get("bucket",""), rec.get("text","")])

    ws4 = wb.create_sheet("Landscape Summary")
    landscape = build_landscape(rows)
    ws4.append(["Metric", "Value"])
    ws4.append(["Total Applications", landscape["total_applications"]])
    for k, v in landscape["maturity_counts"].items():
        ws4.append([f"Maturity {k}", v])
    for k, v in landscape["tier_average_scores"].items():
        ws4.append([f"Tier Avg {k}", v])

    ws5 = wb.create_sheet("Service Heatmap")
    ws5.append(["Application", "Service", "Maturity", "Overall", "logging", "metrics", "tracing", "health", "resilience", "config", "governance", "cloud_observability"])
    for r in rows:
        report = r.get("report_json", {}) or {}
        for svc in report.get("service_heatmap", []):
            b = svc.get("buckets", {})
            ws5.append([
                r.get("application_name",""), svc.get("service",""), svc.get("maturity",""), svc.get("overall",0),
                b.get("logging",""), b.get("metrics",""), b.get("tracing",""), b.get("health",""),
                b.get("resilience",""), b.get("config",""), b.get("governance",""), b.get("cloud_observability","")
            ])
    output_path = BASE_DIR / "observability_landscape.xlsx"
    wb.save(output_path)
    return FileResponse(str(output_path), filename="observability_landscape.xlsx")


@app.get("/api/history/export")
def api_history_export():
    conn = get_db()
    cur = conn.cursor()
    cur.execute("SELECT * FROM scan_runs ORDER BY created_at DESC, id DESC")
    rows = [dict(r) for r in cur.fetchall()]
    conn.close()

    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(["id", "repo_url", "primary_service_id", "score", "maturity", "created_at"])
    for row in rows:
        writer.writerow([
            row.get("id"),
            row.get("repo_url"),
            row.get("primary_service_id"),
            row.get("score"),
            row.get("maturity"),
            row.get("created_at"),
        ])
    output.seek(0)
    return StreamingResponse(
        iter([output.getvalue()]),
        media_type="text/csv",
        headers={"Content-Disposition": "attachment; filename=scan_history.csv"}
    )


@app.get("/config/menu-visibility")
def api_get_menu_visibility():
    return {"status": "ok", "menu_visibility": get_menu_config()}

@app.post("/config/menu-visibility")
def api_save_menu_visibility(payload: dict):
    incoming = payload.get("menu_visibility", {}) if isinstance(payload, dict) else {}
    current = get_menu_config()
    current.update({k: bool(v) for k, v in incoming.items()})
    save_menu_config(current)
    return {"status": "ok", "menu_visibility": current}


@app.get("/config/scanners")
def api_get_scanners():
    items = discover_scanners()
    return {"status": "ok", "items": items, "visible_items": [x for x in items if x.get("visible", True)]}

@app.post("/config/scanners")
def api_save_scanners(payload: dict):
    items = payload.get("items", []) if isinstance(payload, dict) else []
    current = get_scanner_visibility()
    for item in items:
        scanner_id = item.get("id")
        if scanner_id:
            current[scanner_id] = bool(item.get("visible", True))
    save_scanner_visibility(current)
    return {"status": "ok", "items": discover_scanners()}

@app.get("/api/admin")
def api_admin():
    return {
        "database_mode": "sqlite",
        "database_file": DB_PATH.name,
        "pyodbc_required": False,
        "database_setup": "Built in. SQLite is active and observability.db is created automatically on startup."
    }


@app.get("/assessments/export")
def export_assessments():
    init_db()
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    cur = conn.cursor()
    cur.execute("""
        SELECT id, application_name, repo_input, stack, archetype, tier, portfolio, owner, criticality,
               maturity, score, saved_at, service_ids_json, vendor_tools_json, bucket_scores_json, report_json, scanner_profile
        FROM assessments
        ORDER BY saved_at DESC, id DESC
    """)
    rows = [dict(r) for r in cur.fetchall()]
    conn.close()

    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow([
        "id","application_name","repo_input","stack","archetype","tier","portfolio","owner","criticality",
        "maturity","score","saved_at","service_ids","vendor_tools","bucket_scores","report_json","scanner_profile"
    ])
    for row in rows:
        writer.writerow([
            row.get("id",""),
            row.get("application_name",""),
            row.get("repo_input",""),
            row.get("stack",""),
            row.get("archetype",""),
            row.get("tier",""),
            row.get("portfolio",""),
            row.get("owner",""),
            row.get("criticality",""),
            row.get("maturity",""),
            row.get("score",""),
            row.get("saved_at",""),
            row.get("service_ids_json",""),
            row.get("vendor_tools_json",""),
            row.get("bucket_scores_json",""),
            row.get("report_json",""),
            row.get("scanner_profile","scanner_v1"),
        ])
    output.seek(0)
    return StreamingResponse(
        iter([output.getvalue()]),
        media_type="text/csv",
        headers={"Content-Disposition": "attachment; filename=scanned_applications_register.csv"}
    )


def fetch_assessments_for_run(scan_run_id: int):
    init_db()
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    cur = conn.cursor()
    cur.execute("SELECT * FROM assessments WHERE scan_run_id = ? ORDER BY id DESC", (scan_run_id,))
    rows = [dict(r) for r in cur.fetchall()]
    conn.close()
    for row in rows:
        for k in ("service_ids", "vendor_tools", "bucket_scores", "recommendations", "report_json"):
            try:
                row[k] = json.loads(row[k]) if row[k] else ([] if k in ("service_ids","vendor_tools","recommendations") else {})
            except Exception:
                row[k] = [] if k in ("service_ids","vendor_tools","recommendations") else {}
    return rows

@app.get("/batch/export/summary/{scan_run_id}")
def export_batch_summary(scan_run_id: int):
    rows = fetch_assessments_for_run(scan_run_id)
    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(["application_name","repo_input","scanner_profile","tier","portfolio","owner","criticality","maturity","score","services_count","tools_count","saved_at"])
    for r in rows:
        writer.writerow([
            r.get("application_name",""),
            r.get("repo_input",""),
            r.get("scanner_profile","scanner_v1"),
            r.get("tier",""),
            r.get("portfolio",""),
            r.get("owner",""),
            r.get("criticality",""),
            r.get("maturity",""),
            r.get("score",""),
            len(r.get("service_ids",[])),
            len(r.get("vendor_tools",[])),
            r.get("saved_at",""),
        ])
    output.seek(0)
    return StreamingResponse(iter([output.getvalue()]), media_type="text/csv", headers={"Content-Disposition": f"attachment; filename=batch_{scan_run_id}_summary.csv"})

@app.get("/batch/export/details/{scan_run_id}")
def export_batch_details(scan_run_id: int):
    rows = fetch_assessments_for_run(scan_run_id)
    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(["application_name","repo_input","scanner_profile","bucket","bucket_score","service_ids","vendor_tools","strengths","gaps","recommendations"])
    for r in rows:
        report = r.get("report_json") or {}
        bucket_overview = report.get("bucket_overview") or {}
        strengths = ", ".join(report.get("strengths", []))
        gaps = ", ".join(report.get("gaps", []))
        recs = ", ".join([x.get("text","") if isinstance(x, dict) else str(x) for x in report.get("recommendations", [])])
        if bucket_overview:
            for bucket, meta in bucket_overview.items():
                writer.writerow([
                    r.get("application_name",""),
                    r.get("repo_input",""),
                    r.get("scanner_profile","scanner_v1"),
                    bucket,
                    meta.get("score",""),
                    ", ".join(r.get("service_ids",[])),
                    ", ".join(r.get("vendor_tools",[])),
                    strengths,
                    gaps,
                    recs,
                ])
        else:
            writer.writerow([
                r.get("application_name",""),
                r.get("repo_input",""),
                r.get("scanner_profile","scanner_v1"),
                "",
                "",
                ", ".join(r.get("service_ids",[])),
                ", ".join(r.get("vendor_tools",[])),
                strengths,
                gaps,
                recs,
            ])
    output.seek(0)
    return StreamingResponse(iter([output.getvalue()]), media_type="text/csv", headers={"Content-Disposition": f"attachment; filename=batch_{scan_run_id}_details.csv"})

@app.get("/batch/export/report/{scan_run_id}")
def export_batch_report_json(scan_run_id: int):
    rows = fetch_assessments_for_run(scan_run_id)
    payload = {
        "scan_run_id": scan_run_id,
        "applications": rows,
        "landscape": build_landscape(rows),
    }
    return JSONResponse(payload)


@app.get("/reports/export/holistic")
def export_holistic_register():
    rows = fetch_assessments_for_export()
    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow([
        "id","application_name","repo_input","scanner_profile","stack","archetype","tier","portfolio","owner","criticality",
        "maturity","score","saved_at","services_count","tools_count","strengths","gaps"
    ])
    for r in rows:
        report = r.get("report_json") or {}
        writer.writerow([
            r.get("id",""),
            r.get("application_name",""),
            r.get("repo_input",""),
            r.get("scanner_profile","scanner_v1"),
            r.get("stack",""),
            r.get("archetype",""),
            r.get("tier",""),
            r.get("portfolio",""),
            r.get("owner",""),
            r.get("criticality",""),
            r.get("maturity",""),
            r.get("score",""),
            r.get("saved_at",""),
            len(r.get("service_ids",[])),
            len(r.get("vendor_tools",[])),
            ", ".join(report.get("strengths", [])),
            ", ".join(report.get("gaps", [])),
        ])
    output.seek(0)
    return StreamingResponse(iter([output.getvalue()]), media_type="text/csv", headers={"Content-Disposition": "attachment; filename=holistic_scans_register.csv"})

@app.get("/reports/export/scan/{scan_id}")
def export_single_scan_csv(scan_id: int):
    rows = fetch_assessments_for_export(scan_id)
    if not rows:
        return JSONResponse({"status":"error","message":"Scan not found"}, status_code=404)
    r = rows[0]
    report = r.get("report_json") or {}
    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(["section","field","value"])
    top_fields = {
        "application_name": r.get("application_name",""),
        "repo_input": r.get("repo_input",""),
        "scanner_profile": r.get("scanner_profile","scanner_v1"),
        "stack": r.get("stack",""),
        "archetype": r.get("archetype",""),
        "tier": r.get("tier",""),
        "portfolio": r.get("portfolio",""),
        "owner": r.get("owner",""),
        "criticality": r.get("criticality",""),
        "maturity": r.get("maturity",""),
        "score": r.get("score",""),
        "saved_at": r.get("saved_at",""),
    }
    for k,v in top_fields.items():
        writer.writerow(["summary", k, v])

    for s in r.get("service_ids",[]):
        writer.writerow(["service_ids", "service_id", s])
    for t in r.get("vendor_tools",[]):
        writer.writerow(["vendor_tools", "tool", t])

    bucket_scores = r.get("bucket_scores", {})
    if isinstance(bucket_scores, dict):
        for bucket, meta in bucket_scores.items():
            if isinstance(meta, dict):
                writer.writerow(["bucket", bucket, f'{meta.get("score","")}/{meta.get("weight","")}'])
            else:
                writer.writerow(["bucket", bucket, meta])

    for strength in report.get("strengths", []):
        writer.writerow(["strengths", "item", strength])
    for gap in report.get("gaps", []):
        writer.writerow(["gaps", "item", gap])

    for rec in report.get("recommendations", []):
        if isinstance(rec, dict):
            writer.writerow(["recommendations", rec.get("bucket",""), rec.get("text","")])
        else:
            writer.writerow(["recommendations", "item", str(rec)])

    scanner2 = report.get("scanner2") or {}
    if scanner2:
        writer.writerow(["scanner2", "verdict", scanner2.get("verdict","")])
        for group, meta in (scanner2.get("bucket_summary") or {}).items():
            writer.writerow(["scanner2_bucket", group, f'{meta.get("passed","")}/{meta.get("total","")} ({meta.get("status","")})'])

    output.seek(0)
    app_name = (r.get("application_name") or "scan").replace(" ", "_")
    return StreamingResponse(iter([output.getvalue()]), media_type="text/csv", headers={"Content-Disposition": f"attachment; filename={app_name}_scan_{scan_id}.csv"})
