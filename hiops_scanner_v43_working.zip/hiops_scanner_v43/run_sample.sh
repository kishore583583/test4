#!/usr/bin/env bash
pip install -r requirements.txt
python main.py --repo ./sample_repo --output ./outputs
